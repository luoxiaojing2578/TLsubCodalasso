# Trans-subCodaLasso Code 

R Code for the paper:

**Transfer Learning for High-Dimensional Regression with Compositional Covariates: Application to Microbiome Studies**

This folder contains the model implementation, simulation code, real data analysis code, and microbiome data used in the paper and supplementary material.

## Outline

```text
├── code
│   ├── real                         # real microbiome data analysis for BMI prediction
│   └── sim                          # simulation studies in the paper and supplementary material
│       ├── Main-simulation                         # main simulations in Section 4.2 and Supplementary Section S5.2.1
│       ├── Constraint-effects Simulation            # effects of constraints and excluding non-compositional covariates, Supplementary Section S5.2.2
│       ├── Target-sample-size Simulation            # effect of target-domain sample size, Supplementary Section S5.2.3
│       ├── TF Simulation                            # comparison with constrained TransFusion, Supplementary Section S4.1
│       ├── L0 Simulation                            # comparison with constrained L0-based methods, Supplementary Section S4.2
│       ├── Tuning-sensitivity Simulation            # sensitivity analysis for tuning parameters
│       ├── msub Simulation                          # comparison with the variant imposing constraints only in the second step
│       └── Additional source-selection Simulation   # comparison with a joint source-selection method
└── data
    └── abundance_stoolsubset.csv     # microbiome data used in the real data analysis
```

## Main functions

The main functions for the proposed Trans-subCodaLasso method are generally provided in:

```text
Func-TransCodaLasso.R
cclasso1.cpp
```

The file `cclasso1.cpp` contains C++ code used for constrained optimization through `Rcpp`.

## Notes

Some scripts call C++ code through `Rcpp::sourceCpp`, so a working C++ compiler is required.
