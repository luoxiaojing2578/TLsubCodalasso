# Function(Simulation-small-rho05-single)

library(MASS) 
library(stats) 
library(magrittr) 

### Coefficient generating function
Coef.gen<- function(h=2, q=4, size.A0, M, sig.delta1, sig.delta2, 
                    p, exact=TRUE, seed,
                    p_n = 2, sig.delta_a1 = 0.05, sig.delta_a2 = 1,
                    num_perturbed_groups = 3
){
  set.seed(seed)
  resample <- function(x, ...) x[sample.int(length(x), ...)]
  beta <- c(0.14,-0.07,0.03,-0.19,0.11,-0.04,0.08,-0.16,0.05,0.12,-0.33,0.27,-0.41,0.18,0.46,-0.24,
            rep(0, p - 16))
  
  tind <- c(0, p)
  ngrp <- length(tind)-1 
  
  W <- matrix(rep(beta, each=M), ncol=M, byrow=TRUE) 
  
  if (p_n == 0) { 
    a_target <- numeric(0)  
    A <- matrix(nrow=0, ncol=M) 
  } else { 
    a_target <- c(0.5, -0.1)
    A <- matrix(rep(a_target, each=M), ncol=M, byrow=TRUE) 
  }
  
  start_idx <- 1
  for (g in 1:ngrp) {
    end_idx <- start_idx + (tind[g+1] - tind[g]) - 1
    group_sum <- sum(beta[start_idx:end_idx])
    if (abs(group_sum) > 1e-6) {
      warning(paste("Warning: The sum of coefficients in group", g, "is", round(group_sum, 6), "which is not exactly 0."))
    }
    start_idx <- end_idx + 1
  }
  
  if (!is.numeric(num_perturbed_groups) || length(num_perturbed_groups) != 1 || 
      num_perturbed_groups < 1 || num_perturbed_groups > ngrp ||
      num_perturbed_groups != as.integer(num_perturbed_groups)) {
    stop(paste("num_perturbed_groups must be a positive integer between 1 and", ngrp,
               "(the current total number of groups is", ngrp, ")!"))
  }
  num_perturbed_groups <- as.integer(num_perturbed_groups)
  perturbed_groups <- sort(resample(1:ngrp, size = num_perturbed_groups, replace = FALSE))
  
  for(k in 1:M){
    set.seed(seed + k)
    if(k <= size.A0){ 
      if(exact){ 
        for(i in 1:length(perturbed_groups)){
          g <- perturbed_groups[i] 
          group_vars <- (tind[g]+1):tind[g+1] 
          samp0<- resample(group_vars, h/2, replace=F)
          samp_neg <- resample(setdiff(group_vars, samp0), h/2, replace = F)
          W[samp0,k] <- W[samp0,k] + sig.delta1
          W[samp_neg, k] <- W[samp_neg, k] - sig.delta1
          
        }
        if (p_n > 0) {
          A[, k] <- a_target + sig.delta_a1
        }
      }else{ 
        for(i in 1:length(perturbed_groups)){
          g <- perturbed_groups[i] 
          group_vars <- (tind[g]+1):tind[g+1]
          samp_pos <- resample(group_vars, h/2, replace = F)
          samp_posneg <- resample(setdiff(group_vars, samp_pos), h/2, replace = FALSE)
          random_values <- runif(length(samp_pos), min = 0, max = 0.05)
          W[samp_pos, k] <- W[samp_pos, k] + random_values
          W[samp_posneg, k] <- W[samp_posneg, k] - random_values
        }
        if (p_n > 0) {
          random_values <- runif(p_n, min = 0, max = 0.05)
          A[, k] <- a_target + random_values 
        }
      }
    }else{ 
      if(exact){ 
        for(g in 1:ngrp){
          group_vars <- (tind[g]+1):tind[g+1]
          samp1 <- resample(group_vars, q/2, replace = F)
          samp_neg <- resample(setdiff(group_vars, samp1), q/2, replace = F)
          W[samp1,k] <- W[samp1,k] + sig.delta2
          W[samp_neg, k] <- W[samp_neg, k] - sig.delta2
        }
        if (p_n > 0) {
          A[, k] <- a_target + sig.delta_a2
        }
      }else{ 
        for(g in 1:ngrp){
          group_vars <- (tind[g]+1):tind[g+1]
          samp_pos <- resample(group_vars, q/2, replace = F)
          samp_posneg <- resample(setdiff(group_vars, samp_pos), q/2, replace = F)
          random_values <- runif(length(samp_pos), min = 0.5, max = 0.8)
          W[samp_pos, k] <- W[samp_pos, k] + random_values
          W[samp_posneg, k] <- W[samp_posneg, k] - random_values
        }
        if (p_n > 0) {
          random_values <- runif(p_n, min = 0.5, max = 0.8)
          A[, k] <- a_target + random_values 
        }
      }
    }
    start_idx <- 1
    for (g in 1:ngrp) {
      end_idx <- start_idx + (tind[g+1] - tind[g]) - 1
      group_sum <- sum(W[start_idx:end_idx, k])
      if (abs(group_sum) > 1e-6) {
        warning(paste("Warning: In source domain", k, ", the sum of coefficients in group", g,
                      "is", round(group_sum, 6), "and is not exactly 0!"))
      }
      start_idx <- end_idx + 1
    }
  }
  return(list(W=W, beta=beta, tind=tind,
              A=A, a_target=a_target, p_n=p_n))
}


### Data generation function
Data.gen <- function(n.vec, M, p, B, snr, seed=2025) {
  set.seed(seed)
  
  p_n <- B$p_n       
  a_target <- B$a_target
  A <- B$A          
  tind <- B$tind
  ngrp <- length(tind)-1 
  target_beta <- B$beta
  beta_nonzero_pos <- which(abs(target_beta) != 0)  
  
  mu_vec_target <- c(rep(log(p / 2), 5), rep(0, p - 5))
  
  Sigma <- matrix(0, nrow=p, ncol=p)
  for (i in 1:p) {
    for (j in 1:p) {
      Sigma[i,j] <- 0.5^abs(i - j)
    }
  }
  
  X_combined <- matrix(nrow = 0, ncol = p)
  Z_combined <- matrix(nrow = 0, ncol = p)   
  N_combined <- matrix(nrow = 0, ncol = p_n)
  y_combined <- numeric(0)
  y_z_combined <- numeric(0)  
  X_test_combined <- matrix(nrow = 0, ncol = p)
  Z_test_combined <- matrix(nrow = 0, ncol = p) 
  N_test_combined <- matrix(nrow = 0, ncol = p_n)
  y_test_combined <- numeric(0)
  y_test_z_combined <- numeric(0)  
  
  N_target <- if (p_n == 0) {
    matrix(nrow = n.vec[1], ncol = 0) 
  } else {
    mat <- matrix(1, nrow = n.vec[1], ncol = p_n)
    if (p_n > 1) {
      mat[, -1] <- matrix(rbinom(n.vec[1] * (p_n - 1), size = 1, prob = 0.5), n.vec[1], p_n - 1)
    }
    colnames(mat) <- paste0("N", 1:p_n)
    mat
  }
  x_target_raw <- mvrnorm(n.vec[1], mu = mu_vec_target, Sigma = Sigma)
  exp_x_target <- exp(x_target_raw) 
  C_total_target <- exp_x_target / rowSums(exp_x_target) 
  x_target <- log(C_total_target)
  prod_target <- apply(C_total_target, 1, function(row) prod(row) + 1e-8)
  z_target <- log(C_total_target / prod_target)
  if (p_n == 0) {
    y_target <- as.vector(x_target %*% target_beta)
  } else {
    y_target <- as.vector(N_target %*% a_target + x_target %*% target_beta)
  }
  y_target_z <- as.vector(
    if (p_n == 0) z_target %*% target_beta
    else N_target %*% a_target + z_target %*% target_beta
  )
  sigma_target <- norm(matrix(y_target), "2") / sqrt(n.vec[1]) / snr 
  y_target <- y_target + sigma_target * rnorm(n.vec[1])
  y_target_z <- y_target_z + sigma_target * rnorm(n.vec[1])
  
  x_target_test_raw <- mvrnorm(n.vec[1], mu = mu_vec_target, Sigma = Sigma)
  exp_x_target_test <- exp(x_target_test_raw)
  C_total_target_test <- exp_x_target_test / rowSums(exp_x_target_test)
  x_target_test <- log(C_total_target_test)
  prod_target_test <- apply(C_total_target_test, 1, function(row) prod(row) + 1e-8)
  z_target_test <- log(C_total_target_test / prod_target_test)
  N_target_test <- if (p_n == 0) {
    matrix(nrow = n.vec[1], ncol = 0)
  } else {
    mat <- matrix(1, nrow = n.vec[1], ncol = p_n)
    if (p_n > 1) {
      mat[, -1] <- matrix(rbinom(n.vec[1] * (p_n - 1), size = 1, prob = 0.5), n.vec[1], p_n - 1)
    }
    colnames(mat) <- paste0("N", 1:p_n)
    mat
  }
  if (p_n == 0) {
    y_target_test <- as.vector(x_target_test %*% target_beta)
  } else {
    y_target_test <- as.vector(N_target_test %*% a_target + x_target_test %*% target_beta)
  }
  y_target_test_z <- as.vector(
    if (p_n == 0) z_target_test %*% target_beta
    else N_target_test %*% a_target + z_target_test %*% target_beta
  )
  sigma_target_test <- norm(matrix(y_target_test), "2") / sqrt(n.vec[1]) / snr # 方法2
  y_target_test <- y_target_test + sigma_target_test * rnorm(n.vec[1])
  y_target_test_z <- y_target_test_z + sigma_target * rnorm(n.vec[1])
  
  X_combined <- rbind(X_combined, x_target) 
  Z_combined <- rbind(Z_combined, z_target)     
  N_combined <- rbind(N_combined, N_target) 
  y_combined <- c(y_combined, y_target) 
  y_z_combined <- c(y_z_combined, y_target_z)
  X_test_combined <- rbind(X_test_combined, x_target_test) 
  Z_test_combined <- rbind(Z_test_combined, z_target_test)  
  N_test_combined <- rbind(N_test_combined, N_target_test) 
  y_test_combined <- c(y_test_combined, y_target_test) 
  y_test_z_combined <- c(y_test_z_combined, y_target_test_z)
  
  for (k in 1:M) {
    set.seed(seed + k)
    source_beta <- B$W[,k] 
    source_a <- A[,k] 
    N_source <- if (p_n == 0) {
      matrix(nrow = n.vec[k+1], ncol = 0)
    } else {
      mat <- matrix(1, nrow = n.vec[k+1], ncol = p_n)
      if (p_n > 1) {
        mat[, -1] <- matrix(rbinom(n.vec[k+1] * (p_n - 1), size = 1, prob = 0.5), n.vec[k+1], p_n - 1)
      }
      colnames(mat) <- paste0("N", 1:p_n)
      mat
    }
    source_beta_nonzero_pos <- which(abs(source_beta) != 0)
    mu_vec_source <- c(rep(log(p / 2), 5), rep(0, p - 5))
    
    x_source_raw <- mvrnorm(n.vec[k+1], mu = mu_vec_source, Sigma = Sigma)
    exp_x_source <- exp(x_source_raw)
    C_total_source <- exp_x_source / rowSums(exp_x_source)
    x_source <- log(C_total_source)
    prod_source <- apply(C_total_source, 1, function(row) prod(row) + 1e-8)
    z_source <- log(C_total_source / prod_source)
    
    if (p_n == 0) {
      y_source <- as.vector(x_source %*% source_beta)
    } else {
      y_source <- as.vector(N_source %*% source_a + x_source %*% source_beta)
    }
    y_source_z <- as.vector(
      if (p_n == 0) z_source %*% source_beta
      else N_source %*% source_a + z_source %*% source_beta
    )
    sigma_source <- norm(matrix(y_source), "2") / sqrt(n.vec[k+1]) / snr 
    y_source <- y_source + sigma_source * rnorm(n.vec[k+1])
    y_source_z <- y_source_z + sigma_target * rnorm(n.vec[k+1])
    
    X_combined <- rbind(X_combined, x_source) 
    Z_combined <- rbind(Z_combined, z_source)    
    N_combined <- rbind(N_combined, N_source) 
    y_combined <- c(y_combined, y_source) 
    y_z_combined <- c(y_z_combined, y_source_z)
    
    cat("source", k, "done\n")
  }
  
  data_train <- list(
    X = X_combined,        
    Z = Z_combined,    
    N = N_combined,      
    y = y_combined,        
    y_z = y_z_combined,      
    target_beta = target_beta,
    target_a = a_target,    
    tind = tind             
  )
  data_test <- list(
    X = X_test_combined,    
    Z = Z_test_combined,
    N = N_test_combined,     
    y = y_test_combined,      
    y_z = y_test_z_combined   
  )
  
  return(list(data_train = data_train, data_test = data_test))
}

compute_lambda_init <- function(data_train, snr=10) {
  X <- data_train$X
  y <- data_train$y - mean(data_train$y)
  n <- nrow(X)
  ngrp <- length(data_train$tind)-1
  scale_grp <- sqrt(log(ngrp + 1))
  lambda_init <- max(abs(t(X) %*% y))/ n / scale_grp * ifelse(snr<5,1.3,1.0)
  max(lambda_init, 1e-10) 
}


model_evaluation <- function(est_a, 
                             true_a = NULL, 
                             est_beta, 
                             true_beta, 
                             fit_model = NULL, 
                             se_beta = NULL,   
                             y_test = NULL, 
                             X_test = NULL, 
                             N_test = NULL,
                             p_val_threshold = 0.05) {
  
  if (length(est_beta) != length(true_beta)) {
    stop("length(est_beta) != length(true_beta)")
  }
  if (!is.null(true_a)) {
    if (length(est_a) != length(true_a)) {
      stop("length(est_a) != length(true_a)")
    }
  }
  
  if (!is.null(N_test)) {
    p_n <- ncol(N_test)
    if (is.null(p_n) || p_n == 1 || is.vector(N_test)) {
      N_test <- as.matrix(N_test, ncol = 1)
      p_n <- 1
    }
  } else {
    p_n <- NA
  }
  
  del <- est_beta - true_beta
  l1   <- sum(abs(del))
  l2   <- sqrt(sum(del^2))
  linf <- max(abs(del))
  mse_beta <- mean(del^2)
  
  if (!is.null(true_a)) {
    del_a <- est_a - true_a
    l1_a   <- sum(abs(del_a))
    l2_a   <- sqrt(sum(del_a^2))
    linf_a <- max(abs(del_a))
    mse_a  <- mean(del_a^2)
  } else {
    del_a <- NA
    l1_a <- l2_a <- linf_a <- mse_a <- NA
  }
  
  del_total <- c(del_a, del)
  l1_total   <- sum(abs(del_total))
  l2_total   <- sqrt(sum(del_total^2))
  linf_total <- max(abs(del_total))
  
  weight_a <- length(del_a) / length(del_total)
  weight_beta <- length(del) / length(del_total)
  mse_total  <- (mse_a * weight_a) + (mse_beta * weight_beta)
  
  fp <- fn <- fdp <- NA
  selected <- rep(FALSE, length(est_beta))
  p_val <- rep(NA, length(est_beta))   
  
  
  if(length(est_beta) > 0){
    
    est_nonzero  <- est_beta != 0
    true_nonzero <- true_beta != 0
    
    selected <- est_nonzero
    
    fp <- sum(est_nonzero & !true_nonzero, na.rm = TRUE)
    fn <- sum(!est_nonzero & true_nonzero, na.rm = TRUE)
    s  <- sum(est_nonzero, na.rm = TRUE)
    fdp <- ifelse(s == 0, 0, fp / s)
    
    p_val <- rep(NA, length(est_beta))
    
  } else {
    warning("No compositional coefficients in the model; variable selection metrics are returned as NA.")
  }
  
  if (!is.null(y_test) && !is.null(X_test) && !is.null(N_test)) {
    y_pred <- as.vector(
      N_test %*% est_a +
        X_test %*% est_beta
    )
    pe <- mean((y_test - y_pred)^2)
  } else {
    pe <- NA
  }
  
  return(list(
    l1_a = l1_a,
    l2_a = l2_a,
    linf_a = linf_a,
    l1 = l1,
    l2 = l2,
    linf = linf,
    l1_total = l1_total,
    l2_total = l2_total,
    linf_total = linf_total,
    fn = fn,
    fp = fp,
    fdp = fdp,
    pe = pe
  ))
}









