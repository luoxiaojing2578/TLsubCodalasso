# Trans-Coda-Lasso-l0-old(HTC-ℓ0)

library(L0Learn)

Rcpp::sourceCpp("cclasso1.cpp")

classol0_old <- function(data, p, lam0 = NULL, maxiter = 5000, 
                         tol = 1e-8, mu = 1, nu = 1.05, seed = 2025,
                         constraint_type = "sub", sparse_level = 10) { 
  set.seed(seed) 
  
  X <- data$X 
  N <- data$N  
  y <- data$y 
  tind <- data$tind
  p_n <- if (is.null(dim(N))) 0 else ncol(N)
  
  Z <- cbind(N, X)
  n <- nrow(Z)
  p_total <- ncol(Z) 
  
  C <- NULL
  if (constraint_type == "sub") {
    ngrp <- length(tind)-1
    C <- matrix(0, ngrp, p_total)
    for (ii in 1:ngrp) {
      C[ii, (p_n + tind[ii] + 1):(p_n + tind[ii + 1])] <- 1
    }
  } else if (constraint_type == "single") {
    ngrp <- 1
    C <- matrix(0, ngrp, p_total)
    C[, (p_n + 1):p_total] <- 1 
  }
  
  if (p_n == 0) {
    we <- rep(1, p)
  } else {
    we <- c(0, rep(1, p_n - 1), rep(1, p))
  }
  intercept_index <- if (p_n > 0) 1 else NA
  
  Zt <- Z  
  Zt <- crossprod(t(Zt), subtract(diag(1, p_total, p_total), svd(t(C))$u %>% tcrossprod()))
  xmean <- colMeans(Zt)
  if (p_n > 0) xmean[intercept_index] <- 0
  sfac <- apply(Zt, 2, sd)
  sfac[sfac == 0] <- 1 
  if (p_n > 0) sfac[intercept_index] <- 1
  sfac[sfac < 1e-6] <- 1e-6 
  sfac <- drop(1 / sfac) 
  Zt <- t(t(Zt) - xmean) * rep(sfac, each = n) 
  C <- C * rep(sfac, each = nrow(C)) 
  y_orig <- y
  if (p_n > 0) {
    mu_y <- mean(y_orig)
    y <- y_orig - mu_y
  } else {
    mu_y <- 0
    y <- y_orig
  }
  model_res <- classo_l0(Zt, y, C, we, lam0, maxiter, tol, mu, nu, sparse_level = sparse_level) 
  
  tem <- model_res$beta * sfac  
  if (p_n > 0) {
    offset <- sum(tem[(p_n + 1):p_total] * xmean[(p_n + 1):p_total])
  } else {
    offset <- 0
  }
  if (p_n > 0) {
    a_est <- (mu_y + tem[1:p_n]) - offset
  } else {
    a_est <- numeric(0)
  }
  beta_est <- tem[(p_n + 1):p_total]
  
  if (p_n > 0) {
    y_train_pred <- as.vector(N %*% a_est + X %*% beta_est)
  } else {
    y_train_pred <- as.vector(X %*% beta_est)
  }
  resid <- y_orig - y_train_pred
  train_mse <- mean(resid^2)
  
  sigma2_est = mean(resid^2) 
  df_est = sum(abs(beta_est) > 1e-8) 
  n_sample = nrow(X) 
  se_beta = sqrt(sigma2_est / (n_sample - df_est))
  se_a = sqrt(sigma2_est / (n_sample - df_est))  
  se_beta_vec = rep(se_beta, length(beta_est))  
  se_a_vec = rep(se_a, length(a_est))           
  names(se_beta_vec) = colnames(X)             
  #names(se_a_vec) = colnames(N)                
  if (length(a_est) > 0 && !is.null(colnames(N))) {
    names(se_a_vec) <- colnames(N)
  }
  se_full = c(se_a_vec, se_beta_vec)           
  
  return(list(a = a_est, 
              beta = beta_est, 
              beta_full = c(a_est, beta_est),  
              lam0 = lam0,
              sigma2 = sigma2_est,
              df = df_est,
              y_pred = y_train_pred,
              N = N,
              X = X,
              y_orig = y_orig,
              se_a = se_a_vec,       
              se_beta = se_beta_vec, 
              se_full = se_full    
  )) 
}

cv_classol0_old <- function(data, p, lam0_seq, nfold = 10,
                            maxiter = 5000, tol = 1e-8, mu = 1, nu = 1.05, 
                            seed = 2025, constraint_type = "sub", type = "min", sparse_level = 10) {
  set.seed(seed)
  
  X <- data$X
  N <- data$N      
  y <- data$y
  tind <- data$tind
  n <- length(y)
  p_original <- ncol(X)
  p_n <- if (is.null(dim(N))) 0 else ncol(N)
  
  if (p_n > 0 && (p_n == 1 || is.vector(N))) {
    N <- as.matrix(N, ncol = 1)
    p_n <- 1
  }
  
  foldid <- sample(rep(1:nfold, length.out = n))
  
  pred <- matrix(NA, nrow = nfold, ncol = length(lam0_seq))
  valid_n <- numeric(nfold) 
  
  for (i in 1:nfold) {
    train_idx <- which(foldid != i)
    valid_idx <- which(foldid == i)
    valid_n[i] <- length(valid_idx)
    y_train <- y[train_idx]
    X_train <- X[train_idx, , drop = FALSE]
    y_valid <- y[valid_idx]
    X_valid <- X[valid_idx, , drop = FALSE]
    N_train <- N[train_idx, , drop = FALSE]
    N_valid <- N[valid_idx, , drop = FALSE]
    
    data_train_fold <- list(
      X = X_train,
      N = N_train,      
      y = y_train,
      tind = tind
    )
    
    for (j in seq_along(lam0_seq)) {
      lam0_j <- lam0_seq[j]
      fit_j <- classol0_old(
        data = data_train_fold,
        p = p,
        lam0 = lam0_j,
        maxiter = maxiter,
        tol = tol,
        mu = mu,
        nu = nu,
        seed = seed + i + j, 
        constraint_type = constraint_type,
        sparse_level = sparse_level
      )
      
      if (p_n > 0) {
        y_valid_pred <- as.vector(
          N_valid %*% fit_j$a +
            X_valid %*% fit_j$beta
        )
      } else {
        y_valid_pred <- as.vector(X_valid %*% fit_j$beta)
      }
      valid_sse <- sum((y_valid - y_valid_pred)^2)
      pred[i, j] <- valid_sse
    }
    
    
  }
  
  pred_mse <- t(t(pred) / valid_n)
  weights <- valid_n / sum(valid_n)
  cvm <- colSums(pred_mse * weights, na.rm = TRUE) 
  cvse <- apply(pred_mse, 2, function(col) {
    valid_vals <- col[!is.na(col)]
    if (length(valid_vals) < 2) return(NA)
    sd(valid_vals) / sqrt(length(valid_vals))
  })
  
  imin <- which.min(cvm)
  if (type == "1se") {
    ilam <- which(cvm <= cvm[imin] + cvse[imin])[1]
  } else {
    ilam <- imin
  }
  lam_best <- lam0_seq[ilam]
  
  data_full <- list(
    X = X,         
    N = N,      
    y = y,      
    tind = tind   
  )
  
  fit_best <- classol0_old(
    data = data_full,
    p = p,
    lam0 = lam_best,
    maxiter = maxiter,
    tol = tol,
    mu = mu,
    nu = nu,
    seed = seed,
    constraint_type = constraint_type,
    sparse_level = sparse_level
  )
  
  return(list(
    a = fit_best$a,            
    beta = fit_best$beta,       
    lam0_best = lam_best,       
    lam0_seq = lam0_seq,      
    cvm = cvm,                 
    cvse = cvse,              
    foldid = foldid,         
    fit_best = fit_best,        
    se_a = fit_best$se_a,     
    se_beta = fit_best$se_beta   
  ))
}

Oracle.subCodalassol0_old <- function(X, N, y, tind, A0, n.vec, nfold = 10, 
                                      maxiter=5000, tol=1e-8, mu=1, nu=1.05, seed=2025,
                                      constraint_type = "sub", lam0_seq, sparse_level = 10) {  
  p<-ncol(X)  
  p_n <- if (is.null(dim(N))) 0 else ncol(N)
  if (length(A0) == 2 && all(A0 == c(1, 0))) {  
    A0 <- integer(0)  
  }  
  size.A0<- length(A0) 
  a.KA <- numeric(p_n)   
  a.udb <- numeric(p_n)  
  
  if(size.A0 > 0){ 
    k.vec <- c(1, A0+1)  
    ind.kA <- NULL    
    for(k in k.vec){ 
      if(k==1){ 
        ind.kA <- c(ind.kA, 1:n.vec[1]) 
      }else{ 
        ind.kA <- c(ind.kA, (sum(n.vec[1:(k-1)])+1):sum(n.vec[1:k]))
      }
    }
    ind.1<-1:n.vec[1]
    data.kA <- list(
      X = X[ind.kA, , drop = FALSE],   
      N = N[ind.kA, , drop = FALSE],    
      y = y[ind.kA],    
      tind = tind
    )
    
    w <- cv_classol0_old(
      data = data.kA,
      p = p,
      lam0_seq = lam0_seq,
      nfold = nfold,
      maxiter = maxiter,
      tol = tol,
      mu = mu,
      nu = nu,
      seed = seed,
      constraint_type = constraint_type,
      type = "1se",
      sparse_level = sparse_level
    )
    a.udb <- as.numeric(w$a) 
    w.kA <- as.numeric(w$beta)  
    se_w_kA <- w$se_beta        
    se_w_a <- w$se_a          
    
    if (p_n > 0) {
      y_pred_w <- as.vector(
        N[ind.1, , drop = FALSE] %*% a.udb +
          X[ind.1, , drop = FALSE] %*% w.kA
      )
    } else {
      y_pred_w <- as.vector(X[ind.1, , drop = FALSE] %*% w.kA)
    }
    res <- as.numeric(y[ind.1] - y_pred_w) 
    data.delta <- list(
      X = X[ind.1, , drop = FALSE],    
      N = N[ind.1, , drop = FALSE],   
      y = res,                       
      tind = tind
    )
    
    delta <- cv_classol0_old(
      data = data.delta,
      p = p,
      lam0_seq = lam0_seq,
      nfold = nfold,
      maxiter = maxiter,
      tol = tol,
      mu = mu,
      nu = nu,
      seed = seed,
      constraint_type = constraint_type,
      #type = "1se"
      sparse_level = sparse_level
    )
    a.delta <- as.numeric(delta$a)     
    delta.kA <- as.numeric(delta$beta) 
    se_delta_kA <- delta$se_beta       
    se_delta_a <- delta$se_a          
    
    beta.kA <- w.kA + delta.kA   
    a.KA <- a.udb + a.delta    
    se_beta_kA <- sqrt(se_w_kA^2 + se_delta_kA^2)
    se_a_KA <- sqrt(se_w_a^2 + se_delta_a^2)
    names(se_beta_kA) = colnames(X)
    if (p_n > 0 && !is.null(colnames(N))) names(se_a_KA) <- colnames(N)
  }else{ 
    ind.1 <- 1:n.vec[1] 
    data.kA <- list(
      X = X[ind.1, , drop = FALSE],
      N = N[ind.1, , drop = FALSE],
      y = y[ind.1],
      tind = tind
    )
    w <- cv_classol0_old(
      data = data.kA,
      p = p,
      lam0_seq = lam0_seq,
      nfold = nfold,
      maxiter = maxiter,
      tol = tol,
      mu = mu,
      nu = nu,
      seed = seed,
      constraint_type = constraint_type,
      type = "1se",
      sparse_level = sparse_level
    )
    
    a.udb <- as.numeric(w$a)
    w.kA <- as.numeric(w$beta)
    se_w_kA <- w$se_beta
    se_w_a <- w$se_a
    
    
    if (p_n > 0) {
      y_pred_w <- as.vector(
        N[ind.1, , drop = FALSE] %*% a.udb +
          X[ind.1, , drop = FALSE] %*% w.kA
      )
    } else {
      y_pred_w <- as.vector(X[ind.1, , drop = FALSE] %*% w.kA)
    }
    
    res <- as.numeric(y[ind.1] - y_pred_w)
    
    data.delta <- list(
      X = X[ind.1, , drop = FALSE],
      N = N[ind.1, , drop = FALSE],
      y = res,
      tind = tind
    )
    
    delta <- cv_classol0_old(
      data = data.delta,
      p = p,
      lam0_seq = lam0_seq,
      nfold = nfold,
      maxiter = maxiter,
      tol = tol,
      mu = mu,
      nu = nu,
      seed = seed,
      constraint_type = constraint_type,
      sparse_level = sparse_level
    )
    
    a.delta <- as.numeric(delta$a)
    delta.kA <- as.numeric(delta$beta)
    se_delta_kA <- delta$se_beta
    se_delta_a <- delta$se_a
    
    
    beta.kA <- w.kA + delta.kA
    a.KA <- a.udb + a.delta
    
    se_beta_kA <- sqrt(se_w_kA^2 + se_delta_kA^2)
    se_a_KA <- sqrt(se_w_a^2 + se_delta_a^2)
    names(se_beta_kA) = colnames(X)
    if (p_n > 0 && !is.null(colnames(N))) names(se_a_KA) <- colnames(N)
  }
  
  return(list(beta = as.numeric(beta.kA), 
              a = a.KA,
              beta.udb = w.kA, 
              a.udb = a.udb, 
              se_beta = se_beta_kA,      
              se_a = se_a_KA,        
              se_beta_udb = se_w_kA,  
              se_a_udb = se_w_a       
  ))            
}

