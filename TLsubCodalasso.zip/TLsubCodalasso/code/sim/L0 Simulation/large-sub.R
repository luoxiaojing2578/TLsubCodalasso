# Simulation-large-rho05-sub

library(glmtrans)    
library(glmnet)   
library(dplyr)    
library(writexl)
source("data_eval-large-rho05-sub.R")
source("Func-TransCodaLasso.R")
source("Func-TranssubCodaLassol0new.R")
source("Func-TransCodaLassol0old.R")
source("Func-TransLasso1.R")  

total_time_start <- Sys.time()

###################### Experimental Setup ######################
n_target <- 100   
n_source_per <- 100 
M <- 20           
n.vec <- c(n_target, rep(n_source_per, M)) 
size.A0_list <- c(2,4,8)
p <- 100           
p_n <- 0         
nsim <- 100        
sig.delta1_list <- c(0.05)
sig.delta2 <- 1  
sig.delta_a1 <- 0.05
sig.delta_a2 <- 1
num_perturbed_groups_list <- c(1)  
snr <- 3           
h <- 2
q <- 2
exact <- F
epsilon <- 0.01
maxiter = 5000
tol = 1e-8
mu = 1
nu = 1.05
seed <- 2025       

sim_results <- data.frame(
  sig.delta1 = numeric(), 
  size.A0 = integer(),  
  num_perturbed_groups = integer(),  
  sim_id = integer(),
  model = character(),              
  runtime = numeric(),              
  l1_a = numeric(),    
  l2_a = numeric(),  
  linf_a = numeric(),  
  l1 = numeric(),
  l2 = numeric(),
  linf = numeric(),
  l1_total = numeric(), 
  l2_total = numeric(), 
  linf_total = numeric(),
  fn = integer(),
  fp = integer(),
  fdp = numeric(),
  pe = numeric()
)

beta_results <- data.frame(
  sig.delta1 = numeric(),
  size.A0 = integer(),
  num_perturbed_groups = integer(),
  sim_id = integer(),
  model = character(),
  beta_index = integer(),
  beta_value = numeric()
)

save_beta_results <- function(beta_df, sig.delta1, size.A0, num_perturbed_groups, sim_id, model, beta_vec) {
  beta_vec <- as.numeric(beta_vec)
  tmp <- data.frame(
    sig.delta1 = rep(sig.delta1, length(beta_vec)),
    size.A0 = rep(size.A0, length(beta_vec)),
    num_perturbed_groups = rep(num_perturbed_groups, length(beta_vec)),
    sim_id = rep(sim_id, length(beta_vec)),
    model = rep(model, length(beta_vec)),
    beta_index = seq_along(beta_vec),
    beta_value = beta_vec
  )
  rbind(beta_df, tmp)
}

subcomp_alr_from_logx <- function(logx, tind) {
  logx <- as.matrix(logx) 
  alr_list <- vector("list", length(tind) - 1) 
  for (g in 1:(length(tind) - 1)) { 
    idx <- (tind[g] + 1):tind[g + 1] 
    xg <- logx[, idx, drop = FALSE] 
    ref_col <- xg[, ncol(xg), drop = FALSE] 
    if (ncol(xg) == 1) { 
      alr_list[[g]] <- matrix(0, nrow = nrow(logx), ncol = 0) 
    } else {
      alr_list[[g]] <- sweep(xg[, -ncol(xg), drop = FALSE], 1, ref_col[, 1], "-") 
      
    }
  }
  out <- do.call(cbind, alr_list) 
  out
}

alr_to_beta_subcomp <- function(gamma, tind) {
  gamma <- as.numeric(gamma) 
  beta <- numeric(tind[length(tind)])
  pos <- 1 
  for (g in 1:(length(tind) - 1)) { 
    idx <- (tind[g] + 1):tind[g + 1] 
    m_g <- length(idx) 
    if (m_g == 1) {
      beta[idx] <- 0
    } else {
      gamma_g <- gamma[pos:(pos + m_g - 2)] 
      beta[idx[1:(m_g - 1)]] <- gamma_g 
      beta[idx[m_g]] <- -sum(gamma_g) 
      pos <- pos + m_g - 1
    }
  }
  beta
}

###################### Simulation ######################
for (sim in 1:nsim) {
  cat("\n===========================================\n")
  cat("sim =", sim, "\n")
  cat("===========================================\n")
  
  for (sig.delta1 in sig.delta1_list) {
    cat("\n===========================================\n")
    cat("sig.delta1 =", sig.delta1, "\n")
    cat("===========================================\n")
    
    for (num_perturbed_groups in num_perturbed_groups_list) {
      cat("\n===========================================\n")
      cat("num_perturbed_groups =", num_perturbed_groups, "\n")
      cat("===========================================\n")
      
      for (size.A0 in size.A0_list) {
        cat("\n===========================================\n")
        cat("sim =", sim, ", size.A0 =", size.A0, "\n")
        cat("===========================================\n")
        
        B <- Coef.gen(
          h=h, q=q, 
          size.A0=size.A0, 
          M=M, 
          sig.delta1=sig.delta1, 
          sig.delta2=sig.delta2, 
          p=p, 
          exact=exact,
          seed = seed,
          p_n=p_n,
          sig.delta_a1 = sig.delta_a1, 
          sig.delta_a2 = sig.delta_a2,
          num_perturbed_groups = num_perturbed_groups
        )
        
        all_data <- Data.gen(
          n.vec = n.vec,
          M = M,
          p = p,
          B = B,
          snr = snr,
          seed = seed + sim
        )
        
        lambda_init <- compute_lambda_init(all_data$data_train, snr=10)
        lam0_seq <- exp(seq(log(lambda_init*0.005), log(lambda_init*0.5), length.out=50)) # lam1
        #lam0_seq <- exp(seq(log(lambda_init*0.05), log(lambda_init*0.25), length.out=50)) # lam2
        #lam0_seq <- exp(seq(log(lambda_init*0.1), log(lambda_init*1), length.out=50))  # lam3
        lam0_seq <- unique(sort(lam0_seq, decreasing=TRUE))
        
        # classo(targetonly)
        cat("sim =", sim, ", size.A0 =", size.A0, "\n")
        cat("classo\n")
        classo_data <- list(
          X = all_data$data_train$X[1:n.vec[1], ],  
          y = all_data$data_train$y[1:n.vec[1]],    
          N = all_data$data_train$N[1:n.vec[1], ], 
          tind = all_data$data_train$tind
        )
        time_classo <- system.time(fit_classo <- cv_classo(
          data = classo_data,
          p = p,
          lam0_seq = lam0_seq,
          maxiter = maxiter,
          tol = tol,
          mu = mu,
          nu = nu,
          seed = seed + sim,
          constraint_type = "sub"
        ))[3]
        
        eval_classo <- model_evaluation(
          est_a = fit_classo$a,
          true_a = all_data$data_train$target_a,
          est_beta = fit_classo$beta,  
          true_beta     = all_data$data_train$target_beta, 
          se_beta = fit_classo$se_beta,
          y_test        = all_data$data_test$y[1:n.vec[1]], 
          X_test        = all_data$data_test$X[1:n.vec[1], ], 
          N_test = all_data$data_test$N[1:n.vec[1], ]
        )
        sim_results <- rbind(sim_results, data.frame(
          sig.delta1 = sig.delta1,
          size.A0 = size.A0,
          num_perturbed_groups = num_perturbed_groups,
          sim_id = sim,
          model = "classo",
          runtime = time_classo,
          l1_a = eval_classo$l1_a,
          l2_a = eval_classo$l2_a,
          linf_a = eval_classo$linf_a,
          l1 = eval_classo$l1,
          l2 = eval_classo$l2,
          linf = eval_classo$linf,
          l1_total = eval_classo$l1_total,
          l2_total = eval_classo$l2_total,
          linf_total = eval_classo$linf_total,
          fn = eval_classo$fn,
          fp = eval_classo$fp,
          fdp = eval_classo$fdp,
          pe = eval_classo$pe
        ))
        beta_results <- save_beta_results(beta_results, sig.delta1, size.A0, num_perturbed_groups, sim, "classo", fit_classo$beta)
        
        
        # Oracle.subCodalasso
        cat("sim =", sim, ", size.A0 =", size.A0, "\n")
        cat("Oracle.subCodalasso\n")
        time_oraclesubCodalasso <- system.time(fit_oraclesubCodalasso <- Oracle.subCodalasso(
          X = all_data$data_train$X,      
          y = all_data$data_train$y,       
          N = all_data$data_train$N,  
          tind = all_data$data_train$tind, 
          A0 = 1:size.A0,                 
          n.vec = n.vec,                       
          maxiter = maxiter,
          tol = tol,
          mu = mu,
          nu = nu,
          seed = seed + sim,                   
          constraint_type = "sub",
          lam0_seq = lam0_seq
        ))[3]
        
        eval_oraclesubCodalasso <- model_evaluation(
          est_a = fit_oraclesubCodalasso$a,
          true_a = all_data$data_train$target_a,
          est_beta = fit_oraclesubCodalasso$beta,
          true_beta     = all_data$data_train$target_beta,  
          se_beta = fit_oraclesubCodalasso$se_beta,
          y_test        = all_data$data_test$y[1:n.vec[1]], 
          X_test        = all_data$data_test$X[1:n.vec[1], ], 
          N_test = all_data$data_test$N[1:n.vec[1], ]
        )
        
        sim_results <- rbind(sim_results, data.frame(
          sig.delta1 = sig.delta1,
          size.A0 = size.A0,
          num_perturbed_groups = num_perturbed_groups,
          sim_id = sim,
          model = "Oracle.subCodalasso",
          runtime = time_oraclesubCodalasso,
          l1_a = eval_oraclesubCodalasso$l1_a,
          l2_a = eval_oraclesubCodalasso$l2_a,
          linf_a = eval_oraclesubCodalasso$linf_a,
          l1 = eval_oraclesubCodalasso$l1,
          l2 = eval_oraclesubCodalasso$l2,
          linf = eval_oraclesubCodalasso$linf,
          l1_total = eval_oraclesubCodalasso$l1_total,
          l2_total = eval_oraclesubCodalasso$l2_total,
          linf_total = eval_oraclesubCodalasso$linf_total,
          fn = eval_oraclesubCodalasso$fn,
          fp = eval_oraclesubCodalasso$fp,
          fdp = eval_oraclesubCodalasso$fdp,
          pe = eval_oraclesubCodalasso$pe
        ))
        beta_results <- save_beta_results(beta_results, sig.delta1, size.A0, num_perturbed_groups, sim, "Oracle.subCodalasso", fit_oraclesubCodalasso$beta)
        
        
        # Oracle.subCodalassol0_old
        cat("sim =", sim, ", size.A0 =", size.A0, "\n")
        cat("Oracle.subCodalassol0_old\n")
        
        time_oraclesubCodalassol0_old <- system.time(fit_oraclesubCodalassol0_old <- Oracle.subCodalassol0_old(
          X = all_data$data_train$X,      
          y = all_data$data_train$y,       
          N = all_data$data_train$N, 
          tind = all_data$data_train$tind, 
          A0 = 1:size.A0,           
          n.vec = n.vec,                 
          maxiter = maxiter,
          tol = tol,
          mu = mu,
          nu = nu,
          seed = seed + sim,                 
          constraint_type = "sub",
          lam0_seq = lam0_seq
        ))[3]
        
        eval_oraclesubCodalassol0_old <- model_evaluation(
          est_a = fit_oraclesubCodalassol0_old$a,
          true_a = all_data$data_train$target_a,
          est_beta = fit_oraclesubCodalassol0_old$beta,
          true_beta     = all_data$data_train$target_beta, 
          se_beta = fit_oraclesubCodalassol0_old$se_beta,
          y_test        = all_data$data_test$y[1:n.vec[1]], 
          X_test        = all_data$data_test$X[1:n.vec[1], ],
          N_test = all_data$data_test$N[1:n.vec[1], ]
        )
        
        sim_results <- rbind(sim_results, data.frame(
          sig.delta1 = sig.delta1,
          size.A0 = size.A0,
          num_perturbed_groups = num_perturbed_groups,
          sim_id = sim,
          model = "Oracle.subCodalassol0_old",
          runtime = time_oraclesubCodalassol0_old,
          l1_a = eval_oraclesubCodalassol0_old$l1_a,
          l2_a = eval_oraclesubCodalassol0_old$l2_a,
          linf_a = eval_oraclesubCodalassol0_old$linf_a,
          l1 = eval_oraclesubCodalassol0_old$l1,
          l2 = eval_oraclesubCodalassol0_old$l2,
          linf = eval_oraclesubCodalassol0_old$linf,
          l1_total = eval_oraclesubCodalassol0_old$l1_total,
          l2_total = eval_oraclesubCodalassol0_old$l2_total,
          linf_total = eval_oraclesubCodalassol0_old$linf_total,
          fn = eval_oraclesubCodalassol0_old$fn,
          fp = eval_oraclesubCodalassol0_old$fp,
          fdp = eval_oraclesubCodalassol0_old$fdp,
          pe = eval_oraclesubCodalassol0_old$pe
        ))
        beta_results <- save_beta_results(beta_results, sig.delta1, size.A0, num_perturbed_groups, sim, "Oracle.subCodalassol0_old", fit_oraclesubCodalassol0_old$beta)

        # Oracle.subCodalassol0
        cat("sim =", sim, ", size.A0 =", size.A0, "\n")
        cat("Oracle.subCodalassol0\n")
        
        time_oraclesubCodalassol0 <- system.time(fit_oraclesubCodalassol0 <- Oracle.subCodalassol0(
          X = all_data$data_train$X,       
          y = all_data$data_train$y,      
          N = all_data$data_train$N, 
          tind = all_data$data_train$tind, 
          A0 = 1:size.A0,                       
          n.vec = n.vec,                  
          maxiter = maxiter,
          tol = tol,
          mu = mu,
          nu = nu,
          seed = seed + sim,                   
          constraint_type = "sub",
          lam0_seq = lam0_seq
        ))[3]
        
        eval_oraclesubCodalassol0 <- model_evaluation(
          est_a = fit_oraclesubCodalassol0$a,
          true_a = all_data$data_train$target_a,
          est_beta = fit_oraclesubCodalassol0$beta,
          true_beta     = all_data$data_train$target_beta,  
          se_beta = fit_oraclesubCodalassol0$se_beta,
          y_test        = all_data$data_test$y[1:n.vec[1]], 
          X_test        = all_data$data_test$X[1:n.vec[1], ],
          N_test = all_data$data_test$N[1:n.vec[1], ]
        )
        
        sim_results <- rbind(sim_results, data.frame(
          sig.delta1 = sig.delta1,
          size.A0 = size.A0,
          num_perturbed_groups = num_perturbed_groups,
          sim_id = sim,
          model = "Oracle.subCodalassol0",
          runtime = time_oraclesubCodalassol0,
          l1_a = eval_oraclesubCodalassol0$l1_a,
          l2_a = eval_oraclesubCodalassol0$l2_a,
          linf_a = eval_oraclesubCodalassol0$linf_a,
          l1 = eval_oraclesubCodalassol0$l1,
          l2 = eval_oraclesubCodalassol0$l2,
          linf = eval_oraclesubCodalassol0$linf,
          l1_total = eval_oraclesubCodalassol0$l1_total,
          l2_total = eval_oraclesubCodalassol0$l2_total,
          linf_total = eval_oraclesubCodalassol0$linf_total,
          fn = eval_oraclesubCodalassol0$fn,
          fp = eval_oraclesubCodalassol0$fp,
          fdp = eval_oraclesubCodalassol0$fdp,
          pe = eval_oraclesubCodalassol0$pe
        ))
        beta_results <- save_beta_results(beta_results, sig.delta1, size.A0, num_perturbed_groups, sim, "Oracle.subCodalassol0", fit_oraclesubCodalassol0$beta)
        
        
        tind_now <- all_data$data_train$tind
        p_n_now <- ncol(all_data$data_train$N)
        if (is.null(p_n_now)) p_n_now <- 0

        X_raw_train <- all_data$data_train$X
        X_raw_test  <- all_data$data_test$X
        X_clr_train <- all_data$data_train$Z
        X_clr_test  <- all_data$data_test$Z
        X_alr_train <- subcomp_alr_from_logx(X_raw_train, tind_now)
        X_alr_test  <- subcomp_alr_from_logx(X_raw_test, tind_now)
        
        # glmtrans_raw(oracle)
        cat("sim =", sim, ", size.A0 =", size.A0, "\n")
        cat("glmtrans_raw(oracle)\n")
        target_glmtrans_raw <- list(
          x = as.matrix(cbind(all_data$data_train$N[1:n.vec[1], , drop = FALSE], X_raw_train[1:n.vec[1], , drop = FALSE])),
          y = as.vector(all_data$data_train$y[1:n.vec[1]])
        )
        source_glmtrans_raw <- vector("list", M)
        start_idx <- n.vec[1] + 1
        for (k in 1:M) {
          end_idx <- start_idx + n.vec[k + 1] - 1
          source_glmtrans_raw[[k]] <- list(
            x = as.matrix(cbind(all_data$data_train$N[start_idx:end_idx, , drop = FALSE], X_raw_train[start_idx:end_idx, , drop = FALSE])),
            y = as.vector(all_data$data_train$y[start_idx:end_idx])
          )
          start_idx <- end_idx + 1
        }
        time_glmtrans_raw <- system.time(
          fit_glmtrans_raw <- glmtrans(
            target = target_glmtrans_raw,
            source = source_glmtrans_raw,
            family = "gaussian",
            transfer.source.id = 1:size.A0,  
            alpha = 1,
            standardize = TRUE,
            intercept = FALSE,
            nfolds = 10,
            cores = 1,
            lambda.seq = list(
              transfer  = lam0_seq,
              debias    = lam0_seq,
              detection = lam0_seq
            ),   
            detection.info = FALSE
          )
        )[3]
        beta_full <- as.numeric(fit_glmtrans_raw$beta)
        if (p_n_now > 0) {
          a_glmtrans_raw   <- beta_full[1:p_n_now]
          beta_glmtrans_raw<- beta_full[(p_n_now + 1):(p_n_now + p)]
        } else {
          a_glmtrans_raw   <- numeric(0)
          beta_glmtrans_raw<- beta_full[1:p]
        }
        eval_glmtrans_raw <- model_evaluation(
          est_a = a_glmtrans_raw,
          true_a = all_data$data_train$target_a,
          est_beta = beta_glmtrans_raw,
          true_beta = all_data$data_train$target_beta,
          y_test = all_data$data_test$y[1:n.vec[1]],
          X_test = X_raw_test[1:n.vec[1], , drop = FALSE],
          N_test = all_data$data_test$N[1:n.vec[1], , drop = FALSE]
        )
        sim_results <- rbind(sim_results, data.frame(
          sig.delta1 = sig.delta1,
          size.A0 = size.A0,
          num_perturbed_groups = num_perturbed_groups,
          sim_id = sim,
          model = "glmtrans_raw",
          runtime = time_glmtrans_raw,
          l1_a = eval_glmtrans_raw$l1_a,
          l2_a = eval_glmtrans_raw$l2_a,
          linf_a = eval_glmtrans_raw$linf_a,
          l1 = eval_glmtrans_raw$l1,
          l2 = eval_glmtrans_raw$l2,
          linf = eval_glmtrans_raw$linf,
          l1_total = eval_glmtrans_raw$l1_total,
          l2_total = eval_glmtrans_raw$l2_total,
          linf_total = eval_glmtrans_raw$linf_total,
          fn = eval_glmtrans_raw$fn,
          fp = eval_glmtrans_raw$fp,
          fdp = eval_glmtrans_raw$fdp,
          pe = eval_glmtrans_raw$pe
        ))
        beta_results <- save_beta_results(
          beta_results,
          sig.delta1,
          size.A0,
          num_perturbed_groups,
          sim,
          "glmtrans_raw",
          beta_glmtrans_raw
        )

        # glmtrans_alr(oracle)
        cat("sim =", sim, ", size.A0 =", size.A0, "\n")
        cat("glmtrans_alr(oracle)\n")
        p_alr <- ncol(X_alr_train)
        target_glmtrans_alr <- list(
          x = as.matrix(cbind(all_data$data_train$N[1:n.vec[1], , drop = FALSE], X_alr_train[1:n.vec[1], , drop = FALSE])),
          y = as.vector(all_data$data_train$y[1:n.vec[1]])  
        )
        source_glmtrans_alr <- vector("list", M)
        start_idx <- n.vec[1] + 1
        for (k in 1:M) {
          end_idx <- start_idx + n.vec[k + 1] - 1
          source_glmtrans_alr[[k]] <- list(
            x = as.matrix(cbind(all_data$data_train$N[start_idx:end_idx, , drop = FALSE], X_alr_train[start_idx:end_idx, , drop = FALSE])),
            y = as.vector(all_data$data_train$y[start_idx:end_idx])
          )
          start_idx <- end_idx + 1
        }
        time_glmtrans_alr <- system.time(
          fit_glmtrans_alr <- glmtrans(
            target = target_glmtrans_alr,
            source = source_glmtrans_alr,
            family = "gaussian",
            transfer.source.id = 1:size.A0, 
            alpha = 1,
            standardize = TRUE,
            intercept = FALSE,
            nfolds = 10,
            cores = 1,
            lambda.seq = list(
              transfer  = lam0_seq,
              debias    = lam0_seq,
              detection = lam0_seq
            ),     
            detection.info = FALSE
          )
        )[3]
        beta_full <- as.numeric(fit_glmtrans_alr$beta)
        if (p_n_now > 0) {
          a_glmtrans_alr     <- beta_full[1:p_n_now]
          gamma_glmtrans_alr <- beta_full[(p_n_now + 1):(p_n_now + p_alr)]
        } else {
          a_glmtrans_alr     <- numeric(0)
          gamma_glmtrans_alr <- beta_full[1:p_alr]
        }
        beta_glmtrans_alr <- alr_to_beta_subcomp(gamma_glmtrans_alr, tind_now)
        eval_glmtrans_alr <- model_evaluation(
          est_a = a_glmtrans_alr,
          true_a = all_data$data_train$target_a,
          est_beta = beta_glmtrans_alr,
          true_beta = all_data$data_train$target_beta,
          y_test = all_data$data_test$y[1:n.vec[1]],
          X_test = X_raw_test[1:n.vec[1], , drop = FALSE], 
          N_test = all_data$data_test$N[1:n.vec[1], , drop = FALSE]
        )
        sim_results <- rbind(sim_results, data.frame(
          sig.delta1 = sig.delta1,
          size.A0 = size.A0,
          num_perturbed_groups = num_perturbed_groups,
          sim_id = sim,
          model = "glmtrans_alr",
          runtime = time_glmtrans_alr,
          l1_a = eval_glmtrans_alr$l1_a,
          l2_a = eval_glmtrans_alr$l2_a,
          linf_a = eval_glmtrans_alr$linf_a,
          l1 = eval_glmtrans_alr$l1,
          l2 = eval_glmtrans_alr$l2,
          linf = eval_glmtrans_alr$linf,
          l1_total = eval_glmtrans_alr$l1_total,
          l2_total = eval_glmtrans_alr$l2_total,
          linf_total = eval_glmtrans_alr$linf_total,
          fn = eval_glmtrans_alr$fn,
          fp = eval_glmtrans_alr$fp,
          fdp = eval_glmtrans_alr$fdp,
          pe = eval_glmtrans_alr$pe
        ))
        beta_results <- save_beta_results(
          beta_results, sig.delta1, size.A0, num_perturbed_groups, sim,
          "glmtrans_alr", beta_glmtrans_alr
        )

        # glmtrans_clr(oracle)
        cat("sim =", sim, ", size.A0 =", size.A0, "\n")
        cat("glmtrans_clr(oracle)\n")
        target_glmtrans_clr <- list(
          x = as.matrix(cbind(all_data$data_train$N[1:n.vec[1], , drop = FALSE], X_clr_train[1:n.vec[1], , drop = FALSE])),
          y = as.vector(all_data$data_train$y_z[1:n.vec[1]]) 
        )
        source_glmtrans_clr <- vector("list", M)
        start_idx <- n.vec[1] + 1
        for (k in 1:M) {
          end_idx <- start_idx + n.vec[k + 1] - 1
          source_glmtrans_clr[[k]] <- list(
            x = as.matrix(cbind(all_data$data_train$N[start_idx:end_idx, , drop = FALSE], X_clr_train[start_idx:end_idx, , drop = FALSE])),
            y = as.vector(all_data$data_train$y_z[start_idx:end_idx])
          )
          start_idx <- end_idx + 1
        }
        time_glmtrans_clr <- system.time(
          fit_glmtrans_clr <- glmtrans(
            target = target_glmtrans_clr,
            source = source_glmtrans_clr,
            family = "gaussian",
            transfer.source.id = 1:size.A0, 
            alpha = 1,
            standardize = TRUE,
            intercept = FALSE,
            nfolds = 10,
            cores = 1,
            lambda.seq = list(
              transfer  = lam0_seq,
              debias    = lam0_seq,
              detection = lam0_seq
            ),    
            detection.info = FALSE
          )
        )[3]
        beta_full <- as.numeric(fit_glmtrans_clr$beta)
        if (p_n_now > 0) {
          a_glmtrans_clr    <- beta_full[1:p_n_now]
          beta_glmtrans_clr <- beta_full[(p_n_now + 1):(p_n_now + p)]
        } else {
          a_glmtrans_clr    <- numeric(0)
          beta_glmtrans_clr <- beta_full[1:p]
        }
        eval_glmtrans_clr <- model_evaluation(
          est_a = a_glmtrans_clr,
          true_a = all_data$data_train$target_a,
          est_beta = beta_glmtrans_clr,
          true_beta = all_data$data_train$target_beta,
          y_test = all_data$data_test$y_z[1:n.vec[1]],
          X_test = X_clr_test[1:n.vec[1], , drop = FALSE],
          N_test = all_data$data_test$N[1:n.vec[1], , drop = FALSE]
        )
        sim_results <- rbind(sim_results, data.frame(
          sig.delta1 = sig.delta1,
          size.A0 = size.A0,
          num_perturbed_groups = num_perturbed_groups,
          sim_id = sim,
          model = "glmtrans_clr",
          runtime = time_glmtrans_clr,
          l1_a = eval_glmtrans_clr$l1_a,
          l2_a = eval_glmtrans_clr$l2_a,
          linf_a = eval_glmtrans_clr$linf_a,
          l1 = eval_glmtrans_clr$l1,
          l2 = eval_glmtrans_clr$l2,
          linf = eval_glmtrans_clr$linf,
          l1_total = eval_glmtrans_clr$l1_total,
          l2_total = eval_glmtrans_clr$l2_total,
          linf_total = eval_glmtrans_clr$linf_total,
          fn = eval_glmtrans_clr$fn,
          fp = eval_glmtrans_clr$fp,
          fdp = eval_glmtrans_clr$fdp,
          pe = eval_glmtrans_clr$pe
        ))
        beta_results <- save_beta_results(
          beta_results, sig.delta1, size.A0, num_perturbed_groups, sim,
          "glmtrans_clr", beta_glmtrans_clr
        )

        # TransLasso.raw(oracle)
        cat("sim =", sim, ", size.A0 =", size.A0, "\n")
        cat("TransLasso.raw(oracle)\n")
        X_tl_raw <- as.matrix(cbind(all_data$data_train$N, X_raw_train))
        time_translasso_raw <- system.time(
          fit_translasso_raw <- las.kA(
            X = X_tl_raw,
            y = all_data$data_train$y,
            A0 = 1:size.A0,           
            n.vec = n.vec,
            l1 = TRUE,
            base_lambda_seq = lam0_seq
          )
        )[3]
        beta_full_tl_raw <- as.numeric(fit_translasso_raw$beta.kA)
        if (p_n_now > 0) {
          a_translasso_raw <- beta_full_tl_raw[1:p_n_now]
          beta_translasso_raw <- beta_full_tl_raw[(p_n_now + 1):(p_n_now + p)]
        } else {
          a_translasso_raw <- numeric(0)
          beta_translasso_raw <- beta_full_tl_raw[1:p]
        }
        eval_translasso_raw <- model_evaluation(
          est_a = a_translasso_raw,
          true_a = all_data$data_train$target_a,
          est_beta = beta_translasso_raw,
          true_beta = all_data$data_train$target_beta,
          y_test = all_data$data_test$y[1:n.vec[1]],
          X_test = X_raw_test[1:n.vec[1], , drop = FALSE],
          N_test = all_data$data_test$N[1:n.vec[1], , drop = FALSE]
        )
        sim_results <- rbind(sim_results, data.frame(
          sig.delta1 = sig.delta1,
          size.A0 = size.A0,
          num_perturbed_groups = num_perturbed_groups,
          sim_id = sim,
          model = "translasso_raw",
          runtime = time_translasso_raw,
          l1_a = eval_translasso_raw$l1_a,
          l2_a = eval_translasso_raw$l2_a,
          linf_a = eval_translasso_raw$linf_a,
          l1 = eval_translasso_raw$l1,
          l2 = eval_translasso_raw$l2,
          linf = eval_translasso_raw$linf,
          l1_total = eval_translasso_raw$l1_total,
          l2_total = eval_translasso_raw$l2_total,
          linf_total = eval_translasso_raw$linf_total,
          fn = eval_translasso_raw$fn,
          fp = eval_translasso_raw$fp,
          fdp = eval_translasso_raw$fdp,
          pe = eval_translasso_raw$pe
        ))
        beta_results <- save_beta_results(beta_results, sig.delta1, size.A0, num_perturbed_groups, sim, "translasso_raw", beta_translasso_raw)

        # TransLasso.alr(oracle)
        cat("sim =", sim, ", size.A0 =", size.A0, "\n")
        cat("TransLasso.alr(oracle)\n")
        X_tl_alr <- as.matrix(cbind(all_data$data_train$N, X_alr_train))
        time_translasso_alr <- system.time(
          fit_translasso_alr <- las.kA(
            X = X_tl_alr,
            y = all_data$data_train$y,   
            A0 = 1:size.A0,
            n.vec = n.vec,
            l1 = TRUE,
            base_lambda_seq = lam0_seq
          )
        )[3]
        beta_full_tl_alr <- as.numeric(fit_translasso_alr$beta.kA)
        if (p_n_now > 0) {
          a_translasso_alr <- beta_full_tl_alr[1:p_n_now]
          gamma_translasso_alr <- beta_full_tl_alr[(p_n_now + 1):length(beta_full_tl_alr)]
        } else {
          a_translasso_alr <- numeric(0)
          gamma_translasso_alr <- beta_full_tl_alr
        }
        beta_translasso_alr <- alr_to_beta_subcomp(gamma_translasso_alr, tind_now)  
        eval_translasso_alr <- model_evaluation(
          est_a = a_translasso_alr,
          true_a = all_data$data_train$target_a,
          est_beta = beta_translasso_alr,
          true_beta = all_data$data_train$target_beta,
          y_test = all_data$data_test$y[1:n.vec[1]],
          X_test = X_raw_test[1:n.vec[1], , drop = FALSE],
          N_test = all_data$data_test$N[1:n.vec[1], , drop = FALSE]
        )
        sim_results <- rbind(sim_results, data.frame(
          sig.delta1 = sig.delta1,
          size.A0 = size.A0,
          num_perturbed_groups = num_perturbed_groups,
          sim_id = sim,
          model = "translasso_alr",
          runtime = time_translasso_alr,
          l1_a = eval_translasso_alr$l1_a,
          l2_a = eval_translasso_alr$l2_a,
          linf_a = eval_translasso_alr$linf_a,
          l1 = eval_translasso_alr$l1,
          l2 = eval_translasso_alr$l2,
          linf = eval_translasso_alr$linf,
          l1_total = eval_translasso_alr$l1_total,
          l2_total = eval_translasso_alr$l2_total,
          linf_total = eval_translasso_alr$linf_total,
          fn = eval_translasso_alr$fn,
          fp = eval_translasso_alr$fp,
          fdp = eval_translasso_alr$fdp,
          pe = eval_translasso_alr$pe
        ))
        beta_results <- save_beta_results(beta_results, sig.delta1, size.A0, num_perturbed_groups, sim, "translasso_alr", beta_translasso_alr)

        # TransLasso.clr(oracle)
        cat("sim =", sim, ", size.A0 =", size.A0, "\n")
        cat("TransLasso.clr(oracle)\n")
        X_tl_clr <- as.matrix(cbind(all_data$data_train$N, X_clr_train))
        time_translasso_clr <- system.time(
          fit_translasso_clr <- las.kA(
            X = X_tl_clr,
            y = all_data$data_train$y_z,  
            A0 = 1:size.A0,
            n.vec = n.vec,
            l1 = TRUE,
            base_lambda_seq = lam0_seq
          )
        )[3]
        beta_full_tl_clr <- as.numeric(fit_translasso_clr$beta.kA)
        if (p_n_now > 0) {
          a_translasso_clr <- beta_full_tl_clr[1:p_n_now]
          beta_translasso_clr <- beta_full_tl_clr[(p_n_now + 1):(p_n_now + p)]
        } else {
          a_translasso_clr <- numeric(0)
          beta_translasso_clr <- beta_full_tl_clr[1:p]
        }
        eval_translasso_clr <- model_evaluation(
          est_a = a_translasso_clr,
          true_a = all_data$data_train$target_a,
          est_beta = beta_translasso_clr,
          true_beta = all_data$data_train$target_beta,
          y_test = all_data$data_test$y_z[1:n.vec[1]],
          X_test = X_clr_test[1:n.vec[1], , drop = FALSE],
          N_test = all_data$data_test$N[1:n.vec[1], , drop = FALSE]
        )
        sim_results <- rbind(sim_results, data.frame(
          sig.delta1 = sig.delta1,
          size.A0 = size.A0,
          num_perturbed_groups = num_perturbed_groups,
          sim_id = sim,
          model = "translasso_clr",
          runtime = time_translasso_clr,
          l1_a = eval_translasso_clr$l1_a,
          l2_a = eval_translasso_clr$l2_a,
          linf_a = eval_translasso_clr$linf_a,
          l1 = eval_translasso_clr$l1,
          l2 = eval_translasso_clr$l2,
          linf = eval_translasso_clr$linf,
          l1_total = eval_translasso_clr$l1_total,
          l2_total = eval_translasso_clr$l2_total,
          linf_total = eval_translasso_clr$linf_total,
          fn = eval_translasso_clr$fn,
          fp = eval_translasso_clr$fp,
          fdp = eval_translasso_clr$fdp,
          pe = eval_translasso_clr$pe
        ))
        beta_results <- save_beta_results(beta_results, sig.delta1, size.A0, num_perturbed_groups, sim, "translasso_clr", beta_translasso_clr)

        cat("size.A0 =", size.A0, "done\n")
      }
      
    }
    
  }
  
}

###################### Results ######################
summary_res <- sim_results %>%
  group_by(sig.delta1, size.A0, num_perturbed_groups, model) %>%
  summarise(
    runtime_mean = mean(runtime, na.rm = TRUE),
    runtime_sd = sd(runtime, na.rm = TRUE),
    l1_a_mean = mean(l1_a, na.rm = TRUE),
    l1_a_sd = sd(l1_a, na.rm = TRUE),
    l2_a_mean = mean(l2_a, na.rm = TRUE),
    l2_a_sd = sd(l2_a, na.rm = TRUE),
    linf_a_mean = mean(linf_a, na.rm = TRUE),
    linf_a_sd = sd(linf_a, na.rm = TRUE),
    l1_mean = mean(l1, na.rm = TRUE),
    l1_sd = sd(l1, na.rm = TRUE),
    l2_mean = mean(l2, na.rm = TRUE),
    l2_sd = sd(l2, na.rm = TRUE),
    linf_mean = mean(linf, na.rm = TRUE),
    linf_sd = sd(linf, na.rm = TRUE),
    l1_total_mean = mean(l1_total, na.rm = TRUE),
    l1_total_sd = sd(l1_total, na.rm = TRUE),
    l2_total_mean = mean(l2_total, na.rm = TRUE),
    l2_total_sd = sd(l2_total, na.rm = TRUE),
    linf_total_mean = mean(linf_total, na.rm = TRUE),
    linf_total_sd = sd(linf_total, na.rm = TRUE),
    fn_mean = mean(fn, na.rm = TRUE),
    fn_sd = sd(fn, na.rm = TRUE),
    fp_mean = mean(fp, na.rm = TRUE),
    fp_sd = sd(fp, na.rm = TRUE),
    fdp_mean = mean(fdp, na.rm = TRUE),
    fdp_sd = sd(fdp, na.rm = TRUE),
    pe_mean = mean(pe, na.rm = TRUE),
    pe_sd = sd(pe, na.rm = TRUE),
    .groups = "drop"
  )

print(summary_res, digits = 4)

write_xlsx(list(
  summary = summary_res,
  sim_results = sim_results,
  beta_results = beta_results
), "c-sub-rho05-largebeta-lam1-A020408.xlsx")


total_time_end <- Sys.time()
total_seconds <- as.numeric(difftime(total_time_end, total_time_start, units = "secs"))

hours <- floor(total_seconds / 3600)
minutes <- floor((total_seconds %% 3600) / 60)
seconds <- round(total_seconds %% 60)

cat("\n====================================\n")
cat(sprintf("Total simulation time: %02d:%02d:%02d (hh:mm:ss)\n", 
            hours, minutes, seconds))
cat("====================================\n")
