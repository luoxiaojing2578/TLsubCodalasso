# Trans-Coda-Lasso-l0-new(Constrained SDAR)

nzcount <- function(x, tol = 1e-8) {
  sum(abs(x) > tol)
}

safe_solve <- function(A, b = NULL, ridge = 1e-8) {
  if (is.null(b)) {
    out <- tryCatch(solve(A),
                    error = function(e) NULL)
    if (!is.null(out)) return(out)
    
    out <- tryCatch(qr.solve(A),
                    error = function(e) NULL)
    if (!is.null(out)) return(out)
    
    A2 <- A + ridge * diag(nrow(A))
    return(solve(A2))
  } else {
    out <- tryCatch(solve(A, b),
                    error = function(e) NULL)
    if (!is.null(out)) return(out)
    
    out <- tryCatch(qr.solve(A, b),
                    error = function(e) NULL)
    if (!is.null(out)) return(out)
    
    A2 <- A + ridge * diag(nrow(A))
    return(solve(A2, b))
  }
}

make_constraint_matrix <- function(tind, p_total, p_n, constraint_type = "sub") {
  if (constraint_type == "sub") {
    ngrp <- length(tind) - 1
    C <- matrix(0, nrow = ngrp, ncol = p_total)
    for (ii in 1:ngrp) {
      C[ii, (p_n + tind[ii] + 1):(p_n + tind[ii + 1])] <- 1
    }
  } else if (constraint_type == "single") {
    C <- matrix(0, nrow = 1, ncol = p_total)
    C[1, (p_n + 1):p_total] <- 1
  } else {
    stop("constraint_type : 'sub' or 'single'")
  }
  return(C)
}

constrained_ls_refit <- function(XA, y, CA = NULL, tol = 1e-10, ridge = 1e-8) {
  n <- nrow(XA)
  s <- ncol(XA)
  
  if (s == 0) {
    return(list(beta = numeric(0), nu = numeric(0)))
  }
  
  G <- crossprod(XA) / n
  g <- crossprod(XA, y) / n
  g <- as.numeric(g)
  
  if (is.null(CA) || nrow(CA) == 0) {
    beta_A <- as.numeric(safe_solve(G + ridge * diag(s), g))
    return(list(beta = beta_A, nu = numeric(0)))
  }
  
  keep_row <- which(rowSums(abs(CA)) > tol)
  if (length(keep_row) == 0) {
    beta_A <- as.numeric(safe_solve(G + ridge * diag(s), g))
    return(list(beta = beta_A, nu = numeric(0)))
  }
  CA <- CA[keep_row, , drop = FALSE]
  qA <- nrow(CA)
  
  KKT <- rbind(
    cbind(G + ridge * diag(s), t(CA)),
    cbind(CA, matrix(0, nrow = qA, ncol = qA))
  )
  rhs <- c(g, rep(0, qA))
  
  sol <- safe_solve(KKT, rhs, ridge = ridge)
  sol <- as.numeric(sol)
  
  if (length(sol) != s + qA) {
    stop("KKT system solution has incorrect length in constrained_ls_refit().")
  }
  
  beta_A <- sol[1:s]
  nu <- sol[(s + 1):(s + qA)]
  
  return(list(
    beta = as.numeric(beta_A),
    nu = as.numeric(nu)
  ))
}

classo_l0_sdar <- function(Xt, y, C, we, lam0,
                           maxiter = 100,
                           tol = 1e-8,
                           mu = 1, nu = 1.05,
                           sparse_level = 10) {
  
  Xt <- as.matrix(Xt)
  C <- as.matrix(C)
  y <- as.numeric(y)
  we <- as.numeric(we)
  
  n <- nrow(Xt)
  p <- ncol(Xt)
  
  if (length(we) != p) stop("length(we) != ncol(Xt)")
  if (ncol(C) != p) stop("ncol(C) != ncol(Xt)")
  
  beta <- rep(0, p)
  resid <- as.numeric(y - Xt %*% beta)
  d <- as.numeric(crossprod(Xt, resid) / n)
  
  thr <- sqrt(2 * lam0) * we
  
  unpen_idx <- which(we <= 1e-15)
  pen_idx <- setdiff(seq_len(p), unpen_idx)
  
  old_support <- NULL
  
  for (iter in 1:maxiter) {
    
    svec <- beta + d
    
    support_unpen <- unpen_idx
    
    if (length(pen_idx) > 0) {
      support_pen <- pen_idx[abs(svec[pen_idx]) >= thr[pen_idx]]
    } else {
      support_pen <- integer(0)
    }
    
    if (!is.null(sparse_level) && is.finite(sparse_level) &&
        length(support_pen) > sparse_level) {
      ord <- order(abs(svec[support_pen]), decreasing = TRUE)
      support_pen <- support_pen[ord[1:sparse_level]]
    }
    
    support <- sort(unique(c(support_unpen, support_pen)))
    nonsupport <- setdiff(seq_len(p), support)
    
    if (length(support) == 0) {
      beta_new <- rep(0, p)
      resid_new <- as.numeric(y - Xt %*% beta_new)
      d_new <- as.numeric(crossprod(Xt, resid_new) / n)
      
      beta <- beta_new
      d <- d_new
      break
    }
    
    XA <- Xt[, support, drop = FALSE]
    CA <- C[, support, drop = FALSE]
    
    refit <- constrained_ls_refit(XA, y, CA)
    beta_A <- as.numeric(refit$beta)
    nu_A <- refit$nu
    
    if (is.null(nu_A)) nu_A <- numeric(0)
    nu_A <- as.numeric(nu_A)
    
    beta_new <- rep(0, p)
    beta_new[support] <- beta_A
    
    resid_new <- as.numeric(y - Xt %*% beta_new)
    d_new <- as.numeric(crossprod(Xt, resid_new) / n)
    
    if (length(nu_A) > 0 && nrow(CA) > 0) {
      keep_row <- which(rowSums(abs(CA)) > 1e-10)
      
      if (length(keep_row) > 0) {
        CA_eff <- CA[keep_row, , drop = FALSE]
        q_eff <- nrow(CA_eff)
        
        if (length(nu_A) != q_eff) {
          warning("length(nu_A) != number of effective constraints; skip dual correction in this iteration.")
        } else {
          d_new[support] <- as.numeric(t(CA_eff) %*% nu_A)
          
          if (length(nonsupport) > 0) {
            CI <- C[keep_row, nonsupport, drop = FALSE]
            d_new[nonsupport] <- d_new[nonsupport] - as.numeric(t(CI) %*% nu_A)
          }
        }
      }
    }
    
    beta_err <- sqrt(sum((beta_new - beta)^2))
    same_support <- !is.null(old_support) && identical(support, old_support)
    
    beta <- beta_new
    d <- d_new
    old_support <- support
    
    if (same_support || beta_err < tol) break
  }
  
  return(list(
    beta = as.numeric(beta),
    sparse_level = nzcount(beta)
  ))
}

classol0 <- function(data, p, lam0 = NULL, maxiter = 5000,
                     tol = 1e-8, mu = 1, nu = 1.05, seed = 2025,
                     constraint_type = "sub", sparse_level = 10) {
  
  set.seed(seed)
  
  X <- as.matrix(data$X)     
  N <- as.matrix(data$N)    
  y <- as.numeric(data$y)
  tind <- data$tind
  
  p_n <- ncol(N)
  Z <- cbind(N, X)
  n <- nrow(Z)
  p_total <- ncol(Z)
  
  C <- make_constraint_matrix(
    tind = tind,
    p_total = p_total,
    p_n = p_n,
    constraint_type = constraint_type
  )
  
  if (p_n == 0) {
    we <- rep(1, p)
  } else {
    we <- c(0, rep(1, p_n - 1), rep(1, p))
  }
  
  intercept_index <- if (p_n > 0) 1 else NA
  xmean <- colMeans(Z)
  if (p_n > 0) xmean[intercept_index] <- 0
  sfac_raw <- apply(Z, 2, sd)
  sfac_raw[is.na(sfac_raw)] <- 1
  sfac_raw[sfac_raw == 0] <- 1
  if (p_n > 0) sfac_raw[intercept_index] <- 1
  sfac_raw[sfac_raw < 1e-6] <- 1e-6
  
  sfac <- 1 / sfac_raw
  
  Zt <- sweep(Z, 2, xmean, FUN = "-")
  Zt <- sweep(Zt, 2, sfac, FUN = "*")
  
  C_std <- sweep(C, 2, sfac, FUN = "*")
  
  y_orig <- y
  if (p_n > 0) {
    mu_y <- mean(y_orig)
    y_cent <- y_orig - mu_y
  } else {
    mu_y <- 0
    y_cent <- y_orig
  }
  
  model_res <- classo_l0_sdar(
    Xt = Zt,
    y = y_cent,
    C = C_std,
    we = we,
    lam0 = lam0,
    maxiter = maxiter,
    tol = tol,
    mu = mu,
    nu = nu,
    sparse_level = sparse_level
  )
  
  beta_std <- as.numeric(model_res$beta)
  tem <- beta_std * sfac
  
  if (p_n > 0) {
    offset <- sum(tem[(p_n + 1):p_total] * xmean[(p_n + 1):p_total])
  } else {
    offset <- 0
  }
  if (p_n > 0) {
    a_est <- (mu_y + tem[1:p_n]) - offset
  } else {
    a_est <- numeric(0)
  }
  beta_est <- tem[(p_n + 1):p_total]
  
  if (p_n > 0) {
    y_train_pred <- as.vector(N %*% a_est + X %*% beta_est)
  } else {
    y_train_pred <- as.vector(X %*% beta_est)
  }
  resid <- y_orig - y_train_pred
  train_mse <- mean(resid^2)
  
  sigma2_est <- mean(resid^2)
  df_est <- sum(abs(beta_est) > 1e-8)
  n_sample <- nrow(X)
  
  denom <- max(n_sample - df_est, 1)
  se_beta <- sqrt(sigma2_est / denom)
  se_a <- sqrt(sigma2_est / denom)
  
  se_beta_vec <- rep(se_beta, length(beta_est))
  se_a_vec <- rep(se_a, length(a_est))
  
  names(se_beta_vec) <- colnames(X)
  if (length(a_est) > 0 && !is.null(colnames(N))) {
    names(se_a_vec) <- colnames(N)
  }
  se_full <- c(se_a_vec, se_beta_vec)
  
  return(list(
    a = as.numeric(a_est),
    beta = as.numeric(beta_est),
    beta_full = c(as.numeric(a_est), as.numeric(beta_est)),
    lam0 = lam0,
    sigma2 = sigma2_est,
    df = df_est,
    y_pred = y_train_pred,
    N = N,
    X = X,
    y_orig = y_orig,
    train_mse = train_mse,
    se_a = se_a_vec,
    se_beta = se_beta_vec,
    se_full = se_full,
    support_size = nzcount(beta_est)
  ))
}

cv_classol0 <- function(data, p, lam0_seq, nfold = 10,
                        maxiter = 5000, tol = 1e-8, mu = 1, nu = 1.05,
                        seed = 2025, constraint_type = "sub",
                        type = "min", sparse_level = 10) {
  
  set.seed(seed)
  
  X <- as.matrix(data$X)
  y <- as.numeric(data$y)
  tind <- data$tind
  
  n <- length(y)
  p_original <- ncol(X)
  N <- data$N
  p_n <- if (is.null(dim(N))) 0 else ncol(N)
  
  if (p_n > 0 && (p_n == 1 || is.vector(N))) {
    N <- as.matrix(N, ncol = 1)
    p_n <- 1
  }
  
  foldid <- sample(rep(1:nfold, length.out = n))
  
  pred <- matrix(NA, nrow = nfold, ncol = length(lam0_seq))
  valid_n <- numeric(nfold)
  
  for (i in 1:nfold) {
    train_idx <- which(foldid != i)
    valid_idx <- which(foldid == i)
    valid_n[i] <- length(valid_idx)
    
    y_train <- y[train_idx]
    X_train <- X[train_idx, , drop = FALSE]
    N_train <- N[train_idx, , drop = FALSE]
    
    y_valid <- y[valid_idx]
    X_valid <- X[valid_idx, , drop = FALSE]
    N_valid <- N[valid_idx, , drop = FALSE]
    
    data_train_fold <- list(
      X = X_train,
      N = N_train,
      y = y_train,
      tind = tind
    )
    
    for (j in seq_along(lam0_seq)) {
      lam0_j <- lam0_seq[j]
      
      fit_j <- classol0(
        data = data_train_fold,
        p = p,
        lam0 = lam0_j,
        maxiter = maxiter,
        tol = tol,
        mu = mu,
        nu = nu,
        seed = seed + i + j,
        constraint_type = constraint_type,
        sparse_level = sparse_level
      )
      
      if (p_n > 0) {
        y_valid_pred <- as.vector(
          N_valid %*% fit_j$a + X_valid %*% fit_j$beta
        )
      } else {
        y_valid_pred <- as.vector(X_valid %*% fit_j$beta)
      }
      
      pred[i, j] <- sum((y_valid - y_valid_pred)^2)
    }
    
    
  }
  
  pred_mse <- t(t(pred) / valid_n)
  
  weights <- valid_n / sum(valid_n)
  cvm <- colSums(pred_mse * weights, na.rm = TRUE)
  
  cvse <- apply(pred_mse, 2, function(col) {
    valid_vals <- col[!is.na(col)]
    if (length(valid_vals) < 2) return(NA_real_)
    sd(valid_vals) / sqrt(length(valid_vals))
  })
  
  imin <- which.min(cvm)
  if (type == "1se") {
    ilam <- which(cvm <= cvm[imin] + cvse[imin])[1]
  } else {
    ilam <- imin
  }
  lam_best <- lam0_seq[ilam]
  
  data_full <- list(
    X = X,
    N = N,
    y = y,
    tind = tind
  )
  
  fit_best <- classol0(
    data = data_full,
    p = p,
    lam0 = lam_best,
    maxiter = maxiter,
    tol = tol,
    mu = mu,
    nu = nu,
    seed = seed,
    constraint_type = constraint_type,
    sparse_level = sparse_level
  )
  
  return(list(
    a = fit_best$a,
    beta = fit_best$beta,
    lam0_best = lam_best,
    lam0_seq = lam0_seq,
    cvm = cvm,
    cvse = cvse,
    foldid = foldid,
    fit_best = fit_best,
    se_a = fit_best$se_a,
    se_beta = fit_best$se_beta
  ))
}

Oracle.subCodalassol0 <- function(X, N, y, tind, A0, n.vec, nfold = 10,
                                  maxiter = 5000, tol = 1e-8, mu = 1, nu = 1.05,
                                  seed = 2025, constraint_type = "sub",
                                  lam0_seq, sparse_level = 10) {
  
  X <- as.matrix(X)
  N <- as.matrix(N)
  y <- as.numeric(y)
  
  p <- ncol(X)
  p_n <- if (is.null(dim(N))) 0 else ncol(N)
  
  if (length(A0) == 2 && all(A0 == c(1, 0))) {
    A0 <- integer(0)
  }
  
  size.A0 <- length(A0)
  a.KA <- numeric(p_n)
  a.udb <- numeric(p_n)
  
  if (size.A0 > 0) {
    
    k.vec <- c(1, A0 + 1)
    ind.kA <- NULL
    
    for (k in k.vec) {
      if (k == 1) {
        ind.kA <- c(ind.kA, 1:n.vec[1])
      } else {
        ind.kA <- c(ind.kA,
                    (sum(n.vec[1:(k - 1)]) + 1):sum(n.vec[1:k]))
      }
    }
    
    ind.1 <- 1:n.vec[1]
    
    data.kA <- list(
      X = X[ind.kA, , drop = FALSE],
      N = N[ind.kA, , drop = FALSE],
      y = y[ind.kA],
      tind = tind
    )
    
    w <- cv_classol0(
      data = data.kA,
      p = p,
      lam0_seq = lam0_seq,
      nfold = nfold,
      maxiter = maxiter,
      tol = tol,
      mu = mu,
      nu = nu,
      seed = seed,
      constraint_type = constraint_type,
      type = "1se",
      sparse_level = sparse_level
    )
    
    a.udb <- as.numeric(w$a)
    w.kA <- as.numeric(w$beta)
    se_w_kA <- w$se_beta
    se_w_a <- w$se_a
    
    if (p_n > 0) {
      y_pred_w <- as.vector(
        N[ind.1, , drop = FALSE] %*% a.udb +
          X[ind.1, , drop = FALSE] %*% w.kA
      )
    } else {
      y_pred_w <- as.vector(X[ind.1, , drop = FALSE] %*% w.kA)
    }
    res <- as.numeric(y[ind.1] - y_pred_w)
    
    data.delta <- list(
      X = X[ind.1, , drop = FALSE],
      N = N[ind.1, , drop = FALSE],
      y = res,
      tind = tind
    )
    
    delta <- cv_classol0(
      data = data.delta,
      p = p,
      lam0_seq = lam0_seq,
      nfold = nfold,
      maxiter = maxiter,
      tol = tol,
      mu = mu,
      nu = nu,
      seed = seed,
      constraint_type = constraint_type,
      type = "min",
      sparse_level = sparse_level
    )
    
    a.delta <- as.numeric(delta$a)
    delta.kA <- as.numeric(delta$beta)
    se_delta_kA <- delta$se_beta
    se_delta_a <- delta$se_a
    
    beta.kA <- w.kA + delta.kA
    a.KA <- a.udb + a.delta
    
    se_beta_kA <- sqrt(se_w_kA^2 + se_delta_kA^2)
    se_a_KA <- sqrt(se_w_a^2 + se_delta_a^2)
    
    names(se_beta_kA) <- colnames(X)
    if (p_n > 0 && !is.null(colnames(N))) names(se_a_KA) <- colnames(N)
    
  } else {
    
    ind.1 <- 1:n.vec[1]
    
    data.kA <- list(
      X = X[ind.1, , drop = FALSE],
      N = N[ind.1, , drop = FALSE],
      y = y[ind.1],
      tind = tind
    )
    
    w <- cv_classol0(
      data = data.kA,
      p = p,
      lam0_seq = lam0_seq,
      nfold = nfold,
      maxiter = maxiter,
      tol = tol,
      mu = mu,
      nu = nu,
      seed = seed,
      constraint_type = constraint_type,
      type = "1se",
      sparse_level = sparse_level
    )
    
    a.udb <- as.numeric(w$a)
    w.kA <- as.numeric(w$beta)
    se_w_kA <- w$se_beta
    se_w_a <- w$se_a
    
    if (p_n > 0) {
      y_pred_w <- as.vector(
        N[ind.1, , drop = FALSE] %*% a.udb +
          X[ind.1, , drop = FALSE] %*% w.kA
      )
    } else {
      y_pred_w <- as.vector(X[ind.1, , drop = FALSE] %*% w.kA)
    }
    res <- as.numeric(y[ind.1] - y_pred_w)
    
    data.delta <- list(
      X = X[ind.1, , drop = FALSE],
      N = N[ind.1, , drop = FALSE],
      y = res,
      tind = tind
    )
    
    delta <- cv_classol0(
      data = data.delta,
      p = p,
      lam0_seq = lam0_seq,
      nfold = nfold,
      maxiter = maxiter,
      tol = tol,
      mu = mu,
      nu = nu,
      seed = seed,
      constraint_type = constraint_type,
      type = "min",
      sparse_level = sparse_level
    )
    
    a.delta <- as.numeric(delta$a)
    delta.kA <- as.numeric(delta$beta)
    se_delta_kA <- delta$se_beta
    se_delta_a <- delta$se_a
    
    beta.kA <- w.kA + delta.kA
    a.KA <- a.udb + a.delta
    
    se_beta_kA <- sqrt(se_w_kA^2 + se_delta_kA^2)
    se_a_KA <- sqrt(se_w_a^2 + se_delta_a^2)
    
    names(se_beta_kA) <- colnames(X)
    if (p_n > 0 && !is.null(colnames(N))) names(se_a_KA) <- colnames(N)
  }
  
  return(list(
    beta = as.numeric(beta.kA),
    a = as.numeric(a.KA),
    beta.udb = as.numeric(w.kA),
    a.udb = as.numeric(a.udb),
    se_beta = se_beta_kA,
    se_a = se_a_KA,
    se_beta_udb = se_w_kA,
    se_a_udb = se_w_a
  ))
}


