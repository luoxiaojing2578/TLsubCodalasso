﻿# L0 Simulation Experiments

R code for the additional simulation experiments with constrained L0-based methods in the paper:

**Transfer Learning for High-Dimensional Regression with Compositional Covariates: Application to Microbiome Studies**

The scripts reproduce the supplementary simulation studies comparing the proposed constrained L1-based Trans-subCodaLasso method with constrained L0-type competitors.

The code corresponds to **Supplementary Material Section S4.2**, including the algorithms in **Section S4.2.1**, the simulation settings in **Section S4.2.2**, and the numerical results in **Section S4.2.3**.

## Main functions

The main functions for the proposed L1-based method are in:

- `Func-TransCodaLasso.R`

The constrained L0-type methods are implemented in:

- `Func-TransCodaLassol0new.R`
- `Func-TranssubCodaLassol0new.R`
- `Func-TransCodaLassol0old.R`

The C++ code used for constrained Lasso computation is in:

- `cclasso1.cpp`


The data generation and model evaluation functions are in:

- `data_eval-large-rho05-single.R`
- `data_eval-large-rho05-sub.R`
- `data_eval-small-rho05-single.R`
- `data_eval-small-rho05-sub.R`

## How to run

The L0 simulation experiments are implemented in four main R scripts:

- `large-single.R`: strong signals and sparse coefficients under the single composition constraint.
- `large-sub.R`: strong signals and sparse coefficients under the subcomposition constraints.
- `small-single.R`: weak signals and dense coefficients under the single composition constraint.
- `small-sub.R`: weak signals and dense coefficients under the subcomposition constraints.

Run the four simulation settings by:

```r
source("large-single.R")
source("large-sub.R")
source("small-single.R")
source("small-sub.R")
```

Each script runs the simulation, evaluates the competing methods, and exports the results to an Excel file.


## Notes

The constrained L0-type competitors include:

- Constrained SDAR.
- HTC-L0, a hard-thresholding constrained L0 method.

The simulations compare these L0-type methods with the proposed Oracle-Trans-subCodaLasso method and other transfer learning benchmarks, including Trans-Lasso and Trans-GLM.
