# Function(Simulation-Gaussian-Data generation)
Data.gen <- function(n.vec, M, p, B, snr, seed=2025) {
  set.seed(seed)
  p_n <- B$p_n
  a_target <- B$a_target
  A <- B$A
  tind <- B$tind 
  ngrp <- length(tind)-1
  target_beta <- B$beta
  ref_indices <- tind[2:length(tind)] 
  target_beta_z <- target_beta[-ref_indices] 
  mu_vec <- rep(0, p)
  Sigma <- matrix(0, nrow=p, ncol=p)
  for (i in 1:p) {
    for (j in 1:p) {
      Sigma[i,j] <- 0.5^abs(i - j)
    }
  }
  A_k <- matrix(rbinom(p*p, 1, 0.3) * 0.3, ncol=p)
  Sigma1 <- t(A_k) %*% A_k + diag(p)
  
  X_combined <- matrix(nrow = 0, ncol = p)
  Z_combined <- matrix(nrow = 0, ncol = p - ngrp) 
  N_combined <- if (p_n == 0) matrix(nrow=0, ncol=0) else matrix(nrow = 0, ncol = p_n)
  y_combined <- numeric(0)
  X_test_combined <- matrix(nrow = 0, ncol = p)
  Z_test_combined <- matrix(nrow = 0, ncol = p - ngrp)
  N_test_combined <- if (p_n == 0) matrix(nrow=0, ncol=0) else matrix(nrow = 0, ncol = p_n)
  y_test_combined <- numeric(0)

  sub_group_diff <- function(X_raw, tind) {
    Z_list <- list()
    for (g in 1:(length(tind)-1)) {
      group_idx <- (tind[g]+1):tind[g+1]
      X_g <- X_raw[, group_idx, drop=FALSE]
      p_g <- length(group_idx)
      ref_col <- X_g[, p_g] 
      numerator_cols <- X_g[, -p_g, drop=FALSE]
      Z_g <- sweep(numerator_cols, 1, ref_col, "-")
      Z_list[[g]] <- Z_g
    }
    return(do.call(cbind, Z_list))
  }
  
  for (type in c("train", "test")) {
    n_curr <- n.vec[1]
    N_curr <- if (p_n > 0) {
      mat <- matrix(1, nrow = n_curr, ncol = p_n)
      if (p_n > 1) mat[, -1] <- rbinom(n_curr * (p_n - 1), 1, 0.5)
      mat
    } else matrix(nrow = n_curr, ncol = 0)
    x_curr <- mvrnorm(n_curr, mu = mu_vec, Sigma = Sigma)
    z_curr <- sub_group_diff(x_curr, tind)
    y_val <- as.vector(if(p_n > 0) N_curr %*% a_target + x_curr %*% target_beta else x_curr %*% target_beta)
    y_z_val <- as.vector(if(p_n > 0) N_curr %*% a_target + z_curr %*% target_beta_z else z_curr %*% target_beta_z)
    snr_sigma <- sd(y_val) / snr
    noise <- snr_sigma * rnorm(n_curr)
    y_val <- y_val + noise
    y_z_val <- y_z_val + noise 

    if (type == "train") {
      X_combined <- x_curr; Z_combined <- z_curr; N_combined <- N_curr; 
      y_combined <- y_val; y_z_combined <- y_z_val 
    } else {
      X_test_combined <- x_curr; Z_test_combined <- z_curr; N_test_combined <- N_curr; 
      y_test_combined <- y_val; y_test_z_combined <- y_z_val 
    }
  }

  y_z_combined <- y_z_combined 
  
  for (k in 1:M) {
    set.seed(seed + 100*k)
    s_beta <- B$W[,k]      
    s_a <- A[,k]          
    n_s <- n.vec[k+1]
    ref_indices <- tind[2:length(tind)]
    s_beta_z <- s_beta[-ref_indices]
    N_s <- if (p_n > 0) {
      mat <- matrix(1, nrow = n_s, ncol = p_n)
      if (p_n > 1) mat[, -1] <- rbinom(n_s * (p_n - 1), 1, 0.5)
      mat
    } else matrix(nrow = n_s, ncol = 0)
    x_s_curr <- mvrnorm(n_s, mu = mu_vec, Sigma = Sigma1)
    z_s_curr <- sub_group_diff(x_s_curr, tind)
    y_s <- as.vector(if(p_n > 0) N_s %*% s_a + x_s_curr %*% s_beta else x_s_curr %*% s_beta)
    y_z_s <- as.vector(if(p_n > 0) N_s %*% s_a + z_s_curr %*% s_beta_z else z_s_curr %*% s_beta_z)
    s_sigma <- sd(y_s) / snr
    s_noise <- s_sigma * rnorm(n_s)
    y_s <- y_s + s_noise
    y_z_s <- y_z_s + s_noise

    X_combined <- rbind(X_combined, x_s_curr)
    Z_combined <- rbind(Z_combined, z_s_curr)
    if(p_n > 0) N_combined <- rbind(N_combined, N_s)
    y_combined <- c(y_combined, y_s)
    y_z_combined <- c(y_z_combined, y_z_s) 
  }
  
  return(list(
    data_train = list(
      X = X_combined, 
      Z = Z_combined, 
      N = N_combined, 
      y = y_combined, 
      y_z = y_z_combined,    
      target_beta = target_beta, 
      target_beta_z = target_beta_z, 
      target_a = a_target, 
      tind = tind
    ),
    data_test = list(
      X = X_test_combined, 
      Z = Z_test_combined, 
      N = N_test_combined, 
      y = y_test_combined,
      y_z = y_test_z_combined
    )
  ))
}