library(ggplot2)
library(scales)
library(readxl)
library(dplyr)


load_and_label <- function(path, scenario_name, d_name) {
  df <- read_excel(path, sheet = "Sheet1")
  df$scenario <- scenario_name 
  df$d_val <- d_name          
  return(df)
}

d1 <- load_and_label("C:/.../M_homogeneous.xlsx", "Gaussian data", "Homogeneous")
d2 <- load_and_label("C:/.../M_mild_heterogeneous.xlsx", "Gaussian data", "Heterogeneous I")
d3 <- load_and_label("C:/.../M_heavy5_heterogeneous.xlsx", "Gaussian data", "Heterogeneous II")
d4 <- load_and_label("C:/.../M_homogeneous422.xlsx", "Compositional data", "Homogeneous")
d5 <- load_and_label("C:/.../M_mild_heterogeneous422.xlsx", "Compositional data", "Heterogeneous I")
d6 <- load_and_label("C:/.../M_heavy5_heterogeneous422.xlsx", "Compositional data", "Heterogeneous II")

df_all <- rbind(d1, d2, d3, d4, d5, d6)

df_all$scenario <- factor(df_all$scenario, 
                          levels = c("Gaussian data", "Compositional data"))

df_all$d_val <- factor(df_all$d_val, 
                       levels = c("Homogeneous", "Heterogeneous I", "Heterogeneous II"))

df_all$model <- dplyr::case_when(
  df_all$model == "classo" ~ "subCodalasso",
  df_all$model == "Trans.Codalasso.sub" ~ "Trans-subCodalasso",
  df_all$model == "Oracle.subCodalasso" ~ "Oracle-Trans-subCodalasso",
  df_all$model == "TransFusion.CoDa" ~ "Con-TransFusion",
  df_all$model == "TransGLM.alr" ~ "Trans-GLM-alr",
  df_all$model == "TransGLM.raw" ~ "Trans-GLM-raw",
  df_all$model == "TransLasso.alr" ~ "Trans-Lasso-alr",
  df_all$model == "TransLasso.raw" ~ "Trans-Lasso-raw",
  TRUE ~ df_all$model
)

df_filtered <- df_all[df_all$model != "Trans-subCodalasso", ]
df_filtered <- df_filtered[
  !grepl("raw", df_filtered$model, ignore.case = TRUE), 
]
target_order <- c(
  "Oracle-Trans-subCodalasso", 
  "subCodalasso",
  "Con-TransFusion",
  "Trans-Lasso-alr",  
  "Trans-GLM-alr"
)

df_filtered$model <- factor(df_filtered$model, levels = target_order)
p <- ggplot(df_filtered, aes(x = M, y = l2_mean, color = model, shape = model)) +
  geom_line(linewidth = 0.3, alpha = 0.9) +
  geom_point(size = 1.5, alpha = 0.9) +
  facet_grid(scenario ~ d_val) + 
  scale_x_continuous(breaks = unique(df_filtered$M)) +
  labs(
    x = "|A|",
    y = expression("L"[2] ~ "error"),
    color = "Method",
    shape = "Method"
  ) +
  theme_bw(base_size = 12) + 
  theme(
    legend.position = "bottom",
    legend.box = "horizontal",         
    legend.direction = "horizontal",
    legend.title = element_text(size = 14), 
    legend.text = element_text(size = 12),      
    legend.key.size = unit(1.2, "lines"),         
    legend.spacing.x = unit(0.1, "cm"),          
    legend.spacing.y = unit(0.5, "cm"),
    strip.background = element_rect(fill = "gray95"),
    strip.text = element_text(size = 11),   
    panel.grid.minor = element_blank(),
    panel.spacing = unit(1, "lines"),
    plot.margin = margin(10, 20, 10, 20)         
  ) +
  guides(color = guide_legend(nrow = 1, byrow = TRUE), 
         shape = guide_legend(nrow = 1, byrow = TRUE))
  

my_shapes <- c(
  "Oracle-Trans-subCodalasso" = 17, 
  "Con-TransFusion"           = 16, 
  "subCodalasso"              = 15, 
  "Trans-GLM-raw"             = 7,  
  "Trans-GLM-alr"             = 3,  
  "Trans-Lasso-raw"           = 1,
  "Trans-Lasso-alr"           = 8   
)

p_final <- p + 
  scale_color_manual(
    values = c(
      "Oracle-Trans-subCodalasso" = "#2E8B57", 
      "Con-TransFusion"           = "#D32F2F",  
      "subCodalasso"              = "#E76BF3",  
      "Trans-GLM-alr"             = "#F8766D",  
      "Trans-Lasso-alr"           = "#1E90FF", 
      setNames(
        scales::hue_pal()(length(unique(df_filtered$model))-2),
        setdiff(unique(df_filtered$model), c("Oracle-Trans-subCodalasso", "Con-TransFusion"))
      )
    )
  ) +
  scale_shape_manual(values = my_shapes) +
  guides(
    color = guide_legend(title = "Method", ncol = 3, byrow = TRUE),
    shape = guide_legend(title = "Method", ncol = 3, byrow = TRUE)
  )

print(p_final)

ggsave("E:/valid sources(all).pdf", p_final, width = 12, height = 7)


# fix M
library(ggplot2)
library(scales)
library(readxl)
library(dplyr)

load_and_label <- function(path, scenario_name, d_name) {
  df <- read_excel(path, sheet = "Sheet1")
  df$scenario <- scenario_name
  df$d_val <- d_name
  return(df)
}

d1 <- load_and_label("C:/.../A0_heavy5_heterogeneous.xlsx", "Gaussian data", "Heterogeneous II")
d4 <- load_and_label("C:/.../A0_heavy5_heterogeneous422.xlsx", "Compositional data", "Heterogeneous II")
df_all <- rbind(d1, d4)
df_all$scenario <- factor(df_all$scenario, 
                          levels = c("Gaussian data", "Compositional data"))

df_all$model <- dplyr::case_when(
  df_all$model == "classo" ~ "subCodalasso",
  df_all$model == "Trans.Codalasso.sub" ~ "Trans-subCodalasso",
  df_all$model == "Oracle.subCodalasso" ~ "Oracle-Trans-subCodalasso",
  df_all$model == "TransFusion.CoDa" ~ "Con-TransFusion",
  df_all$model == "TransGLM.alr" ~ "Trans-GLM-alr",
  df_all$model == "TransGLM.raw" ~ "Trans-GLM-raw",
  df_all$model == "TransLasso.alr" ~ "Trans-Lasso-alr",
  df_all$model == "TransLasso.raw" ~ "Trans-Lasso-raw",
  TRUE ~ df_all$model
)

df_filtered <- df_all[
  !grepl("raw", df_all$model, ignore.case = TRUE), 
]
target_order <- c(
  "Oracle-Trans-subCodalasso", 
  "Trans-subCodalasso", 
  "Con-TransFusion", 
  "subCodalasso",
  "Trans-Lasso-alr",   # 紧跟在后面
  "Trans-GLM-alr"
)

df_filtered$model <- factor(df_filtered$model, levels = target_order)
p <- ggplot(df_filtered, aes(x = size.A0, y = l2_mean, color = model, shape = model)) +
  geom_line(linewidth = 0.3, alpha = 0.9) +
  geom_point(size = 1.5, alpha = 0.9) +
  facet_grid(. ~ scenario) +  
  scale_x_continuous(breaks = unique(df_filtered$size.A0)) +
  labs(
    x = "|A|",
    y = expression("L"[2] ~ "error"),
    color = "Method",
    shape = "Method"
  ) +
  theme_bw(base_size = 12) + 
  theme(
    legend.position = "bottom",
    legend.box = "horizontal",
    legend.direction = "horizontal",
    
    legend.title = element_text(size = 14),
    legend.text = element_text(size = 12),
    legend.key.size = unit(1.2, "lines"),
    legend.spacing.x = unit(0.1, "cm"),
    legend.spacing.y = unit(0.5, "cm"),
    strip.background = element_rect(fill = "gray95"),
    strip.text = element_text(size = 11),
    strip.placement = "outside", 
    panel.grid.minor = element_blank(),
    panel.spacing = unit(1, "lines"),
    plot.margin = margin(10, 20, 10, 20)
  ) +
  guides(color = guide_legend(nrow = 2, byrow = TRUE), 
         shape = guide_legend(nrow = 2, byrow = TRUE))


my_shapes <- c(
  "Oracle-Trans-subCodalasso" = 17, 
  "Trans-subCodalasso"        = 18, 
  "Con-TransFusion"           = 16, 
  "subCodalasso"              = 15, 
  "Trans-GLM-raw"             = 7,  
  "Trans-GLM-alr"             = 3,  
  "Trans-Lasso-raw"           = 1,
  "Trans-Lasso-alr"           = 8   
)

p_final <- p + 
  scale_color_manual(
    values = c(
      "Oracle-Trans-subCodalasso" = "#2E8B57",  
      "Trans-subCodalasso"        = "#A2AD00", 
      "Con-TransFusion"           = "#D32F2F", 
      "subCodalasso"              = "#E76BF3", 
      "Trans-GLM-raw"             = "#FFBF00", 
      "Trans-GLM-alr"             = "#F8766D",  
      "Trans-Lasso-raw"           = "#4682B4", 
      "Trans-Lasso-alr"           = "#1E90FF",  
      setNames(
        scales::hue_pal()(length(unique(df_filtered$model)) - 3),
        setdiff(unique(df_filtered$model), c("Oracle-Trans-subCodalasso", "Trans-subCodalasso", "Con-TransFusion"))
      )
    )
  ) +
  scale_shape_manual(values = my_shapes) +
  guides(
    color = guide_legend(title = "Method", ncol = 3, byrow = TRUE),
    shape = guide_legend(title = "Method", ncol = 3, byrow = TRUE)
  )

print(p_final)
ggsave("E:/M=10.pdf", p_final, width = 8, height = 4.5)

