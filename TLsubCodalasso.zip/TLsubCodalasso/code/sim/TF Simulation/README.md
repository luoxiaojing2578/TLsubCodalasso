# Outline

```
├── README.md
├── main.R # simulation instructor
├── Func-sim.R # simulation for coexisting informative and non-informative sources
├── Func-sim-Copy1.R # simulation for all informative sources
├── Func-coefgen.R # coeffcient generation
├── Func-datagen-sub.R # compositional-data generation
├── Func-datagen.R # Gaussian-data generation 
├── Func-lambda-init.R # lambda initialization
├── Func-TransCodaLasso.R # main function
├── model_eval.R # model evaluation 
├── TransLasso-functions-robust.R # Trans-Lasso(one of the competitors)
├── utils.R # auxiliary code for TransFusion algorithm
├── TransFusion.CoDa.R # constrained TransFusion algorithm
├── cclasso1.cpp # auxiliary function for the constrained optimization problem
├── plot_tf.R # plot for the comparison between constrained TransFusion and our method 

``````
# Brief description
This is the code for investigating whether incorporating a constraint into an existing transfer-learning procedure could lead to better performance than our proposed
method, as described in Section S4.1 in the Supplementary Material.

# Run simulation

For the simulation, we only need to run `Func-sim.R` or `Func-sim-Copy1.R` following the guideline `main.R`, which instructs the order of code execution. Specifically, the different data generation mechanism corresponds to different order.
For the plot, we only need to execute `plot_tf.R`.

Required R package:
```
install.packages("MASS","glmtrans","Matrix","glmnet","dplyr","writexl","magrittr","Rcpp","RcppArmadillo","tidyverse","doParallel","foreach")
install.packages("ggplot2","ggpubr","ggh4x","patchwork","cowplot","scales") 
```
### Parameters in `Func-sim.R` and `Func-sim-Copy1.R`


1. data parameters:
- `n_target`: sample size for the target domain
- `n_source_per`: sample size for each source domain
- `M`: total source numbers 
- `p`: the dimension of compositional covariates
- `p_n`: the dimension of non-compositional covariates
- `sig.delta1_list`: the perturbation magnitude list of compositional covariates in informative sources(Scenario II)
- `sig.delta2`: the perturbation magnitude of compositional covariates in non-informative sources(Scenario II)
- `sig.delta_a1`: the perturbation magnitude of non-compositional covariates in informative sources(Scenario II)
- `sig.delta_a2`: the perturbation magnitude of non-compositional covariates in non-informative sources(Scenario II)
- `num_perturbed_groups_list`: the number of selected groups to be perturbed for informative sources
- `snr`: signal-noise ratio, using in the generation of the noise's standard deviation 
- `h`: the number of selected variables to be perturbed for informative sources
- `q`: the number of selected variables to be perturbed for non-informative sources(Scenario I and Scenario II)
- `exact`: the type of perturbation(TRUE for Scenario II, and FALSE for Scenario I)
- `size.A0_list`: the number of informative sources when both informative and non-informative sources coexist
- `M_list`: the number of informative sources(and total source number) when there are all informative sources

2. model parameters:
- `epsilon`: the added threshold controlling the strictness of source selection

3. simulation parameters:
- `nsim`: number of simulations
  
### Outputs
Files will be automatedly saved in `results.xlsx` and `results.RData`, and `results.xlsx` can be directly used for plotting.

