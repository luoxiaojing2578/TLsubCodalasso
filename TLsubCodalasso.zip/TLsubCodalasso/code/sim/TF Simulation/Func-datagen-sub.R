# Function(Simulation-Compositional-Data generation)

### Normalize(sub)
sub_normalize <- function(raw_mat, tind) {
  C_mat <- matrix(0, nrow = nrow(raw_mat), ncol = ncol(raw_mat))
  for (g in 1:(length(tind) - 1)) {
    group_idx <- (tind[g] + 1):tind[g + 1]
    tmp <- exp(raw_mat[, group_idx, drop = FALSE])
    C_mat[, group_idx] <- tmp / rowSums(tmp)
  }
  return(C_mat)
}

### Data generation function
Data.gen <- function(n.vec, M, p, B, snr, seed=2025) {
  set.seed(seed)
  
  p_n <- B$p_n
  a_target <- B$a_target
  A <- B$A
  tind <- B$tind 
  ngrp <- length(tind)-1
  target_beta <- B$beta
  
  ref_indices <- tind[2:length(tind)] 
  target_beta_z <- target_beta[-ref_indices] 
  
  mu_vec_target <- c(rep(log(p / 2), 5), rep(0, p - 5))
  Sigma <- matrix(0, nrow=p, ncol=p)
  for (i in 1:p) {
    for (j in 1:p) {
      Sigma[i,j] <- 0.2^abs(i - j)
    }
  }
  
  Sigma1 <- Sigma
  
  X_combined <- matrix(nrow = 0, ncol = p)
  X_clr_combined <- matrix(nrow = 0, ncol = p) 
  Z_combined <- matrix(nrow = 0, ncol = p - ngrp) 
  N_combined <- if (p_n == 0) matrix(nrow=0, ncol=0) else matrix(nrow = 0, ncol = p_n)
  y_combined <- y_z_combined <- y_clr_combined <- numeric(0) 
  
  X_test_combined <- matrix(nrow = 0, ncol = p)
  X_test_clr_combined <- matrix(nrow = 0, ncol = p) 
  Z_test_combined <- matrix(nrow = 0, ncol = p - ngrp)
  N_test_combined <- if (p_n == 0) matrix(nrow=0, ncol=0) else matrix(nrow = 0, ncol = p_n)
  y_test_combined <- y_test_z_combined <- y_test_clr_combined <- numeric(0)
  
  sub_comp_alr <- function(C_total, tind) {
    Z_sub_list <- list()
    for (g in 1:(length(tind)-1)) {
      group_idx <- (tind[g]+1):tind[g+1]
      C_g <- C_total[, group_idx, drop=FALSE]
      p_g <- length(group_idx)
      ref_col <- C_g[, p_g] 
      numerator_cols <- C_g[, -p_g, drop=FALSE]
      Z_g <- log(sweep(numerator_cols, 1, ref_col, "/"))
      Z_sub_list[[g]] <- Z_g
    }
    return(do.call(cbind, Z_sub_list))
  }
  
  sub_comp_clr <- function(C_total, tind) {
    CLR_list <- list()
    for (g in 1:(length(tind)-1)) {
      group_idx <- (tind[g]+1):tind[g+1]
      log_C_g <- log(C_total[, group_idx, drop=FALSE])
      clr_g <- log_C_g - rowMeans(log_C_g)
      CLR_list[[g]] <- clr_g
    }
    return(do.call(cbind, CLR_list))
  }
  
  for (type in c("train", "test")) {
    n_curr <- n.vec[1]
    N_curr <- if (p_n > 0) {
      mat <- matrix(1, nrow = n_curr, ncol = p_n)
      if (p_n > 1) mat[, -1] <- rbinom(n_curr * (p_n - 1), 1, 0.5)
      mat
    } else matrix(nrow = n_curr, ncol = 0)
    
    x_raw <- mvrnorm(n_curr, mu = mu_vec_target, Sigma = Sigma)
    C_total <- sub_normalize(x_raw, tind)
    x_log <- log(C_total)
    
    x_clr <- sub_comp_clr(C_total, tind)
    z_sub <- sub_comp_alr(C_total, tind)
    
    y_val <- as.vector(if(p_n > 0) N_curr %*% a_target + x_log %*% target_beta else x_log %*% target_beta)
    y_z_val <- as.vector(if(p_n > 0) N_curr %*% a_target + z_sub %*% target_beta_z else z_sub %*% target_beta_z)
    y_clr_val <- as.vector(if(p_n > 0) N_curr %*% a_target + x_clr %*% target_beta else x_clr %*% target_beta)
    
    snr_sigma <- norm(matrix(y_val), "2") / sqrt(n_curr) / snr
    common_noise <- rnorm(n_curr)
    y_val <- y_val + snr_sigma * common_noise
    y_z_val <- y_z_val + snr_sigma * common_noise
    y_clr_val <- y_clr_val + snr_sigma * common_noise 
    
    if (type == "train") {
      X_combined <- x_log; X_clr_combined <- x_clr; Z_combined <- z_sub; 
      N_combined <- N_curr; y_combined <- y_val; y_z_combined <- y_z_val; y_clr_combined <- y_clr_val
    } else {
      X_test_combined <- x_log; X_test_clr_combined <- x_clr; Z_test_combined <- z_sub; 
      N_test_combined <- N_curr; y_test_combined <- y_val; y_test_z_combined <- y_z_val; y_test_clr_combined <- y_clr_val
    }
  }
  
  for (k in 1:M) {
    set.seed(seed + 100*k)
    s_beta <- B$W[,k]
    s_beta_z <- s_beta[-ref_indices]
    s_a <- A[,k]
    n_s <- n.vec[k+1]
    
    N_s <- if (p_n > 0) {
      mat <- matrix(1, nrow = n_s, ncol = p_n)
      if (p_n > 1) mat[, -1] <- rbinom(n_s * (p_n - 1), 1, 0.5)
      mat
    } else matrix(nrow = n_s, ncol = 0)
    
    x_s_raw <- mvrnorm(n_s, mu = mu_vec_target, Sigma = Sigma1)
    C_s_total <- sub_normalize(x_s_raw, tind)
    
    z_s_sub <- sub_comp_alr(C_s_total, tind)
    x_s_clr <- sub_comp_clr(C_s_total, tind)
    x_s_log <- log(C_s_total)
    
    y_s <- as.vector(if(p_n > 0) N_s %*% s_a + x_s_log %*% s_beta else x_s_log %*% s_beta)
    y_s_z <- as.vector(if(p_n > 0) N_s %*% s_a + z_s_sub %*% s_beta_z else z_s_sub %*% s_beta_z)
    y_s_clr <- as.vector(if(p_n > 0) N_s %*% s_a + x_s_clr %*% s_beta else x_s_clr %*% s_beta)
    
    s_sigma <- norm(matrix(y_s), "2") / sqrt(n_s) / snr
    common_noise_s <- rnorm(n_s)
    y_s <- y_s + s_sigma * common_noise_s
    y_s_z <- y_s_z + s_sigma * common_noise_s
    y_s_clr <- y_s_clr + s_sigma * common_noise_s
    
    X_combined <- rbind(X_combined, x_s_log)
    X_clr_combined <- rbind(X_clr_combined, x_s_clr)
    Z_combined <- rbind(Z_combined, z_s_sub)
    if(p_n > 0) N_combined <- rbind(N_combined, N_s)
    y_combined <- c(y_combined, y_s)
    y_z_combined <- c(y_z_combined, y_s_z)
    y_clr_combined <- c(y_clr_combined, y_s_clr)
  }
  
  return(list(
    data_train = list(X=X_combined, X_clr=X_clr_combined, Z=Z_combined, N=N_combined, 
                      y=y_combined, y_z=y_z_combined, y_clr=y_clr_combined,
                      target_beta=target_beta, target_beta_z=target_beta_z, target_a = a_target, tind=tind),
    data_test = list(X=X_test_combined, X_clr=X_test_clr_combined, Z=Z_test_combined, 
                     N=N_test_combined, y=y_test_combined, y_z=y_test_z_combined, y_clr=y_test_clr_combined)
  ))
}