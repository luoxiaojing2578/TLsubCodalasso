# Function(Simulation)

library(ggplot2)
library(tidyr)
library(dplyr)
library(writexl)

###################### Experimental Setup ######################
M <- 10             
size.A0 <- 5       
n_target <- 100 
n_source_per <- 100 
n.vec <- c(n_target, rep(n_source_per, M))
p <- 100
p_n <- 0
snr <- 3
epsilon_values <- c(0.0001, 0.001, 0.01, 0.05, 0.1, 1)
nsim_sens <- 100
seed <- 2025

B <- Coef.gen(
  h=2, q=2, p=p, M=M, size.A0=size.A0, 
  sig.delta1=0.1, sig.delta2=0.5, 
  exact=FALSE, seed=seed, p_n=p_n,
  num_perturbed_groups=2
)

sens_eps_metrics_list <- list()
sens_eps_coefs_list   <- list()
sens_eps_sources_list <- list()
format_sens_coef <- function(sim, eps, type, est_a, est_beta, p_n) {
  res <- data.frame(sim_id = sim, eps = eps, type = type, stringsAsFactors = FALSE)
  if (p_n > 0) {
    a_val <- if(!is.null(est_a)) as.numeric(est_a) else rep(NA, p_n)
    a_df <- as.data.frame(t(setNames(a_val, paste0("a", seq_len(p_n)))))
    res <- cbind(res, a_df)
  }
  beta_val <- as.numeric(est_beta)
  beta_df <- as.data.frame(t(setNames(beta_val, paste0("b", seq_len(length(beta_val))))))
  return(cbind(res, beta_df))
}

format_sources <- function(sim, eps, src_vec) {
  src_str <- if(!is.null(src_vec) && length(src_vec) > 0) {
    paste(sort(unique(as.numeric(src_vec))), collapse = ",")
  } else {
    "None"
  }
  data.frame(
    sim_id = sim,
    epsilon = eps,
    selected_sources = src_str,
    n_selected = length(src_vec),
    stringsAsFactors = FALSE
  )
}

###################### Simulation ######################
for(s in 1:nsim_sens) {
  cat("Iteration:", s, "\n")
  
  all_data <- Data.gen(n.vec = n.vec, M = M, p = p, B = B, snr = snr, seed = seed + s)
  target_beta <- all_data$data_train$target_beta
  tind <- all_data$data_train$tind
  
  N_input <- all_data$data_train$N
  if (p_n == 0 || is.null(N_input)) {
    N_input <- matrix(0, nrow = sum(n.vec), ncol = 0)
  }
  N_test_input <- all_data$data_test$N
  if (p_n == 0 || is.null(N_test_input)) {
    N_test_input <- matrix(0, nrow = nrow(all_data$data_test$X), ncol = 0)
  }
  
  lambda_init <- compute_lambda_init(all_data$data_train, snr=10)
  lam0_seq <- exp(seq(log(lambda_init*0.005), log(lambda_init*0.5), length.out=50))
  lam0_seq <- unique(sort(lam0_seq, decreasing=TRUE)) 
  
  for(eps in epsilon_values) {
    
    fit <- Trans.Codalasso.sub(
      Xtrain = all_data$data_train$X, 
      Ntrain = N_input, 
      ytrain = all_data$data_train$y, 
      tind = tind, 
      n = n.vec, 
      M = M, 
      epsilon = eps,
      lam0_seq = lam0_seq, 
      seed = seed + s
    )
    
    eval_res <- model_evaluation(
      est_beta = fit$beta_hat, 
      true_beta = target_beta, 
      tind = tind,
      se_beta = fit$se_beta,
      y_test = all_data$data_test$y[1:n.vec[1]],
      X_test = all_data$data_test$X[1:n.vec[1], ],
      N_test = N_test_input[1:n.vec[1], , drop = FALSE]
    )
    
    true_A0 <- 1:size.A0
    total_invalid <- setdiff(1:M, true_A0)
    selected <- fit$selected_sources
    
    tpr_val <- sum(selected %in% true_A0) / length(true_A0)
    fpr_val <- if(length(total_invalid) > 0) sum(selected %in% total_invalid) / length(total_invalid) else 0
    
    eval_final <- c(eval_res, TPR = tpr_val, FPR = fpr_val)
    
    meta_info <- data.frame(sim_id = s, epsilon = eps, stringsAsFactors = FALSE)
    sens_eps_metrics_list[[length(sens_eps_metrics_list) + 1]] <- cbind(meta_info, as.data.frame(t(eval_final)))
    
    sens_eps_coefs_list[[length(sens_eps_coefs_list) + 1]] <- format_sens_coef(
      s, eps, "Var_Epsilon", fit$a_hat, fit$beta_hat, p_n
    )
    
    sens_eps_sources_list[[length(sens_eps_sources_list) + 1]] <- format_sources(s, eps, fit$selected_sources)
  }
}

###################### Results ######################
sens_metrics_raw <- bind_rows(sens_eps_metrics_list)
sens_metrics_raw <- sens_metrics_raw %>%
  mutate(across(everything(), ~ {
    if(cur_column() == "selected_sources") return(.x)
    suppressWarnings(as.numeric(as.character(.x)))
  }))

summary_metrics_eps <- sens_metrics_raw %>%
  group_by(epsilon) %>%
  summarise(
    across(where(is.numeric), list(mean = mean, sd = sd), .names = "{.col}_{.fn}"),
    .groups = "drop"
  ) %>%
  dplyr::select(-contains("sim_id"))

sens_coefs_raw   <- bind_rows(sens_eps_coefs_list)
sens_sources_raw <- bind_rows(sens_eps_sources_list)

write_xlsx(list(
  "Eps_Metrics_Avg" = summary_metrics_eps,
  "Eps_Metrics_Raw" = sens_metrics_raw,
  "Eps_Coefs_Raw"   = sens_coefs_raw,
  "Eps_Sources_Raw" = sens_sources_raw
), path = "Epsilon_Sensitivity_Analysis_Results.xlsx")
