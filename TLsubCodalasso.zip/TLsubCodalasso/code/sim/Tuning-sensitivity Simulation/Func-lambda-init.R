# Function(Simulation-lambda_init)

compute_lambda_init <- function(data_train, snr1=10) {
  X <- data_train$X
  y <- data_train$y - mean(data_train$y)
  n <- nrow(X)
  ngrp <- length(data_train$tind)-1
  scale_grp <- sqrt(log(ngrp + 1))
  lambda_init <- max(abs(t(X) %*% y))/ n / scale_grp * ifelse(snr<5,1.3,1.0)
  max(lambda_init, 1e-10) 
}