# Outline

```
├── README.md
├── main.R # simulation instructor
├── Func-lambda sensitivity.R # sensitivity analysis for lambda(using Oracle-Trans-subCodalasso)
├── Func-epsilon sensitivity.R # sensitivity analysis for epsilon_0(using Trans-subCodalasso)
├── Func-coefgen.R # coeffcient generation
├── Func-datagen-sub.R # data generation
├── Func-lambda-init.R # lambda initialization
├── Func-TransCodaLasso.R # main function
├── model_eval.R # model evaluation 
├── Func-oracle-fixed lambda.R # univariate analysis method(fix lambda_x and vary the values of lambda_y)
├── Func-grid search.R # the function to find the optimal fixed values 
├── cclasso1.cpp # auxiliary function for the constrained optimization problem
├── plot_sens.R # plot for the sensitivity analysis results of epsilon_0

``````
# Brief description
This is the code for the sensitivity analysis of hyperparameters(lambda and epsilon_0), ensuring the justification of the values in simulations and real-data analysis.

# Run simulation

For the simulation, we only need to run `Func-lambda sensitivity.R` to record the results for lambda, and run `Func-epsilon sensitivity.R` to record the results for epsilon. The order of code execution is also shown in the guideline `main.R`.
For the plot, we only need to execute `plot_sens.R`.

Required R package:
```
install.packages("MASS","glmtrans","Matrix","glmnet","dplyr","writexl","magrittr","Rcpp","RcppArmadillo","tidyverse")
```
### Parameters in `Func-sim.R`


1. data parameters:
- `n_target`: sample size for the target domain
- `n_source_per`: sample size for each source domain
- `M`: total source numbers 
- `p`: the dimension of compositional covariates
- `p_n`: the dimension of non-compositional covariates
- `sig.delta1`: the perturbation magnitude list of compositional covariates in informative sources(Scenario II)
- `sig.delta2`: the perturbation magnitude of compositional covariates in non-informative sources(Scenario II)
- `sig.delta_a1`: the perturbation magnitude of non-compositional covariates in informative sources(Scenario II)
- `sig.delta_a2`: the perturbation magnitude of non-compositional covariates in non-informative sources(Scenario II)
- `num_perturbed_groups`: the number of selected groups to be perturbed for informative sources
- `snr`: signal-noise ratio, using in the generation of the noise's standard deviation 
- `h`: the number of selected variables to be perturbed for informative sources
- `q`: the number of selected variables to be perturbed for non-informative sources(Scenario I and Scenario II)
- `exact`: the type of perturbation(TRUE for Scenario II, and FALSE for Scenario I)

2. model parameters:
- `epsilon`: the added threshold controlling the strictness of source selection

3. simulation parameters:
- `nsim_cv`: number of simulations
- `nsim_sens`: number of simulations
  
### Outputs
Files will be automatedly saved in `results.xlsx`, and `results.xlsx` can be directly used for plotting.

