# Function(Simulation)

library(ggplot2)
library(tidyr)
library(dplyr)
library(writexl)
lam1_opt <- round(lam1_opt,3)
lam2_opt <- round(lam2_opt,3)

lam_seq <- c(0.001, 0.002, 0.005, 0.01, 0.02, 0.05, 0.1, 0.2, 0.5, 1)
nsim_sens <- 100  

sens_metrics1_list <- list()
sens_metrics2_list <- list()
sens_coefs1_list   <- list()
sens_coefs2_list   <- list()

cnt1 <- 1
cnt2 <- 1
format_sens_coef <- function(sim, lam, type, est_a, est_beta, p_n) {
  res <- data.frame(sim_id = sim, lam = lam, type = type, stringsAsFactors = FALSE)
  if (p_n > 0) {
    a_val <- if(!is.null(est_a)) as.numeric(est_a) else rep(NA, p_n)
    a_df <- as.data.frame(t(setNames(a_val, paste0("a", seq_len(p_n)))))
    res <- cbind(res, a_df)
  }
  beta_val <- as.numeric(est_beta)
  beta_df <- as.data.frame(t(setNames(beta_val, paste0("b", seq_len(length(beta_val))))))
  return(cbind(res, beta_df))
}


for(s in 1:nsim_sens) {
  cat("Iteration:", s, "\n")
  
  all_data <- Data.gen(
    n.vec = n.vec,
    M = M,
    p = p,
    B = B,
    snr = snr,
    seed = seed + s
  ) 
  target_beta <- all_data$data_train$target_beta
  tind <- all_data$data_train$tind
  N_input <- all_data$data_train$N
  
  if (p_n == 0 || is.null(N_input)) {
    N_input <- matrix(0, nrow = sum(n.vec), ncol = 0)
  }
  N_test_input <- all_data$data_test$N
  if (p_n == 0 || is.null(N_test_input)) {
    N_test_input <- matrix(0, nrow = nrow(all_data$data_test$X), ncol = 0)
  }
  
  for(l1 in lam_seq) {
    fit <- Oracle_Fit_Fixed_Lambda(
      X = all_data$data_train$X, N = all_data$data_train$N, y = all_data$data_train$y,
      tind = tind, A0 = 1:M, n.vec = n.vec, maxiter = 1000, tol = 1e-5,
      lam1 = l1, lam2 = lam2_opt, seed = seed + l1)
    eval <- model_evaluation(
      est_beta = fit$beta, 
      true_beta = target_beta, 
      tind = tind,
      se_beta = fit$se_beta,
      y_test = all_data$data_test$y[1:n.vec[1]],
      X_test = all_data$data_test$X[1:n.vec[1], ],
      N_test = N_test_input[1:n.vec[1], , drop = FALSE])
    
    meta_info <- data.frame(sim_id = s, lam = l1, type = "Var_Lam1_Fixed_Lam2", stringsAsFactors = FALSE)
    sens_metrics1_list[[cnt1]] <- cbind(meta_info, as.data.frame(eval))
    
    sens_coefs1_list[[cnt1]] <- format_sens_coef(s, l1, "Var_Lam1", fit$a, fit$beta, p_n)
    
    cnt1 <- cnt1 + 1
  }
  
  for(l2 in lam_seq) {
    fit <- Oracle_Fit_Fixed_Lambda(
      X = all_data$data_train$X, N = all_data$data_train$N, y = all_data$data_train$y,
      tind = tind, A0 = 1:M, n.vec = n.vec, maxiter = 1000, tol = 1e-5,
      lam1 = lam1_opt, lam2 = l2, seed = seed + l2)
    eval <- model_evaluation(
      est_beta = fit$beta, 
      true_beta = target_beta, 
      tind = tind,
      se_beta = fit$se_beta,
      y_test = all_data$data_test$y[1:n.vec[1]],
      X_test = all_data$data_test$X[1:n.vec[1], ],
      N_test = N_test_input[1:n.vec[1], , drop = FALSE])    
    
    meta_info <- data.frame(sim_id = s, lam = l2, type = "Fixed_Lam1_Var_Lam2", stringsAsFactors = FALSE)
    sens_metrics2_list[[cnt2]] <- cbind(meta_info, as.data.frame(eval))
    
    sens_coefs2_list[[cnt2]] <- format_sens_coef(s, l2, "Var_Lam2", fit$a, fit$beta, p_n)
    
    cnt2 <- cnt2 + 1
  }
}

sens_metrics1 <- bind_rows(sens_metrics1_list)
sens_metrics2 <- bind_rows(sens_metrics2_list)

sens_coefs1 <- bind_rows(sens_coefs1_list)
sens_coefs2 <- bind_rows(sens_coefs2_list)

summary_metrics1 <- sens_metrics1 %>%
  group_by(lam) %>% 
  summarise(
    across(where(is.numeric), list(mean = mean, sd = sd), .names = "{.col}_{.fn}"), 
    .groups = "drop"
  ) %>%
  dplyr::select(-contains("sim_id")) 

summary_metrics2 <- sens_metrics2 %>%
  group_by(lam) %>%  
  summarise(
    across(where(is.numeric), list(mean = mean, sd = sd), .names = "{.col}_{.fn}"), 
    .groups = "drop"
  ) %>%
  dplyr::select(-contains("sim_id"))

write_xlsx(list(
  "Sens1_Metrics_Avg" = summary_metrics1, 
  "Sens2_Metrics_Avg" = summary_metrics2, 
  "Sens1_Metrics_Raw" = sens_metrics1,   
  "Sens2_Metrics_Raw" = sens_metrics2,    
  "Sens1_Coefs_Raw"   = sens_coefs1,     
  "Sens2_Coefs_Raw"   = sens_coefs2      
), path = "Sensitivity_Analysis_Results_Complete.xlsx")
