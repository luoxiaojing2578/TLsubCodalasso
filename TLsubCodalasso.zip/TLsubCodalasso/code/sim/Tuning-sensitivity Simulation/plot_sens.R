# epsilon sensitivity

library(ggplot2)
library(dplyr)
library(tidyr)
library(readxl)
library(ggh4x) 

file_path <- "E:/.../epsilon.xlsx"

df_long <- read_excel(file_path, sheet = "Eps_Metrics_Avg") %>%
  dplyr::select(epsilon, l2_mean, TPR_mean, FPR_mean) %>%
  pivot_longer(cols = c(l2_mean, TPR_mean, FPR_mean), 
               names_to = "metric", 
               values_to = "value")

df_long$metric <- factor(df_long$metric, 
                         levels = c("l2_mean", "TPR_mean", "FPR_mean"),
                         labels = c("bold(L[2] ~ error)", "bold(TPR)", "bold(FPR)"))

options(scipen = 999) 
p_final <- ggplot(df_long, aes(x = factor(epsilon), y = value, group = 1, 
                               color = "Trans-subCodalasso", 
                               shape = "Trans-subCodalasso")) +
  geom_line(linewidth = 0.8, alpha = 0.9) +
  geom_point(size = 3, alpha = 0.9) + 
  
  facetted_pos_scales(
    x = list(scale_x_discrete(guide = "axis")),
    y = list(TRUE ~ scale_y_continuous(guide = "axis"))
  ) +
  
  facet_wrap2(
    ~ metric, 
    nrow = 1, 
    scales = "free_y", 
    axes = "all", 
    labeller = label_parsed
  ) +
  
  scale_color_manual(name = "Method", values = c("Trans-subCodalasso" = "#A2AD00")) +
  scale_shape_manual(name = "Method", values = c("Trans-subCodalasso" = 18)) +
  labs(x = expression("ϵ"[0]), y = NULL) +
  
  theme_bw(base_size = 12) + 
  theme(
    strip.background = element_rect(fill = "gray95"),
    strip.text = element_text(face = "bold", size = 13),
    
    legend.position = "bottom",
    legend.box = "horizontal",
    legend.direction = "horizontal",
    legend.title = element_text(face = "bold", size = 14), 
    legend.text = element_text(size = 12),
    legend.key.size = unit(1.2, "lines"),
    legend.spacing.x = unit(0.1, "cm"),
    
    axis.text.x = element_text(size = 9, color = "black", vjust = 0.5),
    axis.text.y = element_text(size = 9, color = "black"),
    
    panel.spacing.x = unit(2, "lines"),
    panel.grid.minor = element_blank(),
    axis.line = element_line(color = "black"),
    
    plot.margin = margin(10, 5, 10, 5)
  ) +
  force_panelsizes(rows = 1, cols = 1) +
  guides(color = guide_legend(title = "Method", ncol = 4, byrow = TRUE),
         shape = guide_legend(title = "Method", ncol = 4, byrow = TRUE))


print(p_final)
ggsave("E:/.../Epsilon_Sensitivity.pdf", p_final, 
       width = 12, height = 4.5, 
       device = cairo_pdf)
