# Function(Simulation)

n_target <- 100    
n_source_per <- 100 
M <- 5           
size.A0 <- 5
n.vec <- c(n_target, rep(n_source_per, M)) 
p <- 100         
p_n <- 0
sig.delta1 <- 0.1
sig.delta2 <- 0.5  
sig.delta_a1 <- 0.1
sig.delta_a2 <- 0.5
num_perturbed_groups <- 2  
snr <- 3          
h <- 2
q <- 2
exact <- FALSE
epsilon <- 0.01
seed <- 2025
B <- Coef.gen(
  h=h, q=q, 
  size.A0=size.A0, 
  M=M, 
  sig.delta1=sig.delta1, 
  sig.delta2=sig.delta2, 
  p=p, 
  exact=exact,
  seed = seed,
  p_n=p_n,
  sig.delta_a1 = sig.delta_a1, 
  sig.delta_a2 = sig.delta_a2,
  num_perturbed_groups = num_perturbed_groups
)

init_values <- c()
for(i in 1:100) {
  test_data <- Data.gen(
    n.vec = n.vec,
    M = M,
    p = p,
    B = B,
    snr = snr,
    seed = seed + i
  ) 
  init_values[i] <- compute_lambda_init(test_data$data_train, snr=10)
}
base_lambda <- mean(init_values) 
lam1_seq <- exp(seq(log(base_lambda*0.005), log(base_lambda*0.5), length.out=100))
lam2_seq <- exp(seq(log(base_lambda*0.005), log(base_lambda*0.5), length.out=100))
nsim_cv  <- 100  

grid_results <- expand.grid(lam1 = lam1_seq, lam2 = lam2_seq)
grid_results$avg_L2 <- 0


for(s in 1:nsim_cv) {
  cat("Simulation:", s, "\n")
  
  all_data <- Data.gen(n.vec = n.vec, M = M, p = p, B = B, snr = snr, seed = seed + s)
  target_beta <- all_data$data_train$target_beta
  tind <- all_data$data_train$tind
  
  for(i in 1:nrow(grid_results)) {
    l1 <- grid_results$lam1[i]
    l2 <- grid_results$lam2[i]
    
    fit <- Oracle_Fit_Fixed_Lambda(
      X = all_data$data_train$X, 
      N = all_data$data_train$N, 
      y = all_data$data_train$y,
      tind = tind, 
      A0 = 1:M, 
      n.vec = n.vec,
      lam1 = l1, 
      lam2 = l2
    )
    
    err <- sqrt(sum((fit$beta - target_beta)^2))
    
    grid_results$avg_L2[i] <- grid_results$avg_L2[i] + (err / nsim_cv)
  }
}

best_idx <- which.min(grid_results$avg_L2)
lam1_opt <- grid_results$lam1[best_idx]
lam2_opt <- grid_results$lam2[best_idx]

cat(round(lam1_opt,3))
cat(round(lam2_opt,3))
cat(grid_results$avg_L2[best_idx])
