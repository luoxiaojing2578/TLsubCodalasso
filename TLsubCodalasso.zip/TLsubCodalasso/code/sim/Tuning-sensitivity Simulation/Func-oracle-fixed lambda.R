# Function(Simulation-lambda_sensitivity)
Oracle_Fit_Fixed_Lambda <- function(X, N, y, tind, A0, n.vec, lam1, lam2,
                                    maxiter=5000, tol=1e-8, seed=2025,
                                    constraint_type = "sub") {
  p <- ncol(X)
  if (is.null(N) || length(N) == 0) {
    p_n <- 0
    N <- matrix(numeric(0), nrow = nrow(X), ncol = 0)
  } else if (is.vector(N)) {
    N <- matrix(N, ncol = 1)
    p_n <- 1
  } else {
    N <- as.matrix(N)
    p_n <- ncol(N)
  }
  
  ind.1 <- 1:n.vec[1]
  size.A0 <- length(A0)
  
  if (size.A0 > 0) {
    k.vec <- c(1, A0 + 1)
    ind.kA <- NULL
    for(k in k.vec) {
      if(k == 1) {
        ind.kA <- c(ind.kA, 1:n.vec[1])
      } else {
        ind.kA <- c(ind.kA, (sum(n.vec[1:(k-1)]) + 1):sum(n.vec[1:k]))
      }
    }
    
    data_step1 <- list(X = X[ind.kA, , drop = FALSE], N = N[ind.kA, , drop = FALSE], y = y[ind.kA], tind = tind)
    fit1 <- classo(data = data_step1, p = p, lam0 = lam1,
                   maxiter = maxiter, tol = tol, seed = seed + s,
                   constraint_type = constraint_type)
    
    a.udb <- as.numeric(fit1$a)
    w.kA <- as.numeric(fit1$beta)
    se_w_kA <- fit1$se_beta
    se_w_a <- fit1$se_a
    
    if (p_n > 0) {
      y_pred1 <- as.vector(N[ind.1, , drop = FALSE] %*% a.udb + X[ind.1, , drop = FALSE] %*% w.kA)
    } else {
      y_pred1 <- as.vector(X[ind.1, , drop = FALSE] %*% w.kA)
    }
    res_residual <- as.numeric(y[ind.1] - y_pred1)
    
    data_step2 <- list(X = X[ind.1, , drop = FALSE], N = N[ind.1, , drop = FALSE], y = res_residual, tind = tind)
    fit2 <- classo(data = data_step2, p = p, lam0 = lam2,
                   maxiter = maxiter, tol = tol, seed = seed + s,
                   constraint_type = constraint_type)
    
    a.delta <- as.numeric(fit2$a)
    delta.kA <- as.numeric(fit2$beta)
    se_delta_kA <- fit2$se_beta
    se_delta_a <- fit2$se_a
    
    beta.kA <- w.kA + delta.kA
    a.KA <- a.udb + a.delta
    
    se_beta_kA <- sqrt(se_w_kA^2 + se_delta_kA^2)
    se_a_KA <- sqrt(se_w_a^2 + se_delta_a^2)
    
  } else { 
    data.target <- list(X = X[ind.1, , drop = FALSE], N = N[ind.1, , drop = FALSE], y = y[ind.1], tind = tind)
    fit_target <- classo(data = data.target, p = p, lam0 = lam1, constraint_type = constraint_type)
    
    beta.kA <- as.numeric(fit_target$beta)
    a.KA <- as.numeric(fit_target$a)
    se_beta_kA <- fit_target$se_beta
    se_a_KA <- fit_target$se_a
    
    w.kA <- beta.kA
    a.udb <- a.KA
    se_w_kA <- se_beta_kA
    se_w_a <- se_a_KA
  }
  
  names(se_beta_kA) <- colnames(X)
  if (p_n > 0 && !is.null(colnames(N))) {
    names(se_a_KA) <- colnames(N)
  }
  
  return(list(
    beta = as.numeric(beta.kA),     
    a = a.KA,                      
    beta.udb = w.kA,               
    a.udb = a.udb,                  
    se_beta = se_beta_kA,           
    se_a = se_a_KA,                
    se_beta_udb = se_w_kA,         
    se_a_udb = se_w_a              
  ))
}


