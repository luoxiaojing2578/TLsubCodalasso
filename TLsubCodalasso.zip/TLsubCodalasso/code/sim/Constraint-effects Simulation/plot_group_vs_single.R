library(ggpubr)
library(patchwork)
library(cowplot)

read_sim_data <- function(paths, d_label) {
  lapply(paths, function(p) {
    df <- read_excel(p, sheet = "Summary_Metrics")
    df$d_val <- d_label
    return(df)
  }) %>% bind_rows()
}

tg_paths <- "final_tg5_Simulation3_4.xlsx"
d_tg <- read_sim_data(tg_paths, "Homogeneous")

yyg_paths <- "final_yyg_Simulation3_4.xlsx"
d_yyg <- read_sim_data(yyg_paths, "Heterogeneous")

df_all <- rbind(d_tg, d_yyg)

df_all$model <- dplyr::case_when(
  df_all$model == "Classo.sub" ~ "subCodalasso",
  df_all$model == "Classo.single" ~ "singleCodalasso",
  df_all$model == "Trans.sub" ~ "Trans-subCodalasso",
  df_all$model == "Trans.single" ~ "Trans-singleCodalasso",
  df_all$model == "Oracle.sub.Raw" ~ "Oracle-Trans-subCodalasso",
  df_all$model == "Oracle.single.Raw" ~ "Oracle-Trans-singleCodalasso",
  df_all$model == "Naive.subCodalasso" ~ "Naive-Trans-subCodalasso",
  df_all$model == "Naive.Codalasso.single" ~ "Naive-Trans-singleCodalasso",
  df_all$model == "Pooled.subCodalasso" ~ "Pooled-subCodalasso",
  df_all$model == "Pooled.Codalasso.single" ~ "Pooled-singleCodalasso",
  df_all$model == "TransLasso.ALR" ~ "Trans-Lasso-alr",
  df_all$model == "TransGLM.ALR" ~ "Trans-GLM-alr",
  TRUE ~ df_all$model
)

df_filtered <- df_all[!grepl("\\.n$", df_all$model, ignore.case = TRUE), ]
target_models <- c(
  "subCodalasso", "singleCodalasso",
  "Trans-subCodalasso", "Trans-singleCodalasso",
  "Oracle-Trans-subCodalasso", "Oracle-Trans-singleCodalasso",
  "Naive-Trans-subCodalasso", "Naive-Trans-singleCodalasso",
  "Pooled-subCodalasso", "Pooled-singleCodalasso",
  "Trans-Lasso-alr",
  "Trans-GLM-alr"
)

df_filtered <- df_filtered %>%
  filter(model %in% target_models) %>%
  mutate(
    algorithm_type = ifelse(grepl("single", model, ignore.case = TRUE), 
                            "Single", "Group"),
    base_algorithm = case_when(
      model == "singleCodalasso" ~ "subCodalasso",
      model == "Trans-singleCodalasso" ~ "Trans-subCodalasso",
      model == "Oracle-Trans-singleCodalasso" ~ "Oracle-Trans-subCodalasso",
      model == "Naive-Trans-singleCodalasso" ~ "Naive-Trans-subCodalasso",
      model == "Pooled-singleCodalasso" ~ "Pooled-subCodalasso",
      TRUE ~ model
    ),
    d_val = factor(d_val, levels = c("Homogeneous", "Heterogeneous")),
    legend_label = case_when(
      model == "singleCodalasso" ~ "singleCodalasso",
      model == "Trans-singleCodalasso" ~ "Trans-singleCodalasso",
      model == "Oracle-Trans-singleCodalasso" ~ "Oracle-Trans-singleCodalasso",
      model == "Naive-Trans-singleCodalasso" ~ "Naive-Trans-singleCodalasso",
      model == "Pooled-singleCodalasso" ~ "Pooled-singleCodalasso",
      TRUE ~ model
    )
  )

my_colors <- c(
  "subCodalasso" = "#E76BF3",
  "Trans-subCodalasso" = "#A2AD00",
  "Oracle-Trans-subCodalasso" = "#2E8B57",
  "Naive-Trans-subCodalasso" = "#3CB371",
  "Pooled-subCodalasso" = "#9400D3",
  "Trans-Lasso-alr" = "#1E90FF",
  "Trans-GLM-alr" = "#F8766D"
)

my_colors_single <- c(
  "singleCodalasso" = "#E76BF3",
  "Trans-singleCodalasso" = "#A2AD00",
  "Oracle-Trans-singleCodalasso" = "#2E8B57",
  "Naive-Trans-singleCodalasso" = "#3CB371",
  "Pooled-singleCodalasso" = "#9400D3"
)

all_colors <- c(my_colors, my_colors_single)

my_shapes_group <- c(
  "subCodalasso" = 15,
  "Trans-subCodalasso" = 18,
  "Oracle-Trans-subCodalasso" = 17,
  "Naive-Trans-subCodalasso" = 10,
  "Pooled-subCodalasso" = 13,
  "Trans-Lasso-alr" = 8,
  "Trans-GLM-alr" = 3
)

my_shapes_single <- c(
  "singleCodalasso" = 15,
  "Trans-singleCodalasso" = 18,
  "Oracle-Trans-singleCodalasso" = 17,
  "Naive-Trans-singleCodalasso" = 10,
  "Pooled-singleCodalasso" = 13
)

all_shapes <- c(my_shapes_group, my_shapes_single)

legend_order_base <- c(
  "subCodalasso",
  "Trans-subCodalasso",
  "Oracle-Trans-subCodalasso",
  "Naive-Trans-subCodalasso",
  "Pooled-subCodalasso",
  "Trans-Lasso-alr",
  "Trans-GLM-alr"
)

legend_order_full <- c(
  "subCodalasso",
  "singleCodalasso",
  "Trans-subCodalasso",
  "Trans-singleCodalasso",
  "Oracle-Trans-subCodalasso",
  "Oracle-Trans-singleCodalasso",
  "Naive-Trans-subCodalasso",
  "Naive-Trans-singleCodalasso",
  "Pooled-subCodalasso",
  "Pooled-singleCodalasso",
  "Trans-Lasso-alr",
  "Trans-GLM-alr"
)

df_total_l2 <- df_filtered %>%
  dplyr::select(size.A0, model, base_algorithm, algorithm_type, d_val, l2_total_mean) %>%
  mutate(
    d_val = factor(d_val, levels = c("Homogeneous", "Heterogeneous")),
    model = factor(model, levels = legend_order_full),
    line_type = ifelse(algorithm_type == "Single", "dashed", "solid"),
    line_width = ifelse(algorithm_type == "Single", 0.5, 0.3)
  )

p_total <- ggplot(df_total_l2, aes(x = size.A0, y = l2_total_mean, 
                                   color = base_algorithm,
                                   shape = base_algorithm,
                                   group = model)) +  
  geom_line(aes(linetype = algorithm_type, linewidth = algorithm_type), alpha = 0.9) +
  geom_point(size = 1.5, alpha = 0.9) +
  
  facet_grid(. ~ d_val, scales = "free_y") +
  
  scale_x_continuous(breaks = unique(df_total_l2$size.A0)) +
  
  scale_color_manual(
    values = my_colors, 
    name = "", 
    breaks = legend_order_base,
    labels = c("subCodalasso", "Oracle-Trans-subCodalasso", "Trans-subCodalasso", 
               "Naive-Trans-subCodalasso", "Pooled-subCodalasso", "Trans-Lasso-alr", "Trans-GLM-alr")
  ) +
  
  scale_shape_manual(
    values = my_shapes_group, 
    name = "", 
    breaks = legend_order_base,
    labels = c("subCodalasso", "Oracle-Trans-subCodalasso", "Trans-subCodalasso", 
               "Naive-Trans-subCodalasso", "Pooled-subCodalasso", "Trans-Lasso-alr", "Trans-GLM-alr")
  ) +
  
  scale_linetype_manual(
    values = c("Group" = "solid", "Single" = "dashed"),
    name = "",
    labels = c("Single constraint"),
    breaks = c("Single")
  ) +
  
  scale_linewidth_manual(values = c("Group" = 0.3, "Single" = 0.5),
                         guide = "none") +
  
  labs(x = "|A|", y = expression("L"[2] ~ "error")) +
  
  theme_bw(base_size = 12) +
  theme(
    legend.position = "bottom",
    legend.box = "horizontal",
    legend.direction = "horizontal",
    legend.title = element_text(size = 14),
    legend.text = element_text(size = 12),
    legend.key.size = unit(1.2, "lines"),
    legend.spacing.x = unit(0.5, "cm"),
    legend.spacing.y = unit(0.2, "cm"),
    
    panel.spacing = unit(1, "lines"),
    panel.grid.minor = element_blank(),
    plot.margin = margin(10, 20, 10, 20),
    
    strip.background = element_rect(fill = "grey95", color = "black"),
    strip.text = element_text(size = 11),
    
    axis.text = element_text(size = 9, color = "black"),
    axis.text.x = element_text(hjust = 1),
    axis.title = element_text(size = 12)
  ) +
  
  guides(
    linetype = guide_legend(
      nrow = 1,
      byrow = TRUE, 
      order = 1,
      title = "",
      label.position = "right",
      override.aes = list(
        linewidth = 0.5,
        linetype = "dashed"
      ),
      theme = theme(
        legend.background = element_rect(fill = "lightgray", color = "gray50", linewidth = 0.5),
        legend.margin = margin(t = 8, r = 9, b = 8, l = 9)
      )
    ),
    color = guide_legend(
      nrow = 2, 
      byrow = TRUE, 
      order = 2,
      override.aes = list(
        size = 2.5, 
        shape = my_shapes_group[legend_order_base]
      )
    ),
    shape = "none"
  )

print(p_total)

ggsave("E:/.../l2group_vs_single.pdf", p_total, width = 12, height = 7)

df_pred <- df_filtered %>%
  dplyr::select(size.A0, model, base_algorithm, algorithm_type, d_val, pe_mean) %>%
  mutate(
    d_val = factor(d_val, levels = c("Homogeneous", "Heterogeneous")),
    model = factor(model, levels = legend_order_full),
    line_type = ifelse(algorithm_type == "Single", "dashed", "solid"),
    line_width = ifelse(algorithm_type == "Single", 0.5, 0.3)
  )

p_pred <- ggplot(df_pred, aes(x = size.A0, y = pe_mean, 
                                   color = base_algorithm,
                                   shape = base_algorithm,
                                   group = model)) +  
  geom_line(aes(linetype = algorithm_type, linewidth = algorithm_type), alpha = 0.9) +
  geom_point(size = 1.5, alpha = 0.9) +
  
  facet_grid(. ~ d_val, scales = "free_y") +
  
  scale_x_continuous(breaks = unique(df_total_l2$size.A0)) +
  
  scale_color_manual(
    values = my_colors, 
    name = "", 
    breaks = legend_order_base,
    labels = c("subCodalasso", "Oracle-Trans-subCodalasso", "Trans-subCodalasso", 
               "Naive-Trans-subCodalasso", "Pooled-subCodalasso", "Trans-Lasso-alr", "Trans-GLM-alr")
  ) +
  
  scale_shape_manual(
    values = my_shapes_group, 
    name = "", 
    breaks = legend_order_base,
    labels = c("subCodalasso", "Oracle-Trans-subCodalasso", "Trans-subCodalasso", 
               "Naive-Trans-subCodalasso", "Pooled-subCodalasso", "Trans-Lasso-alr", "Trans-GLM-alr")
  ) +
  
  scale_linetype_manual(
    values = c("Group" = "solid", "Single" = "dashed"),
    name = "",
    labels = c("Single constraint"),
    breaks = c("Single")
  ) +
  
  scale_linewidth_manual(values = c("Group" = 0.3, "Single" = 0.5),
                         guide = "none") +
  
  labs(x = "|A|", y = "Prediction error") +
  
  theme_bw(base_size = 12) +
  theme(
    legend.position = "bottom",
    legend.box = "horizontal",
    legend.direction = "horizontal",
    legend.title = element_text(size = 14),
    legend.text = element_text(size = 12),
    legend.key.size = unit(1.2, "lines"),
    legend.spacing.x = unit(0.5, "cm"),
    legend.spacing.y = unit(0.2, "cm"),
    
    panel.spacing = unit(1, "lines"),
    panel.grid.minor = element_blank(),
    plot.margin = margin(10, 20, 10, 20),
    
    strip.background = element_rect(fill = "grey95", color = "black"),
    strip.text = element_text(size = 11),
    
    axis.text = element_text(size = 9, color = "black"),
    axis.text.x = element_text(hjust = 1),
    axis.title = element_text(size = 12)
  ) +
  
  guides(
    linetype = guide_legend(
      nrow = 1,
      byrow = TRUE, 
      order = 1,
      title = "",
      label.position = "right",
      override.aes = list(
        linewidth = 0.5,
        linetype = "dashed"
      ),
      theme = theme(
        legend.background = element_rect(fill = "lightgray", color = "gray50", linewidth = 0.5),
        legend.margin = margin(t = 8, r = 9, b = 8, l = 9)
      )
    ),
    color = guide_legend(
      nrow = 2, 
      byrow = TRUE, 
      order = 2,
      override.aes = list(
        size = 2.5, 
        shape = my_shapes_group[legend_order_base]
      )
    ),
    shape = "none"
  )

print(p_pred)
ggsave("E:/.../PEgroup_vs_single.pdf", p_pred, width = 12, height = 7)

df_l2_sub <- df_total_l2 %>% 
  mutate(metric_type = "L2_error", value = l2_total_mean) %>%
  dplyr::select(size.A0, model, base_algorithm, algorithm_type, d_val, metric_type, value)

df_pe_sub <- df_pred %>% 
  mutate(metric_type = "Prediction_error", value = pe_mean) %>%
  dplyr::select(size.A0, model, base_algorithm, algorithm_type, d_val, metric_type, value)

df_combined <- rbind(df_l2_sub, df_pe_sub)

df_combined$d_val <- factor(df_combined$d_val, levels = c("Homogeneous", "Heterogeneous"))
df_combined$metric_type <- factor(df_combined$metric_type, levels = c("L2_error", "Prediction_error"))

facet_labels <- as_labeller(c(
  "L2_error" = "L[2]~error",
  "Prediction_error" = "Prediction~error",
  "Homogeneous" = "Homogeneous",
  "Heterogeneous" = "Heterogeneous"
), default = label_parsed)

df_combined$metric <- df_combined$metric_type

p_combined <- ggplot(df_combined, aes(x = size.A0, y = value, 
                                      color = base_algorithm,
                                      shape = base_algorithm,
                                      group = model)) +  
  geom_line(aes(linetype = algorithm_type, linewidth = algorithm_type), alpha = 0.9) +
  geom_point(size = 1.5, alpha = 0.9) +
  
  facet_grid2(
    rows = vars(d_val), 
    cols = vars(metric), 
    scales = "free", 
    independent = "y",
    labeller = labeller(
      metric = as_labeller(c(L2_error = "L[2]~error", 
                             Prediction_error = "Prediction~error"),
                           label_parsed),  
      d_val = as_labeller(c(Homogeneous = "Homogeneous", 
                            Heterogeneous = "Heterogeneous"))
    )
  ) +
  
  scale_color_manual(
    values = my_colors, 
    name = "", 
    breaks = legend_order_base,
    labels = c("subCodalasso", "Oracle-Trans-subCodalasso", "Trans-subCodalasso", 
               "Naive-Trans-subCodalasso", "Pooled-subCodalasso", "Trans-Lasso-alr", "Trans-GLM-alr")
  ) +
  scale_shape_manual(
    values = my_shapes_group, 
    name = "", 
    breaks = legend_order_base,
    labels = c("subCodalasso", "Oracle-Trans-subCodalasso", "Trans-subCodalasso", 
               "Naive-Trans-subCodalasso", "Pooled-subCodalasso", "Trans-Lasso-alr", "Trans-GLM-alr")
  ) +
  
  scale_linetype_manual(
    values = c("Group" = "solid", "Single" = "dashed"),
    name = "",
    labels = c("Single constraint"),
    breaks = c("Single")
  ) +
  scale_linewidth_manual(values = c("Group" = 0.3, "Single" = 0.5), guide = "none") +
  
  scale_x_continuous(breaks = unique(df_combined$size.A0)) +
  
  labs(x = "|A|", y = NULL) +
  
  theme_bw(base_size = 12) +
  theme(
    legend.position = "bottom",
    legend.box = "horizontal",
    legend.direction = "horizontal",
    legend.title = element_text(size = 14),
    legend.text = element_text(size = 12),
    legend.key.size = unit(1.2, "lines"),
    legend.spacing.x = unit(0.5, "cm"),
    legend.spacing.y = unit(0.2, "cm"),
    
    panel.spacing = unit(1, "lines"),
    panel.grid.minor = element_blank(),
    plot.margin = margin(10, 20, 10, 20),
    
    strip.background = element_rect(fill = "grey95", color = "black"),
    strip.text = element_text(size = 11),
    
    axis.text = element_text(size = 9, color = "black"),
    axis.title = element_text(size = 12)
  ) +
  
  guides(
    linetype = guide_legend(
      nrow = 1,
      byrow = TRUE, 
      order = 1,
      title = "",
      label.position = "right",
      override.aes = list(linewidth = 0.5, linetype = "dashed"),
      theme = theme(
        legend.background = element_rect(fill = "lightgray", color = "gray50", linewidth = 0.5),
        legend.margin = margin(t = 8, r = 9, b = 8, l = 9)
      )
    ),
    color = guide_legend(
      nrow = 2, 
      byrow = TRUE, 
      order = 2,
      override.aes = list(size = 2.5, shape = my_shapes_group[legend_order_base])
    ),
    shape = "none"
  )

print(p_combined)
ggsave("E:/.../Single constraint2.pdf", p_combined, width = 12, height = 7)
