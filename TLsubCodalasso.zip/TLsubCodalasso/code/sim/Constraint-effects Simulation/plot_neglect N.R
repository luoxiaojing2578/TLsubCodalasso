library(ggpubr)
library(patchwork)
library(cowplot)
library(ggh4x)

read_sim_data <- function(paths, d_label) {
  lapply(paths, function(p) {
    df <- read_excel(p, sheet = "Summary_Metrics")
    df$d_val <- d_label
    return(df)
  }) %>% bind_rows()
}

tg_paths <- "C:/.../final_tg5_Simulation3_4.xlsx"
d_tg <- read_sim_data(tg_paths, "Homogeneous")

yyg_paths <- "C:/.../final_yyg_Simulation3_4.xlsx"
d_yyg <- read_sim_data(yyg_paths, "Heterogeneous")

df_all <- rbind(d_tg, d_yyg)

df_all$model <- dplyr::case_when(
  df_all$model == "Classo.sub" ~ "subCodalasso",
  df_all$model == "Classo.sub.n" ~ "subCodalasso-n",
  df_all$model == "Trans.sub" ~ "Trans-subCodalasso",
  df_all$model == "Oracle.sub.Raw" ~ "Oracle-Trans-subCodalasso",
  df_all$model == "Oracle.sub.Raw.n" ~ "Oracle-Trans-subCodalasso-n",
  df_all$model == "Trans.sub.n" ~ "Trans-subCodalasso-n",
  df_all$model == "Naive.subCodalasso" ~ "Naive-Trans-subCodalasso",
  df_all$model == "Naive.subCodalasso.n" ~ "Naive-Trans-subCodalasso-n",
  df_all$model == "Pooled.subCodalasso" ~ "Pooled-subCodalasso",
  df_all$model == "Pooled.subCodalasso.n" ~ "Pooled-subCodalasso-n",
  df_all$model == "TransLasso.ALR" ~ "Trans-Lasso-alr",
  df_all$model == "TransLasso.ALR.n" ~ "Trans-Lasso-alr-n",
  df_all$model == "TransGLM.ALR" ~ "Trans-GLM-alr",
  df_all$model == "TransGLM.ALR.n" ~ "Trans-GLM-alr-n",
  TRUE ~ df_all$model
)

df_filtered <- df_all[!grepl("single", df_all$model, ignore.case = TRUE), ]

target_models <- c(
  "subCodalasso", "subCodalasso-n",
  "Trans-subCodalasso", "Trans-subCodalasso-n",
  "Oracle-Trans-subCodalasso", "Oracle-Trans-subCodalasso-n",
  "Naive-Trans-subCodalasso", "Naive-Trans-subCodalasso-n",
  "Pooled-subCodalasso", "Pooled-subCodalasso-n",
  "Trans-Lasso-alr", "Trans-Lasso-alr-n",
  "Trans-GLM-alr", "Trans-GLM-alr-n"
)

df_filtered <- df_filtered %>%
  filter(model %in% target_models) %>%
  mutate(
    algorithm_type = ifelse(grepl("-n$", model), "Neglected form", "Correct form"),
    base_algorithm = gsub("-n$", "", model),
    d_val = factor(d_val, levels = c("Homogeneous", "Heterogeneous"))
  )

my_colors <- c(
  "subCodalasso" = "#E76BF3",
  "Trans-subCodalasso" = "#A2AD00",
  "Oracle-Trans-subCodalasso" = "#2E8B57",
  "Naive-Trans-subCodalasso" = "#3CB371",
  "Pooled-subCodalasso" = "#9400D3",
  "Trans-Lasso-alr" = "#1E90FF",
  "Trans-GLM-alr" = "#F8766D"
)

my_shapes <- c(
  "subCodalasso" = 15,
  "Trans-subCodalasso" = 18,
  "Oracle-Trans-subCodalasso" = 17,
  "Naive-Trans-subCodalasso" = 10,
  "Pooled-subCodalasso" = 13,
  "Trans-Lasso-alr" = 8,
  "Trans-GLM-alr" = 3
)

legend_order_base <- c(
  "subCodalasso",
  "Trans-subCodalasso",
  "Oracle-Trans-subCodalasso",
  "Naive-Trans-subCodalasso",
  "Pooled-subCodalasso",
  "Trans-Lasso-alr",
  "Trans-GLM-alr"
)

df_total_l2 <- df_filtered %>%
  dplyr::select(size.A0, model, base_algorithm, algorithm_type, d_val, l2_total_mean) %>%
  mutate(
    d_val = factor(d_val, levels = c("Homogeneous", "Heterogeneous")),
    algorithm_type = factor(algorithm_type, levels = c("Correct form", "Neglected form")),
    base_algorithm = factor(base_algorithm, levels = legend_order_base)
  )

p_total <- ggplot(df_total_l2, aes(x = size.A0, y = l2_total_mean, 
                                   color = base_algorithm,    
                                   shape = base_algorithm,     
                                   group = model)) +          
  geom_line(aes(linetype = algorithm_type, linewidth = algorithm_type), alpha = 0.9) +
  geom_point(size = 1.5, alpha = 0.9) +
  
  facet_grid(. ~ d_val, scales = "free_y") +
  
  scale_x_continuous(breaks = unique(df_total_l2$size.A0)) +
  
  scale_color_manual(
    values = my_colors, 
    name = "", 
    breaks = legend_order_base,
    labels = c("subCodalasso", "Oracle-Trans-subCodalasso", "Trans-subCodalasso", 
               "Naive-Trans-subCodalasso", "Pooled-subCodalasso", "Trans-Lasso-alr", "Trans-GLM-alr")
  ) +
  
  scale_shape_manual(
    values = my_shapes, 
    name = "", 
    breaks = legend_order_base,
    labels = c("subCodalasso", "Oracle-Trans-subCodalasso", "Trans-subCodalasso", 
               "Naive-Trans-subCodalasso", "Pooled-subCodalasso", "Trans-Lasso-alr", "Trans-GLM-alr")
  ) +
  
  scale_linetype_manual(
    values = c("Correct form" = "solid", "Neglected form" = "dashed"),
    name = "",
    labels = c("Neglected form"),
    breaks = c("Neglected form")
  ) +
  
  scale_linewidth_manual(values = c("Correct form" = 0.3, "Neglected form" = 0.5),
                         guide = "none") +
  
  labs(x = "|A|", y = expression("L"[2] ~ "error")) +
  
  theme_bw(base_size = 12) +
  theme(
    legend.position = "bottom",
    legend.box = "horizontal",
    legend.direction = "horizontal",
    legend.title = element_text(size = 14),
    legend.text = element_text(size = 12),
    legend.key.size = unit(1.2, "lines"),
    legend.spacing.x = unit(0.5, "cm"),
    legend.spacing.y = unit(0.2, "cm"),
    
    panel.spacing = unit(1, "lines"),
    panel.grid.minor = element_blank(),
    plot.margin = margin(10, 20, 10, 20),
    
    strip.background = element_rect(fill = "grey95", color = "black"),
    strip.text = element_text(size = 11),
    
    axis.text = element_text(size = 9, color = "black"),
    axis.text.x = element_text(hjust = 1),
    axis.title = element_text(size = 12)
  ) +
  
  guides(
    linetype = guide_legend(
      nrow = 1,
      byrow = TRUE, 
      order = 1,
      title = "",
      label.position = "right",
      override.aes = list(
        linewidth = 0.5,
        linetype = "dashed"
      ),
      theme = theme(
        legend.background = element_rect(fill = "lightgray", color = "gray50", linewidth = 0.5),
        legend.margin = margin(t = 8, r = 9, b = 8, l = 9)
      )
    ),
    color = guide_legend(
      nrow = 2, 
      byrow = TRUE, 
      order = 2,
      override.aes = list(
        size = 2.5, 
        shape = my_shapes[legend_order_base]
      )
    ),
    shape = "none"
  )

print(p_total)
ggsave("E:/.../L2_Form_Correct_vs_Neglected.pdf", p_total, width = 12, height = 7)

df_pred <- df_filtered %>%
  dplyr::select(size.A0, model, base_algorithm, algorithm_type, d_val, pe_mean) %>%
  mutate(
    d_val = factor(d_val, levels = c("Homogeneous", "Heterogeneous")),
    algorithm_type = factor(algorithm_type, levels = c("Correct form", "Neglected form")),
    base_algorithm = factor(base_algorithm, levels = legend_order_base)
  )

p_pred <- ggplot(df_pred, aes(x = size.A0, y = pe_mean, 
                              color = base_algorithm,
                              shape = base_algorithm,
                              group = model)) +  
  geom_line(aes(linetype = algorithm_type, linewidth = algorithm_type), alpha = 0.9) +
  geom_point(size = 1.5, alpha = 0.9) +
  
  facet_grid(. ~ d_val, scales = "free_y") +
  
  scale_x_continuous(breaks = unique(df_pred$size.A0)) +
  
  scale_color_manual(
    values = my_colors, 
    name = "", 
    breaks = legend_order_base,
    labels = c("subCodalasso", "Oracle-Trans-subCodalasso", "Trans-subCodalasso", 
               "Naive-Trans-subCodalasso", "Pooled-subCodalasso", "Trans-Lasso-alr", "Trans-GLM-alr")
  ) +
  
  scale_shape_manual(
    values = my_shapes, 
    name = "", 
    breaks = legend_order_base,
    labels = c("subCodalasso", "Oracle-Trans-subCodalasso", "Trans-subCodalasso", 
               "Naive-Trans-subCodalasso", "Pooled-subCodalasso", "Trans-Lasso-alr", "Trans-GLM-alr")
  ) +
  
  scale_linetype_manual(
    values = c("Correct form" = "solid", "Neglected form" = "dashed"),
    name = "",
    labels = c("Neglected form"),
    breaks = c("Neglected form")
  ) +
  
  scale_linewidth_manual(values = c("Correct form" = 0.3, "Neglected form" = 0.5),
                         guide = "none") +
  
  labs(x = "|A|", y = "Prediction error") +
  
  theme_bw(base_size = 12) +
  theme(
    legend.position = "bottom",
    legend.box = "horizontal",
    legend.direction = "horizontal",
    legend.title = element_text(size = 14),
    legend.text = element_text(size = 12),
    legend.key.size = unit(1.2, "lines"),
    legend.spacing.x = unit(0.5, "cm"),
    legend.spacing.y = unit(0.2, "cm"),
    
    panel.spacing = unit(1, "lines"),
    panel.grid.minor = element_blank(),
    plot.margin = margin(10, 20, 10, 20),
    
    strip.background = element_rect(fill = "grey95", color = "black"),
    strip.text = element_text(size = 11),
    
    axis.text = element_text(size = 9, color = "black"),
    axis.text.x = element_text(hjust = 1),
    axis.title = element_text(size = 12)
  ) +
  
  guides(
    linetype = guide_legend(
      nrow = 1,
      byrow = TRUE, 
      order = 1,
      title = "",
      label.position = "right",
      override.aes = list(linewidth = 0.5, linetype = "dashed"),
      theme = theme(
        legend.background = element_rect(fill = "lightgray", color = "gray50", linewidth = 0.5),
        legend.margin = margin(t = 8, r = 9, b = 8, l = 9)
      )
    ),
    color = guide_legend(
      nrow = 2, 
      byrow = TRUE, 
      order = 2,
      override.aes = list(size = 2.5, shape = my_shapes[legend_order_base])
    ),
    shape = "none"
  )

print(p_pred)
ggsave("E:/PE_Form_Correct_vs_Neglected.pdf", p_pred, width = 12, height = 7)

df_l2_sub <- df_total_l2 %>% 
  mutate(metric_type = "L2_error", value = l2_total_mean) %>%
  dplyr::select(size.A0, model, base_algorithm, algorithm_type, d_val, metric_type, value)

df_pe_sub <- df_pred %>% 
  mutate(metric_type = "Prediction_error", value = pe_mean) %>%
  dplyr::select(size.A0, model, base_algorithm, algorithm_type, d_val, metric_type, value)

df_combined <- rbind(df_l2_sub, df_pe_sub)

df_combined$d_val <- factor(df_combined$d_val, levels = c("Homogeneous", "Heterogeneous"))
df_combined$metric_type <- factor(df_combined$metric_type, levels = c("L2_error", "Prediction_error"))

facet_labels <- as_labeller(c(
  "L2_error" = "L[2]~error",
  "Prediction_error" = "Prediction~error",
  "Homogeneous" = "Homogeneous",
  "Heterogeneous" = "Heterogeneous"
), default = label_parsed)

p_combined <- ggplot(df_combined, aes(x = size.A0, y = value, 
                                      color = base_algorithm,
                                      shape = base_algorithm,
                                      group = model)) +  
  geom_line(aes(linetype = algorithm_type, linewidth = algorithm_type), alpha = 0.9) +
  geom_point(size = 1.5, alpha = 0.9) +
  
  facet_nested(d_val ~ metric_type, 
               scales = "free_y", 
               independent = "y", 
               labeller = facet_labels) +
  
  scale_x_continuous(breaks = unique(df_combined$size.A0)) +
  scale_y_continuous(expand = expansion(mult = c(0.1, 0.1))) +
  
  scale_color_manual(
    values = my_colors, 
    name = "", 
    breaks = legend_order_base,
    labels = c("subCodalasso", "Oracle-Trans-subCodalasso", "Trans-subCodalasso", 
               "Naive-Trans-subCodalasso", "Pooled-subCodalasso", "Trans-Lasso-alr", "Trans-GLM-alr")
  ) +
  scale_shape_manual(
    values = my_shapes, 
    name = "", 
    breaks = legend_order_base,
    labels = c("subCodalasso", "Oracle-Trans-subCodalasso", "Trans-subCodalasso", 
               "Naive-Trans-subCodalasso", "Pooled-subCodalasso", "Trans-Lasso-alr", "Trans-GLM-alr")
  ) +
  
  scale_linetype_manual(
    values = c("Correct form" = "solid", "Neglected form" = "dashed"),
    name = "",
    labels = c("Neglected form"),
    breaks = c("Neglected form")
  ) +
  scale_linewidth_manual(values = c("Correct form" = 0.3, "Neglected form" = 0.5), guide = "none") +
  
  labs(x = "|A|", y = NULL) +
  
  theme_bw(base_size = 12) +
  theme(
    legend.position = "bottom",
    legend.box = "horizontal",
    legend.direction = "horizontal",
    legend.title = element_text(size = 14),
    legend.text = element_text(size = 12),
    legend.key.size = unit(1.2, "lines"),
    legend.spacing.x = unit(0.5, "cm"),
    legend.spacing.y = unit(0.2, "cm"),
    
    panel.spacing = unit(1.5, "lines"), 
    panel.grid.minor = element_blank(),
    plot.margin = margin(10, 20, 10, 20),
    
    strip.background = element_rect(fill = "grey95", color = "black"),
    strip.text = element_text(size = 11),
    
    axis.text.y = element_text(size = 9, color = "black"),
    axis.text.x = element_text(size = 9, color = "black"),
    axis.title = element_text(size = 12),
    axis.line = element_line(color = "black")
  ) +
  
  guides(
    linetype = guide_legend(
      nrow = 1,
      byrow = TRUE, 
      order = 1,
      title = "",
      label.position = "right",
      override.aes = list(
        linewidth = 0.5,
        linetype = "dashed"
      ),
      theme = theme(
        legend.background = element_rect(fill = "lightgray", color = "gray50", linewidth = 0.5),
        legend.margin = margin(t = 8, r = 9, b = 8, l = 9)
      )
    ),
    color = guide_legend(
      nrow = 2, 
      byrow = TRUE, 
      order = 2,
      override.aes = list(
        size = 2.5, 
        shape = my_shapes[legend_order_base]
      )
    ),
    shape = "none"
  )

print(p_combined)
ggsave("E:/Neglected N.pdf", p_pred, width = 12, height = 7)