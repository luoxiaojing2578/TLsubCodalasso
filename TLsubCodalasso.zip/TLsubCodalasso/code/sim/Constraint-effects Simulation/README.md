# Outline

```
├── README.md
├── main.R # simulation instructor
├── Func-sim.R # simulation
├── Func-coefgen-new10.R # coeffcient generation
├── Func-datagen-sub.R # data generation
├── Func-lambda-init.R # lambda initialization
├── Func-TransCodaLasso.R # main function
├── model_eval.R # model evaluation 
├── TransLasso-functions-robust.R # Trans-Lasso(one of the competitors)
├── cclasso1.cpp # auxiliary function for the constrained optimization problem
├── plot_group_vs_single.R # plot for the effect of covariate constraints
├── plot_neglect N.R # plot for the effect of excluding non-compositional covariates 


``````
# Brief description
This is the code for investigating the effect of covariate constraints and excluding non-compositional covariates, as described in Supplementary Material Section S5.2.2.

# Run simulation

For the simulation, we only need to run `Func-sim.R` following the guideline `main.R`, which instructs the order of code execution.
For the plot, we only need to execute `plot_group_vs_single.R` and `plot_neglect N.R` in sequence.

Required R package:
```
install.packages("MASS","glmtrans","Matrix","glmnet","dplyr","writexl","magrittr","Rcpp","RcppArmadillo","tidyverse") 
install.packages("ggplot2","ggpubr","ggh4x","patchwork","cowplot") 
```
### Parameters in `Func-sim.R`


1. data parameters:
- `n_target`: sample size for the target domain
- `n_source_per`: sample size for each source domain
- `M`: total source numbers 
- `p`: the dimension of compositional covariates
- `p_n`: the dimension of non-compositional covariates
- `sig.delta1_list`: the perturbation magnitude list of compositional covariates in informative sources(Scenario II)
- `sig.delta2`: the perturbation magnitude of compositional covariates in non-informative sources(Scenario II)
- `sig.delta_a1`: the perturbation magnitude of non-compositional covariates in informative sources(Scenario II)
- `sig.delta_a2`: the perturbation magnitude of non-compositional covariates in non-informative sources(Scenario II)
- `num_perturbed_groups_list`: the number of selected groups to be perturbed for informative sources
- `snr`: signal-noise ratio, using in the generation of the noise's standard deviation 
- `h`: the number of selected variables to be perturbed for informative sources
- `q`: the number of selected variables to be perturbed for non-informative sources(Scenario I and Scenario II)
- `exact`: the type of perturbation(TRUE for Scenario II, and FALSE for Scenario I)

2. model parameters:
- `epsilon`: the added threshold controlling the strictness of source selection

3. simulation parameters:
- `nsim`: number of simulations
  
### Outputs
Files will be automatedly saved in `results.xlsx` and `results.RData`, and `results.xlsx` can be directly used for plotting.

