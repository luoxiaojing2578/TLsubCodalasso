# Function(Simulation-Coefficient generating)

library(MASS) 
library(stats) 
library(magrittr) 

### Coefficient generating function
Coef.gen<- function(h=2, q=2, size.A0, M, sig.delta1, sig.delta2, 
                    p, exact=TRUE, seed,
                    p_n = 2, sig.delta_a1 = 0.05, sig.delta_a2 = 1,
                    num_perturbed_groups = 8
){ 
  set.seed(seed)
  resample <- function(x, ...) x[sample.int(length(x), ...)]
  
  beta <- c(1, -0.8, 0.4, 0, 0, -0.6, 0, 0, 0, 0, -1.5, 0, 1.2, 0, 0, 0.3, rep(0, p - 16))
  tind <- c(0, 10, 16, 20, 23, 30, 32, 40, p) 
  ngrp <- length(tind)-1 
  
  W <- matrix(rep(beta, each=M), ncol=M, byrow=TRUE) # p行 x M列
  
  if (p_n == 0) { 
    a_target <- numeric(0)  
    A <- matrix(nrow=0, ncol=M)  
  } else { 
    a_target <- c(rep(0, p_n))
    a_target[1] <- 0.5
    a_target[2] <- -0.1
    A <- matrix(rep(a_target, each=M), ncol=M, byrow=TRUE) 
  }
  
  start_idx <- 1
  for (g in 1:ngrp) {
    end_idx <- start_idx + (tind[g+1] - tind[g]) - 1
    group_sum <- sum(beta[start_idx:end_idx])
    if (abs(group_sum) > 1e-6) {
      warning(paste("Warning: The sum of coefficients in group", g, "is", round(group_sum, 6), "which is not exactly 0."))
    }
    start_idx <- end_idx + 1
  }
  
  if (!is.numeric(num_perturbed_groups) || length(num_perturbed_groups) != 1 || 
      num_perturbed_groups < 1 || num_perturbed_groups > ngrp ||
      num_perturbed_groups != as.integer(num_perturbed_groups)) {
    stop(paste("num_perturbed_groups must be a positive integer between 1 and", ngrp,
               "(the current total number of groups is", ngrp, ")!"))
  }
  num_perturbed_groups <- as.integer(num_perturbed_groups)
  perturbed_groups <- sort(resample(1:ngrp, size = num_perturbed_groups, replace = FALSE))
  
  for(k in 1:M){
    set.seed(seed + k)
    if(k <= size.A0){ 
      if(exact){
        for(i in 1:length(perturbed_groups)){
          g <- perturbed_groups[i] 
          group_vars <- (tind[g]+1):tind[g+1] 
          samp0 <- resample(group_vars, h/2, replace=F)
          samp_neg <- resample(setdiff(group_vars, samp0), h/2, replace = F)
          W[samp0,k] <- W[samp0,k] + sig.delta1
          W[samp_neg, k] <- W[samp_neg, k] - sig.delta1
          
        }
        
        if (p_n > 0) {
          target_index <- resample(2:p_n, 1, replace = F)
          A[, k] <- a_target
          A[target_index, k] <- a_target[target_index] + sig.delta_a1
        }
      }else{ 
        for(i in 1:length(perturbed_groups)){
          g <- perturbed_groups[i] 
          group_vars <- (tind[g]+1):tind[g+1]
          samp_pos <- resample(group_vars, h/2, replace = F)
          samp_posneg <- resample(setdiff(group_vars, samp_pos), h/2, replace = FALSE)
          random_values <- runif(length(samp_pos), min = 0, max = 0.05)
          W[samp_pos, k] <- W[samp_pos, k] + random_values
          W[samp_posneg, k] <- W[samp_posneg, k] - random_values
        }
        if (p_n > 0) {
          random_value <- runif(1, min = 0, max = 0.05)
          target_index <- resample(2:p_n, 1, replace = F)
          A[, k] <- a_target
          A[target_index, k] <- a_target[target_index] + random_value
        }
      }
    }else{ 
      if(exact){ 
        for(g in 1:8){
          group_vars <- (tind[g]+1):tind[g+1]
          samp1 <- resample(group_vars, q/2, replace = F)
          samp_neg <- resample(setdiff(group_vars, samp1), q/2, replace = F)
          W[samp1,k] <- W[samp1,k] + sig.delta2
          W[samp_neg, k] <- W[samp_neg, k] - sig.delta2
        }
        if (p_n > 0) {
          target_index <- resample(2:p_n, 1, replace = F)
          A[, k] <- a_target
          A[target_index, k] <- a_target[target_index] + sig.delta_a2
        }
      }else{ 
        for(g in 1:8){
          group_vars <- (tind[g]+1):tind[g+1]
          samp_pos <- resample(group_vars, q/2, replace = F)
          samp_posneg <- resample(setdiff(group_vars, samp_pos), q/2, replace = F)
          random_values <- runif(length(samp_pos), min = 0.5, max = 1)
          W[samp_pos, k] <- W[samp_pos, k] + random_values
          W[samp_posneg, k] <- W[samp_posneg, k] - random_values
        }
        if (p_n > 0) {
          random_value <- runif(1, min = 0.5, max = 1)
          target_index <- resample(2:p_n, 1, replace = F)
          A[, k] <- a_target
          A[target_index, k] <- a_target[target_index] + random_value
        }
      }
    }
    start_idx <- 1
    for (g in 1:ngrp) {
      end_idx <- start_idx + (tind[g+1] - tind[g]) - 1
      group_sum <- sum(W[start_idx:end_idx, k])
      if (abs(group_sum) > 1e-6) {
        warning(paste("Warning: In source domain", k, ", the sum of coefficients in group", g,
                      "is", round(group_sum, 6), "and is not exactly 0!"))
      }
      start_idx <- end_idx + 1
    }
  }
  return(list(W=W, beta=beta, tind=tind,        
              A=A, a_target=a_target, p_n=p_n))  
}
