# Function(Simulation-Coefficient generating)

library(MASS) 
library(stats) 
library(magrittr) 

### Coefficient generating function
Coef.gen <- function(h=2, q=2, size.A0, M, sig.delta1, sig.delta2, 
                     p, exact=TRUE, seed,
                     p_n = 2, sig.delta_a1 = 0.05, sig.delta_a2 = 1,
                     num_perturbed_groups = 8
){ 
  set.seed(seed)
  resample <- function(x, ...) x[sample.int(length(x), ...)]
  
  beta <- c(1, -0.8, 0.4, 0, 0, -0.6, 0, 0, 0, 0, -1.5, 0, 1.2, 0, 0, 0.3, rep(0, p - 16))
  tind <- c(0, 10, 16, 20, 23, 30, 32, 40, p) 
  ngrp <- length(tind)-1 
  
  W <- matrix(rep(beta, each=M), ncol=M, byrow=TRUE) 
  
  if (p_n == 0) {
    a_target <- numeric(0)
    A <- matrix(nrow=0, ncol=M)
  } else {
    a_target <- numeric(p_n) 
    a_target[1:2] <- c(0.5, -0.1) 
    A <- matrix(rep(a_target, each=M), ncol=M, byrow=TRUE) 
  }
  
  start_idx <- 1
  for (g in 1:ngrp) {
    end_idx <- start_idx + (tind[g+1] - tind[g]) - 1
    group_sum <- sum(beta[start_idx:end_idx])
    if (abs(group_sum) > 1e-6) {
      warning(paste("Warning: The sum of coefficients in group", g, "is", round(group_sum, 6), "which is not exactly 0."))
    }
    start_idx <- end_idx + 1
  }
  if (!is.numeric(num_perturbed_groups) || length(num_perturbed_groups) != 1 || 
      num_perturbed_groups < 1 || num_perturbed_groups > ngrp ||
      num_perturbed_groups != as.integer(num_perturbed_groups)) {
    stop(paste("num_perturbed_groups must be a positive integer between 1 and", ngrp,
               "(the current total number of groups is", ngrp, ")!"))
  }
  num_perturbed_groups <- as.integer(num_perturbed_groups)
  
  for(k in 1:M){
    set.seed(seed + k)
    
    is_valid <- (k <= size.A0)
    
    for(g in 1:ngrp){
      group_vars <- (tind[g]+1):tind[g+1]
      
      if(g < ngrp){
        num_to_perturb <- h
      } else {
        base_val <- if(is_valid) p/4 else p/2
        remaining_val <- base_val - h * (ngrp - 1)
        
        num_to_perturb <- floor(max(0, remaining_val))
      }
      
      num_pair <- floor(num_to_perturb / 2)
      if(num_pair > 0 && (2 * num_pair) <= length(group_vars)){
        
        samp_pos <- resample(group_vars, num_pair, replace = FALSE)
        samp_neg <- resample(setdiff(group_vars, samp_pos), num_pair, replace = FALSE)
        
        random_values <- if(is_valid) runif(num_pair, min = 0, max = num_perturbed_groups * h / p) else runif(num_pair, min = 0.5, max = 0.5 + 5 * num_perturbed_groups * h / p)
        
        W[samp_pos, k] <- W[samp_pos, k] + random_values
        W[samp_neg, k] <- W[samp_neg, k] - random_values
      }
    }
    
    if (p_n > 0) {
      random_value <- if(is_valid) runif(p_n, min = 0, max = 0.05) else runif(p_n, min = 0.5, max = 1)

      A[, k] <- a_target + random_value
    }
    
    start_idx <- 1
    for (g in 1:ngrp) {
      end_idx <- start_idx + (tind[g+1] - tind[g]) - 1
      group_sum <- sum(W[start_idx:end_idx, k])
      if (abs(group_sum) > 1e-6) {
        warning(paste("Warning: In source domain", k, ", the sum of coefficients in group", g,
                      "is", round(group_sum, 6), "and is not exactly 0!"))
      }
      start_idx <- end_idx + 1
    }
  }
  
  return(list(W=W, beta=beta, tind=tind, A=A, a_target=a_target, p_n=p_n))
}