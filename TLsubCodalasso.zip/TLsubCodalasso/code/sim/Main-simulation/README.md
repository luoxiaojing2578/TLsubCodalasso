# Outline

```
├── README.md
├── main.R # simulation instructor
├── Func-sim.R # simulation
├── Func-coefgen.R # coeffcient generation for Scenario I and Scenario II(q'=0 or q'=2)
├── Func-coefgen-new2.R # coeffcient generation for Random setting(q'=0 or q'=2)
├── Func-coefgen-new.R # coeffcient generation for Scenario I and Scenario II(q'=10)
├── Func-coefgen-new10.R # coeffcient generation for Random setting(q'=10)
├── Func-datagen-sub.R # data generation
├── Func-lambda-init.R # lambda initialization
├── Func-TransCodaLasso.R # main function
├── model_eval.R # model evaluation 
├── TransLasso-functions-robust.R # Trans-Lasso(one of the competitors)
├── cclasso1.cpp # auxiliary function for the constrained optimization problem
├── plot_sim.R # plot the L2-error in the main text(Section 4.2) and Supplementary Material(Section S5.2) 
├── plot_PE.R # plot the prediction error in the Supplementary Material 
├── VS_processing.R # calculation for the TPR and FDR of all covariates
├── VS_processing_c.R # calculation for the TPR and FDR of only compositional covariates


``````
# Brief description
This is the code for the main simulation in the text, as described in Section 4.2 of the main text and Section S5.2 of the Supplementary Material. Considered there are many R code files describing the coefficient generation mechanism, we just need to replace with different files to get the desired coefficient settings, as described in the Numerical setup(Section 4.1) of the main text.

# Run simulation

For the simulation, we only need to run `Func-sim.R` following the guideline `main.R`, which instructs the order of code execution. If you want to change the way coefficients are generated, all you need to do is to replace the code in "Func-coefgen.R", "Func-coefgen-new2.R", "Func-coefgen-new.R", "Func-coefgen-new10.R".
For the plot, we only need to execute `plot_PE.R` and `plot_sim.R` to obtain the figures in the Section 4.2 of the main text and Section S5.2 of the Supplementary Material.

Required R package:
```
install.packages("MASS","glmtrans","Matrix","glmnet","dplyr","writexl","magrittr","Rcpp","RcppArmadillo","tidyverse")
install.packages("ggplot2","ggh4x","tidyr","purrr")
```
### Parameters in `Func-sim.R`


1. data parameters:
- `n_target`: sample size for the target domain
- `n_source_per`: sample size for each source domain
- `M`: total source numbers 
- `p`: the dimension of compositional covariates
- `p_n`: the dimension of non-compositional covariates
- `sig.delta1_list`: the perturbation magnitude list of compositional covariates in informative sources(Scenario II)
- `sig.delta2`: the perturbation magnitude of compositional covariates in non-informative sources(Scenario II)
- `sig.delta_a1`: the perturbation magnitude of non-compositional covariates in informative sources(Scenario II)
- `sig.delta_a2`: the perturbation magnitude of non-compositional covariates in non-informative sources(Scenario II)
- `num_perturbed_groups_list`: the number of selected groups to be perturbed for informative sources
- `snr`: signal-noise ratio, using in the generation of the noise's standard deviation 
- `h`: the number of selected variables to be perturbed for informative sources
- `q`: the number of selected variables to be perturbed for non-informative sources(Scenario I and Scenario II)
- `exact`: the type of perturbation(TRUE for Scenario II, and FALSE for Scenario I)

2. model parameters:
- `epsilon`: the added threshold controlling the strictness of source selection

3. simulation parameters:
- `nsim`: number of simulations
  
### Outputs
Files will be automatedly saved in `results.xlsx` and `results.RData`. After summarizing the results, we can plot the L2-error and PE using `plot_sim.R` 
and `plot_PE.R`, respectively. And we can summarize the TPR and FDR results using `VS_processing.R` and `VS_processing_c.R`.

