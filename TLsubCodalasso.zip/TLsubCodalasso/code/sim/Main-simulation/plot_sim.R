library(ggplot2)
library(scales)
library(readxl)
library(dplyr)

load_and_label <- function(path, scenario_name, d_name) {
  df <- read_excel(path, sheet = "Summary_Metrics")
  df$scenario <- scenario_name  
  df$d_val <- d_name        
  return(df)
}
# q'=2
#tg0.2
d1 <- load_and_label("C:/.../tg_Simulation1_4.xlsx", "d=4", "Scenario II")
d2 <- load_and_label("C:/.../tg_Simulation1_12.xlsx", "d=12", "Scenario II")
d3 <- load_and_label("C:/.../tg_Simulation2_4.xlsx", "d=4", "Scenario I")
d4 <- load_and_label("C:/.../tg_Simulation2_12.xlsx", "d=12", "Scenario I")
d5 <- load_and_label("C:/.../tg_Simulation3_4.xlsx", "d=4", "Random Setting")
d6 <- load_and_label("C:/.../tg_Simulation3_12.xlsx", "d=12", "Random Setting")
#tg0.5
d1 <- load_and_label("C:/.../tg5_Simulation1_4.xlsx", "d=4", "Scenario II")
d2 <- load_and_label("C:/.../tg5_Simulation1_12.xlsx", "d=12", "Scenario II")
d3 <- load_and_label("C:/.../tg5_Simulation2_4.xlsx", "d=4", "Scenario I")
d4 <- load_and_label("C:/.../tg5_Simulation2_12.xlsx", "d=12", "Scenario I")
d5 <- load_and_label("C:/.../tg5_Simulation3_4.xlsx", "d=4", "Random Setting")
d6 <- load_and_label("C:/.../tg5_Simulation3_12.xlsx", "d=12", "Random Setting")
# yg
d1 <- load_and_label("C:/.../yyg_Simulation1_4.xlsx", "d=4", "Scenario II")
d2 <- load_and_label("C:/.../yyg_Simulation1_12.xlsx", "d=12", "Scenario II")
d3 <- load_and_label("C:/.../yyg_Simulation2_4.xlsx", "d=4", "Scenario I")
d4 <- load_and_label("C:/.../yyg_Simulation2_12.xlsx", "d=12", "Scenario I")
d5 <- load_and_label("C:/.../yyg_Simulation3_4.xlsx", "d=4", "Random Setting")
d6 <- load_and_label("C:/.../yyg_Simulation3_12.xlsx", "d=12", "Random Setting")
df_all <- rbind(d1, d2, d3, d4, d5, d6)
# q'=10
#tg0.2
d1 <- load_and_label("C:/.../tg_Simulation1_4.xlsx", "d=4", "Scenario II")
d2 <- load_and_label("C:/.../tg_Simulation1_12.xlsx", "d=12", "Scenario II")
d3 <- load_and_label("C:/.../tg_Simulation2_4.xlsx", "d=4", "Scenario I")
d4 <- load_and_label("C:/.../tg_Simulation2_12.xlsx", "d=12", "Scenario I")
d5 <- load_and_label("C:/.../tg_Simulation3_4.xlsx", "d=4", "Random Setting")
d6 <- load_and_label("C:/.../tg_Simulation3_12.xlsx", "d=12", "Random Setting")
#tg0.5
d1 <- load_and_label("C:/.../tg5_Simulation1_4.xlsx", "d=4", "Scenario II")
d2 <- load_and_label("C:/.../tg5_Simulation1_12.xlsx", "d=12", "Scenario II")
d3 <- load_and_label("C:/.../tg5_Simulation2_4.xlsx", "d=4", "Scenario I")
d4 <- load_and_label("C:/.../tg5_Simulation2_12.xlsx", "d=12", "Scenario I")
d5 <- load_and_label("C:/.../tg5_Simulation3_4.xlsx", "d=4", "Random Setting")
d6 <- load_and_label("C:/.../tg5_Simulation3_12.xlsx", "d=12", "Random Setting")
#yg
d1 <- load_and_label("C:/.../yyg_Simulation1_4.xlsx", "d=4", "Scenario II")
d2 <- load_and_label("C:/.../yyg_Simulation1_12.xlsx", "d=12", "Scenario II")
d3 <- load_and_label("C:/.../yyg_Simulation2_4.xlsx", "d=4", "Scenario I")
d4 <- load_and_label("C:/.../yyg_Simulation2_12.xlsx", "d=12", "Scenario I")
d5 <- load_and_label("C:/.../yyg_Simulation3_4.xlsx", "d=4", "Random Setting")
d6 <- load_and_label("C:/.../yyg_Simulation3_12.xlsx", "d=12", "Random Setting")
df_all <- rbind(d1, d2, d3, d4, d5, d6)
# q'=0
#tg0.2
d1 <- load_and_label("C:/.../tg_Simulation1_4.xlsx", "d=4", "Scenario II")
d2 <- load_and_label("C:/.../tg_Simulation1_12.xlsx", "d=12", "Scenario II")
d3 <- load_and_label("C:/.../tg_Simulation2_4.xlsx", "d=4", "Scenario I")
d4 <- load_and_label("C:/.../tg_Simulation2_12.xlsx", "d=12", "Scenario I")
d5 <- load_and_label("C:/.../tg_Simulation3_4.xlsx", "d=4", "Random Setting")
d6 <- load_and_label("C:/.../tg_Simulation3_12.xlsx", "d=12", "Random Setting")
#tg0.5
d1 <- load_and_label("C:/.../tg5_Simulation1_4.xlsx", "d=4", "Scenario II")
d2 <- load_and_label("C:/.../tg5_Simulation1_12.xlsx", "d=12", "Scenario II")
d3 <- load_and_label("C:/.../tg5_Simulation2_4.xlsx", "d=4", "Scenario I")
d4 <- load_and_label("C:/.../tg5_Simulation2_12.xlsx", "d=12", "Scenario I")
d5 <- load_and_label("C:/.../tg5_Simulation3_4.xlsx", "d=4", "Random Setting")
d6 <- load_and_label("C:/.../tg5_Simulation3_12.xlsx", "d=12", "Random Setting")
# yg
d1 <- load_and_label("C:/.../yyg_Simulation1_4.xlsx", "d=4", "Scenario II")
d2 <- load_and_label("C:/.../yyg_Simulation1_12.xlsx", "d=12", "Scenario II")
d3 <- load_and_label("C:/.../yyg_Simulation2_4.xlsx", "d=4", "Scenario I")
d4 <- load_and_label("C:/.../yyg_Simulation2_12.xlsx", "d=12", "Scenario I")
d5 <- load_and_label("C:/.../yyg_Simulation3_4.xlsx", "d=4", "Random Setting")
d6 <- load_and_label("C:/.../yyg_Simulation3_12.xlsx", "d=12", "Random Setting")
df_all <- rbind(d1, d2, d3, d4, d5, d6)

df_all$scenario <- factor(df_all$scenario,
                          levels = c("d=4", "d=12"))

df_all$d_val <- factor(df_all$d_val,
                       levels = c("Scenario I", "Scenario II", "Random Setting"))

df_all$model <- dplyr::case_when(
  df_all$model == "Classo.sub" ~ "subCodalasso",
  df_all$model == "Classo.single" ~ "singleCodalasso",
  df_all$model == "Trans.sub" ~ "Trans-subCodalasso",
  df_all$model == "Trans.msub" ~ "Trans-msubCodalasso",
  df_all$model == "Oracle.msub.Raw" ~ "Oracle-Trans-msubCodalasso",
  df_all$model == "Oracle.sub.Raw" ~ "Oracle-Trans-subCodalasso",
  df_all$model == "Oracle.sub.CLR" ~ "Oracle-Trans-subCodalasso-clr",
  df_all$model == "Oracle.single.Raw" ~ "Oracle-Trans-singleCodalasso",
  df_all$model == "Oracle.sub.Single" ~ "Oracle-Trans-singleCodalasso",
  df_all$model == "Naive.subCodalasso" ~ "Naive-Trans-subCodalasso",
  df_all$model == "Pooled.subCodalasso" ~ "Pooled-subCodalasso",
  df_all$model == "TransGLM.ALR" ~ "Trans-GLM-alr",
  df_all$model == "TransGLM.Raw" ~ "Trans-GLM-raw",
  df_all$model == "TransGLM.CLR" ~ "Trans-GLM-clr",
  df_all$model == "TransLasso.CLR" ~ "Trans-Lasso-clr",
  df_all$model == "TransLasso.ALR" ~ "Trans-Lasso-alr",
  df_all$model == "TransLasso.Raw" ~ "Trans-Lasso-raw",
  TRUE ~ df_all$model
)

df_filtered <- df_all[
  !grepl("msub|single|clr|raw", df_all$model, ignore.case = TRUE), 
]
target_order <- c(
  "subCodalasso",
  "Oracle-Trans-subCodalasso",
  "Trans-subCodalasso",
  "Naive-Trans-subCodalasso",
  "Pooled-subCodalasso",
  "Trans-Lasso-alr",   # 紧跟在后面
  "Trans-GLM-alr"
)

df_filtered$model <- factor(df_filtered$model, levels = target_order)

my_shapes <- c(
  "Oracle-Trans-subCodalasso"     = 17, 
  "subCodalasso"                  = 15,
  "Trans-subCodalasso"            = 18, 
  "Trans-Lasso-alr"               = 8, 
  "Trans-GLM-alr"                 = 3,  
  "Naive-Trans-subCodalasso"      = 10, 
  "Pooled-subCodalasso"         = 13 
)

my_colors <- c(
  "Oracle-Trans-subCodalasso"     = "#2E8B57",  
  "Naive-Trans-subCodalasso"      = "#3CB371",  
  "Trans-subCodalasso"            = "#A2AD00",  
  "subCodalasso"                  = "#E76BF3",  
  "Pooled-subCodalasso"         = "#9400D3", 
  "Trans-Lasso-alr"               = "#1E90FF", 
  "Trans-GLM-alr"                 = "#F8766D" 
)

p <- ggplot(df_filtered, aes(x = size.A0, y = l2_total_mean, color = model, shape = model)) +
  geom_line(linewidth = 0.3, alpha = 0.9) +
  geom_point(size = 1.2, alpha = 0.9) +
  facet_grid(scenario ~ d_val) +
  scale_x_continuous(breaks = unique(df_filtered$size.A0)) +
  labs(x = "|A|", y = expression("L"[2] ~ "error"), color = "Method", shape = "Method") +
  theme_bw(base_size = 12) +  
  theme(
    legend.position = "bottom",
    legend.box = "horizontal",
    legend.direction = "horizontal",
    legend.title = element_text( size = 14), 
    legend.text = element_text(size = 12), 
    legend.key.size = unit(1.2, "lines"),
    panel.grid.minor = element_blank(),
    plot.margin = margin(10, 20, 10, 20),
    axis.text = element_text(size = 9), 
    axis.title = element_text(size = 12), 
    strip.text = element_text(size = 11) 
  )

p_final <- p + 
  scale_color_manual(values = my_colors) +
  scale_shape_manual(values = my_shapes) +
  guides(color = guide_legend(nrow = 2, byrow = TRUE), 
         shape = guide_legend(nrow = 2, byrow = TRUE))
print(p_final)

ggsave("E:/.../l2n10c200yg.pdf", p_final, width = 12, height = 7)