# summary for the FDR and TPR results of only compositional covariates

library(tidyverse)
library(readxl)
library(writexl)

folder_path <- "E:/.../"

file_list <- list.files(
  path = folder_path, 
  pattern = "^[^~].*\\.xlsx$", 
  full.names = TRUE
)

for (file_path in file_list) {
  df <- read_excel(file_path)
  required_cols <- c("num_perturbed_groups", "size.A0", "model", "fdp_mean", "tpr_mean")
  if (!all(required_cols %in% names(df))) {
    warning(paste("file", basename(file_path), ": the required columns are missing, so they have been skipped."))
    next
  }
  
  summary_df <- df %>%
    dplyr::select(num_perturbed_groups, size.A0, model, 
           fdp_mean, fdp_sd, tpr_mean, tpr_sd)
  
  new_file_path <- gsub("", "", file_path)
  
  write_xlsx(summary_df, new_file_path)
  
  if (new_file_path != file_path) {
    file.remove(file_path)
  }
  
  message(paste("done", basename(new_file_path)))
}

message("done")
file_list <- list.files(path = folder_path, pattern = "\\.xlsx$", full.names = TRUE)

process_all_files <- function(path) {
  file_name <- basename(path)
  current_type <- case_when(
    grepl("tg5", file_name)  ~ "Homogeneous II",
    grepl("tg", file_name)   ~ "Homogeneous I",
    grepl("yyg", file_name)  ~ "Heterogeneous",
    TRUE                     ~ "Others"
  )
  
  current_scenario <- case_when(
    grepl("Simulation1", file_name) ~ "scenario II",
    grepl("Simulation2", file_name) ~ "scenario I",
    grepl("Simulation3", file_name) ~ "Random Setting",
    TRUE                            ~ "Unknown"
  )
  
  current_setting <- case_when(
    grepl("4\\.xlsx$", file_name)  ~ "d=4",
    grepl("12\\.xlsx$", file_name) ~ "d=12",
    TRUE                           ~ "Unknown"
  )
  
  df <- tryCatch({
    read_excel(path, sheet = "Sheet1")
  }, error = function(e) {
    message(paste("Skip the file (missing form):", file_name))
    return(NULL)
  })
  
  if (!is.null(df)) {
    df <- df %>%
      mutate(
        type = current_type,
        scenario = current_scenario,
        setting = current_setting,
        file_source = file_name 
      ) %>%
      dplyr::select(type, scenario, setting, everything()) 
  }
  
  return(df)
}

final_combined_data <- file_list %>%
  map_df(~ process_all_files(.x))

df_all <- final_combined_data
df_all$model <- dplyr::case_when(
  df_all$model == "Classo.sub" ~ "sC",
  df_all$model == "Classo.single" ~ "singleCodalasso",
  df_all$model == "Trans.sub" ~ "TC",
  df_all$model == "Trans.msub" ~ "Trans-msubCodalasso",
  df_all$model == "Oracle.msub.Raw" ~ "Oracle-Trans-msubCodalasso",
  df_all$model == "Oracle.sub.Raw" ~ "OTC",
  df_all$model == "Oracle.sub.CLR" ~ "Oracle-Trans-subCodalasso-clr",
  df_all$model == "Oracle.single.Raw" ~ "Oracle-Trans-singleCodalasso",
  df_all$model == "Oracle.sub.Single" ~ "Oracle-Trans-singleCodalasso",
  df_all$model == "Naive.subCodalasso" ~ "NTC",
  df_all$model == "Pooled.subCodalasso" ~ "PC",
  df_all$model == "TransGLM.ALR" ~ "TG-a",
  df_all$model == "TransGLM.Raw" ~ "Trans-GLM-raw",
  df_all$model == "TransGLM.CLR" ~ "Trans-GLM-clr",
  df_all$model == "TransLasso.CLR" ~ "Trans-Lasso-clr",
  df_all$model == "TransLasso.ALR" ~ "TL-a",
  df_all$model == "TransLasso.Raw" ~ "Trans-Lasso-raw",
  TRUE ~ df_all$model
)
df_filtered <- df_all[
  !grepl("msub|single|clr|raw", df_all$model, ignore.case = TRUE)& 
    (df_all$size.A0 %in% c(5,10,15)), 
]
target_order <- c(
  "sC",
  "OTC",
  "TC",
  "NTC",
  "PC",
  "TL-a",
  "TG-a"
)

df_filtered$model <- factor(df_filtered$model, levels = target_order)
df_filtered <- df_filtered[!is.na(df_filtered$model), ]
df_filtered$round <- ave(seq_len(nrow(df_filtered)), df_filtered$model, FUN = seq_along)
df_filtered <- df_filtered[order(df_filtered$round, df_filtered$model), ]
df_filtered$round <- NULL
write_xlsx(df_filtered,"E:/.../n10p200-5&10&15.xlsx")
df <- read_excel("E:/.../n10p200-5&10&15.xlsx")
df <- df %>%
  mutate(
    fdp0_mean = ifelse(!is.na(fdp_sd), 
                       paste0(round(fdp_mean, 2), "(", round(fdp_sd, 2), ")"),
                       as.character(round(fdp_mean, 2))),
    tpr0_mean = ifelse(!is.na(tpr_sd), 
                       paste0(round(tpr_mean, 2), "(", round(tpr_sd, 2), ")"),
                       as.character(round(tpr_mean, 2)))
  ) %>%
  dplyr::select(-fdp_sd, -tpr_sd)

write_xlsx(df, "E:/.../n10p200-5&10&15.xlsx")