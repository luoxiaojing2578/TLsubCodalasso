library(readxl)
library(ggplot2)
library(dplyr)
library(ggh4x)
library(purrr)
library(writexl)

folder_path <- "E:/.../n10,p100/" 
file_list <- list.files(path = folder_path, pattern = "\\.xlsx$", full.names = TRUE)
process_all_files <- function(path) {
  file_name <- basename(path)
  current_type <- case_when(
    grepl("tg5", file_name)  ~ "Homogeneous II",
    grepl("tg", file_name)   ~ "Homogeneous I",
    grepl("yyg", file_name)  ~ "Heterogeneous",
    TRUE                     ~ "Others"
  )
  current_scenario <- case_when(
    grepl("Simulation1", file_name) ~ "scenario II",
    grepl("Simulation2", file_name) ~ "scenario I",
    grepl("Simulation3", file_name) ~ "Random Setting",
    TRUE                            ~ "Unknown"
  )
  current_setting <- case_when(
    grepl("4\\.xlsx$", file_name)  ~ "d=4",
    grepl("12\\.xlsx$", file_name) ~ "d=12",
    TRUE                           ~ "Unknown"
  )
  df <- tryCatch({
    read_excel(path, sheet = "Summary_Metrics")
  }, error = function(e) {
    message(paste("Skip the file (missing form):", file_name))
    return(NULL)
  })
  if (!is.null(df)) {
    df <- df %>%
      mutate(
        type = current_type,
        scenario = current_scenario,
        setting = current_setting,
        file_source = file_name 
      ) %>%
      select(type, scenario, setting, everything()) 
  }
  return(df)
}

final_combined_data <- file_list %>%
  map_df(~ process_all_files(.x))

df_all <- final_combined_data
df_all$model <- dplyr::case_when(
  df_all$model == "Classo.sub" ~ "sC",
  df_all$model == "Classo.single" ~ "singleCodalasso",
  df_all$model == "Trans.sub" ~ "TC",
  df_all$model == "Trans.msub" ~ "Trans-msubCodalasso",
  df_all$model == "Oracle.msub.Raw" ~ "Oracle-Trans-msubCodalasso",
  df_all$model == "Oracle.sub.Raw" ~ "OTC",
  df_all$model == "Oracle.sub.CLR" ~ "Oracle-Trans-subCodalasso-clr",
  df_all$model == "Oracle.single.Raw" ~ "Oracle-Trans-singleCodalasso",
  df_all$model == "Oracle.sub.Single" ~ "Oracle-Trans-singleCodalasso",
  df_all$model == "Naive.subCodalasso" ~ "NTC",
  df_all$model == "Pooled.subCodalasso" ~ "PC",
  df_all$model == "TransGLM.ALR" ~ "TG-a",
  df_all$model == "TransGLM.Raw" ~ "Trans-GLM-raw",
  df_all$model == "TransGLM.CLR" ~ "Trans-GLM-clr",
  df_all$model == "TransLasso.CLR" ~ "Trans-Lasso-clr",
  df_all$model == "TransLasso.ALR" ~ "TL-a",
  df_all$model == "TransLasso.Raw" ~ "Trans-Lasso-raw",
  TRUE ~ df_all$model
)
df_filtered <- df_all[
  !grepl("msub|single|clr|raw", df_all$model, ignore.case = TRUE)& 
    (df_all$size.A0 %in% c(5,10,15)), 
]
target_order <- c(
  "sC",
  "OTC",
  "TC",
  "NTC",
  "PC",
  "TL-a",
  "TG-a"
)

df_filtered$model <- factor(df_filtered$model, levels = target_order)
df_filtered <- df_filtered[!is.na(df_filtered$model), ]
df_filtered$round <- ave(seq_len(nrow(df_filtered)), df_filtered$model, FUN = seq_along)
df_filtered <- df_filtered[order(df_filtered$round, df_filtered$model), ]
df_filtered$round <- NULL

write_xlsx(df_filtered,"E:/.../n10c100.xlsx")
df <- read_excel("E:/.../n10c100.xlsx")

df_filtered <- df %>%
  mutate(
    type = case_when(
      type == "Homogeneous I" ~ "Homogeneous (ρ=0.2)",
      type == "Homogeneous II" ~ "Homogeneous (ρ=0.5)",
      type == "Heterogeneous" ~ "Heterogeneous"
    ),
    setting = factor(setting, levels = c("d=4", "d=12"))
  ) %>%
  mutate(
    type = factor(type, 
                  levels = c("Homogeneous (ρ=0.2)", "Homogeneous (ρ=0.5)", "Heterogeneous"))
  )
target_order <- c(
  "subCodalasso",
  "Oracle-Trans-subCodalasso",
  "Trans-subCodalasso",
  "Naive-Trans-subCodalasso",
  "Pooled-subCodalasso",
  "Trans-Lasso-alr",
  "Trans-GLM-alr"
)

df_filtered$model <- factor(df_filtered$model, levels = target_order)

my_shapes <- c(
  "Oracle-Trans-subCodalasso"     = 17,
  "subCodalasso"                  = 15,
  "Trans-subCodalasso"            = 18, 
  "Trans-Lasso-alr"               = 8, 
  "Trans-GLM-alr"                 = 3, 
  "Naive-Trans-subCodalasso"      = 10, 
  "Pooled-subCodalasso"         = 13  
)

my_colors <- c(
  "Oracle-Trans-subCodalasso"     = "#2E8B57", 
  "Naive-Trans-subCodalasso"      = "#3CB371", 
  "Trans-subCodalasso"            = "#A2AD00", 
  "subCodalasso"                  = "#E76BF3", 
  "Pooled-subCodalasso"         = "#9400D3",  
  "Trans-Lasso-alr"               = "#1E90FF", 
  "Trans-GLM-alr"                 = "#F8766D" 
)
p_final <- ggplot(df_filtered, aes(x = size.A0, y = pe_mean, 
                                   color = model, shape = model, group = model)) +
  geom_line(linewidth = 0.5, alpha = 0.9) +
  geom_point(size = 1.2, alpha = 0.9) +
  
  facet_grid(setting ~ type, scales = "free") + 
  
  scale_x_continuous(breaks = unique(df_filtered$size.A0)) +
  scale_color_manual(name = "Method", values = my_colors) +
  scale_shape_manual(name = "Method", values = my_shapes) +
  
  labs(x = "|A|", y = "Prediction error") +
  
  theme_bw(base_size = 12) +
  theme(
    panel.spacing.x = unit(0.5, "lines"),
    panel.spacing.y = unit(0.5, "lines"),
    strip.background = element_rect(fill = "gray95"),
    strip.text = element_text(size = 12),
    legend.position = "bottom",
    axis.text = element_text(color = "black", size = 9),
    axis.title = element_text(size = 12),
    legend.title = element_text(size = 14),
    legend.text = element_text(size = 12),
    legend.key.size = unit(1.2, "lines"),
    panel.grid.minor = element_blank(),
    plot.margin = margin(10, 20, 10, 20)
  ) +
  guides(color = guide_legend(nrow = 2, byrow = TRUE), 
         shape = guide_legend(nrow = 2, byrow = TRUE))

print(p_final)


ggsave("E:/.../PEn10c100RS.pdf", p_final, width = 12, height = 7, device = cairo_pdf)
