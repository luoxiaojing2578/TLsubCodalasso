# Function(Simulation-Coefficient generating)

Coef.gen <- function(h = 2, p, M = 3, seed, p_n = 2, num_perturbed_groups) {
  set.seed(seed)
  
  resample <- function(x, ...) x[sample.int(length(x), ...)]
  
  beta <- c(1, -0.8, 0.4, 0, 0, -0.6, 0, 0, 0, 0, -1.5, 0, 1.2, 0, 0, 0.3, rep(0, p - 16))
  tind <- c(0, 10, 16, 20, 23, 30, 32, 40, p) 
  ngrp <- length(tind) - 1 
  
  W <- matrix(0, nrow = p, ncol = M)
  
  if (p_n == 0) {
    a_target <- numeric(0)
    A <- matrix(nrow = 0, ncol = M)
  } else {
    a_target <- rep(0, p_n)
    a_target[1] <- 0.5
    if(p_n >= 2) a_target[2] <- -0.1
    A <- matrix(0, nrow = p_n, ncol = M)
  }
  
  num_perturbed_groups <- as.integer(num_perturbed_groups)
  
  for (k in 1:2) {
    set.seed(seed + k)
    W[, k] <- beta 
    
    curr_perturbed_groups <- sort(resample(1:ngrp, size = num_perturbed_groups, replace = FALSE))
    
    for (g in curr_perturbed_groups) {
      group_vars <- (tind[g] + 1):tind[g + 1]
      
      samp_pos <- resample(group_vars, h / 2, replace = FALSE)
      samp_neg <- resample(setdiff(group_vars, samp_pos), h / 2, replace = FALSE)
      
      random_values <- runif(length(samp_pos), min = 0.8, max = 1)
      W[samp_pos, k] <- W[samp_pos, k] + random_values
      W[samp_neg, k] <- W[samp_neg, k] - random_values
    }
    
    if (p_n > 0) {
      if (p_n > 2) {
        A[, k] <- a_target 
        random_value <- runif(1, min = 0.8, max = 1)
        target_index <- resample(seq(2, p_n), 1)
        A[target_index, k] <- a_target[target_index] + random_value
      } else if(p_n == 2){
        random_value <- runif(2, min = 0.8, max = 1)
        A[, k] <- a_target + random_value
      } else{
        random_value <- runif(1, min = 0.8, max = 1)
        A[1, k] <- a_target[1] + random_value
      }
    }
  }
  
  W[, 3] <- 3 * beta - W[, 1] - W[, 2]
  
  if (p_n > 0) {
    A[, 3] <- 3 * a_target - A[, 1] - A[, 2]
  }
  
  for (k in 1:M) {
    for (g in 1:ngrp) {
      group_vars <- (tind[g] + 1):tind[g + 1]
      group_sum <- sum(W[group_vars, k])
      if (abs(group_sum) > 1e-6) {
        warning(sprintf("In source domain %d, the sum of coefficients in group %d is %.6f, which is not exactly 0!", 
                        k, g, group_sum))
      }
    }
  }
  
  return(list(W = W, beta = beta, tind = tind, 
              A = A, a_target = a_target, p_n = p_n))
}
