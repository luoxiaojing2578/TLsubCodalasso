# Function(Simulation-Evaluation)

model_evaluation <- function(est_a, 
                             true_a = NULL, 
                             est_beta, 
                             true_beta, 
                             tind = NULL, 
                             fit_model = NULL, 
                             se_beta = NULL, 
                             y_test = NULL, 
                             X_test = NULL, 
                             N_test = NULL) {
  raw_est_beta <- est_beta
  to_unified_clr <- function(b, tind_info) {
    p_original <- tind_info[length(tind_info)] 
    ngrp <- length(tind_info) - 1
    
    if (length(b) == (p_original - ngrp)) {
      clr_list <- list()
      curr_pos <- 1
      for (g in 1:ngrp) {
        p_g <- tind_info[g+1] - tind_info[g]
        group_alr <- b[curr_pos : (curr_pos + p_g - 2)]
        group_full <- c(group_alr, -sum(group_alr))
        clr_list[[g]] <- group_full
        curr_pos <- curr_pos + p_g - 1
      }
      return(unlist(clr_list))
      
    } else if (length(b) == p_original) {
      
      return(b)
      
    } else {
      
      return(b) 
    }
  }
  
  eval_est_beta  <- to_unified_clr(est_beta, tind)
  eval_true_beta <- to_unified_clr(true_beta, tind)
  
  if (length(est_beta) != length(true_beta)) {
    stop("est_beta!=true_beta")
  }
  if (!is.null(true_a)) {
    if (length(est_a) != length(true_a)) {
      stop("est_a!=true_a")
    }
  }
  if (is.null(N_test)) {
    p_n_actual <- 0
  } else {
    p_n_actual <- ifelse(is.matrix(N_test), ncol(N_test), 1)
    if (length(N_test) == 0) p_n_actual <- 0
  }
  del <- eval_est_beta - eval_true_beta 
  l1  <- sum(abs(del)) 
  l2  <- sqrt(sum(del^2)) 
  linf <- max(abs(del)) 
  mse_beta <- mean(del^2) 
  
  if (!is.null(true_a)) {
    del_a <- est_a - true_a 
    l2_a  <- sqrt(sum(del_a^2))
    l1_a <- sum(abs(del_a)); linf_a <- max(abs(del_a)); mse_a <- mean(del_a^2)
  } else {
    l1_a <- l2_a <- linf_a <- mse_a <- NA
  }
  
  del_total <- c(if(!is.null(true_a)) del_a else NULL, del)
  l2_total  <- sqrt(sum(del_total^2))
  l1_total <- sum(abs(del_total)); linf_total <- max(abs(del_total))
  
  if(length(est_beta) > 0){
    sel_threshold <- 1e-6
    selected <- as.numeric(abs(raw_est_beta) > sel_threshold)
    truth    <- as.numeric(abs(true_beta) > 0)
    
    tp0 <- sum(selected == 1 & truth == 1) 
    tn0 <- sum(selected == 0 & truth == 0)  
    fp0 <- sum(selected == 1 & truth == 0)  
    fn0 <- sum(selected == 0 & truth == 1) 
    
    s_count <- sum(selected)              
    fdp0 <- ifelse(s_count == 0, 0, fp0 / s_count)  
    
    tpr0 <- ifelse(sum(truth) == 0, 1, tp0 / sum(truth))
    precision0 <- ifelse(s_count == 0, 1, tp0 / s_count)
    
    f1 <- ifelse((precision0 + tpr0) == 0, 0, 2 * (precision0 * tpr0) / (precision0 + tpr0))
    
  } else {
    warning("No compositional coefficients in the model; variable selection metrics are returned as NA.")
  }
  
  if (!is.null(y_test) && !is.null(X_test)) {
    y_pred <- rep(0, length(y_test))
    
    if (p_n_actual > 0 && length(est_a) > 0) {
      y_pred <- y_pred + as.vector(as.matrix(N_test) %*% est_a)
    }
    
    y_pred <- y_pred + as.vector(as.matrix(X_test) %*% est_beta)
    pe <- mean((y_test - y_pred)^2) 
  } else {
    pe <- NA 
  }
  
  return(list(
    l1_a = l1_a, l2_a = l2_a, linf_a = linf_a,
    l1 = l1, l2 = l2, linf = linf, 
    l1_total = l1_total, l2_total = l2_total, linf_total = linf_total,
    fn = fn0, fp = fp0, tp = tp0, tn = tn0, fdp = fdp0, tpr = tpr0,
    precision = precision0, f1 = f1,
    pe = pe                        
  ))
}
