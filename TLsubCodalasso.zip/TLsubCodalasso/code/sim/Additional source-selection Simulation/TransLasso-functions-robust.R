### TransLasso Algorithm 

ind.set = function(n.vec, k.set){
  ind_re = NULL
  ends = cumsum(n.vec)
  starts = c(1, ends[-length(ends)] + 1)
  for(k in k.set){
    ind_re = c(ind_re, starts[k]:ends[k])
  }
  return(ind_re)
}

agg.fun = function(B, X.test, y.test, total.step=10, selection=F){
  if(sum(B == 0) == ncol(B) * nrow(B)){
    return(list(
      theta = rep(0, ncol(B)),
      beta = rep(0, nrow(B)),
      beta.ew = rep(0, nrow(B))
    ))
  }
  
  p <- nrow(B)
  K <- ncol(B)
  colnames(B) <- NULL
  
  if(selection){
    khat <- which.min(colSums((y.test-X.test%*%B)^2))
    theta.hat <- rep(0, ncol(B))
    theta.hat[khat] <- 1
    beta = B[,khat]
    beta.ew = NULL
  }else{
    resid_sq = colSums((y.test - X.test %*% B)^2)
    theta.hat <- exp(-(resid_sq - min(resid_sq, na.rm=TRUE))/2)
    
    if(sum(theta.hat, na.rm=TRUE) == 0) theta.hat <- rep(1, length(theta.hat))
    theta.hat = theta.hat/sum(theta.hat, na.rm=TRUE)
    
    theta.old = theta.hat
    beta <- as.numeric(B %*% theta.hat)
    beta.ew <- beta
    
    for(ss in 1:total.step){
      log_w = -colSums((y.test-X.test%*%B)^2)/2 + colSums((as.vector(X.test%*%beta)-X.test%*%B)^2)/8
      log_w_adj = log_w - max(log_w, na.rm=TRUE) 
      theta.hat <- exp(log_w_adj)
      
      if(sum(theta.hat, na.rm=TRUE) == 0) theta.hat <- rep(1, length(theta.hat))
      theta.hat <- theta.hat/sum(theta.hat, na.rm=TRUE)
      
      beta <- as.numeric(B%*%theta.hat*1/4+3/4*beta)
      
      diff_val = sum(abs(theta.hat - theta.old))
      if(is.na(diff_val)) {
        warning("Convergence check failed due to NA, breaking loop.")
        break
      }
      
      if(diff_val < 10^(-3)){break}
      theta.old = theta.hat
    }
  }
  list(theta=theta.hat, beta=beta, beta.ew=beta.ew)
}

# Oracle Trans-Lasso 
las.kA = function(X, y, A0, n.vec, lam.const=NULL, l1=T){
  p <- ncol(X)
  size.A0 <- length(A0)
  
  ind.1 <- 1:n.vec[1] 
  
  if(size.A0 > 0){
    ind.kA <- ind.set(n.vec, c(1, A0+1))
    y.A <- y[ind.kA]
    X.A <- X[ind.kA, ]
    
    if(l1){
      if(is.null(lam.const)){
        cv.init <- cv.glmnet(X.A, y.A, nfolds=5, alpha=1,lambda.min.ratio = 0.01)
        lam.const <- cv.init$lambda.min / sqrt(2*log(p)/length(ind.kA))
      }
      
      lambda_w = lam.const * sqrt(2*log(p)/length(ind.kA))
      fit_w = glmnet(X.A, y.A, lambda=lambda_w)
      w.kA = as.numeric(fit_w$beta)
      w.kA = w.kA * (abs(w.kA) >= lambda_w) # Hard thresholding
      
      resid_target = y[ind.1] - X[ind.1, ] %*% w.kA
      lambda_d = lam.const * sqrt(2*log(p)/length(ind.1))
      
      fit_d = glmnet(X[ind.1, ], resid_target, lambda=lambda_d)
      delta.kA = as.numeric(fit_d$beta)
      delta.kA = delta.kA * (abs(delta.kA) >= lambda_d)
      
      beta.kA = w.kA + delta.kA
      lam.const = NA
    } else {
      stop("L0 method requires external package. Please use l1=TRUE.")
    }
  } else {
    cv.init <- cv.glmnet(X[ind.1, ], y[ind.1], nfolds=5, lambda.min.ratio = 0.01)
    lam.const <- cv.init$lambda.min / sqrt(2*log(p)/n.vec[1])
    beta.kA <- as.numeric(coef(cv.init, s='lambda.min')[-1])
    w.kA <- NA
  }
  list(beta.kA=as.numeric(beta.kA), w.kA=w.kA, lam.const=lam.const)
}

# Trans-Lasso 
Trans.lasso = function(X, y, n.vec, I.til, l1=T){
  M = length(n.vec) - 1 
  
  X0.til <- X[I.til, , drop=FALSE]
  y0.til <- y[I.til]
  
  X <- X[-I.til, , drop=FALSE] 
  y <- y[-I.til]
  
  n.vec[1] <- n.vec[1] - length(I.til)
  
  Rhat <- rep(0, M+1)
  ind.1 <- 1:n.vec[1] 
  
  for(k in 2:(M+1)){
    ind.k <- ind.set(n.vec, k)
    Xty.k <- t(X[ind.k,])%*%y[ind.k]/n.vec[k] - t(X[ind.1,])%*%y[ind.1]/n.vec[1]
    top_k_vars = max(1, round(n.vec[1]/3))
    margin.T <- sort(abs(Xty.k[,1]), decreasing=TRUE)[1:top_k_vars]
    Rhat[k] <- sum(margin.T^2)
  }
  
  Tset <- list()
  k0 = 0
  kk.list <- unique(rank(Rhat[-1]))
  
  for(kk in 1:length(kk.list)){
    Tset[[k0+kk]] <- which(rank(Rhat[-1]) <= kk.list[kk])
  }
  Tset <- unique(Tset)
  
  beta.T <- list()
  
  init.re <- las.kA(X=X, y=y, A0=NULL, n.vec=n.vec, l1=l1)
  beta.T[[1]] <- init.re$beta.kA
  
  for(kk in 1:length(Tset)){
    T.k <- Tset[[kk]]
    re.k <- las.kA(X=X, y=y, A0=T.k, n.vec=n.vec, l1=l1, lam.const=init.re$lam.const)
    beta.T[[kk+1]] <- re.k$beta.kA
  }
  
  beta.T <- do.call(cbind, beta.T)
  beta.T <- beta.T[, !duplicated(t(beta.T)), drop=FALSE]
  
  agg.re1 <- agg.fun(B=beta.T, X.test=X0.til, y.test=y0.til)
  
  return(list(coef=agg.re1$beta, theta.hat=agg.re1$theta, candidates=beta.T))
}

fit.TransLasso.Full = function(dataset, K, split_ratio = 0.5) {
  Xdata0 = as.matrix(dataset$X0)
  Ydata0 = as.vector(dataset$y0)
  
  Xdata1 = dataset$X  # List
  Ydata1 = dataset$y  # List
  
  X_source_combined = do.call(rbind, lapply(Xdata1, as.matrix))
  y_source_combined = do.call(c, Ydata1)
  
  X_full = rbind(Xdata0, X_source_combined)
  y_full = c(Ydata0, y_source_combined)
  
  n_vec = c(nrow(Xdata0), sapply(Xdata1, nrow))
  
  n_valid = floor(nrow(Xdata0) * split_ratio)
  n_train = nrow(Xdata0) - n_valid
  I_til = (n_train + 1):nrow(Xdata0)
  
  result = Trans.lasso(X = X_full, y = y_full, n.vec = n_vec, I.til = I_til, l1 = TRUE)
  
  return(result)
}
