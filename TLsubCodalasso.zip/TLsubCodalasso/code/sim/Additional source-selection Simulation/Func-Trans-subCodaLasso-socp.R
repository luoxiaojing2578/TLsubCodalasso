# IP-Trans-sub-Codalasso

library(ROI)
library(ROI.plugin.ecos) 
library(ROI.plugin.glpk) 
library(Matrix)

Trans.Codalasso.rank.socp <- function(Xtrain, Ntrain, ytrain, tind, n, M,
                                     lam0_seq,
                                     alpha = 1,
                                     nfold = 10,
                                     maxiter = 5000, tol = 1e-8,
                                     mu = 1, nu = 1.05,
                                     seed = 2025,
                                     constraint_type = "sub",
                                     split_target_random = TRUE,
                                     socp_lambda = 0) {
  set.seed(seed)
  
  Xtrain <- as.matrix(Xtrain)
  ytrain <- as.numeric(ytrain)
  if (is.null(Ntrain) || length(Ntrain) == 0) {
    Ntrain <- matrix(numeric(0), nrow = nrow(Xtrain), ncol = 0)
  } else if (is.vector(Ntrain)) {
    Ntrain <- matrix(Ntrain, ncol = 1)
  } else {
    Ntrain <- as.matrix(Ntrain)
  }  
  n_target <- n[1]
  p <- ncol(Xtrain)
  p_n <- ncol(Ntrain)
  p_total <- ncol(Ntrain) + ncol(Xtrain)
  
  X_target <- Xtrain[1:n_target, , drop = FALSE]
  N_target <- Ntrain[1:n_target, , drop = FALSE]
  y_target <- ytrain[1:n_target]
  
  Zk <- vector("list", M)
  ysourcelist <- vector("list", M)
  xsourcelist <- vector("list", M)
  Nsourcelist <- vector("list", M)
  
  start_row <- n_target + 1
  for (k in 1:M) {
    end_row <- start_row + n[k + 1] - 1
    xsourcelist[[k]] <- Xtrain[start_row:end_row, , drop = FALSE]
    Nsourcelist[[k]] <- Ntrain[start_row:end_row, , drop = FALSE]
    ysourcelist[[k]] <- ytrain[start_row:end_row]
    Zk[[k]] <- cbind(Nsourcelist[[k]], xsourcelist[[k]])
    start_row <- end_row + 1
  }
  
  data_0 <- list(X = X_target, N = N_target, y = y_target, tind = tind)
  fit_0 <- cv_classo(data = data_0, p = p, lam0_seq = lam0_seq, 
                     nfold = nfold, maxiter = maxiter, tol = tol, mu = mu, nu = nu,
                     constraint_type = constraint_type)
  beta0_init <- as.numeric(fit_0$beta)
  if (is.null(beta0_init) || length(beta0_init) == 0) beta0_init <- rep(0, p)
  a0_init <- as.numeric(fit_0$a)
  if (is.null(a0_init) || length(a0_init) == 0) a0_init <- numeric(0)
  b0_full_init <- c(a0_init, beta0_init)
  
  A_mat <- matrix(0, nrow = p_total, ncol = M)
  for (k in 1:M) {
    Gram <- crossprod(Zk[[k]], Zk[[k]]) 
    Gram0 <- crossprod(Zk[[k]], ysourcelist[[k]])
    A_mat[, k] <- as.vector(Gram0 - Gram %*% b0_full_init) / n_target
  }
  
  solve_internal_roi <- function(A, lam) {
    K <- ncol(A); d <- nrow(A)
    num_vars <- K + d + 1
    
    obj_coeff <- c(rep(lam, K), rep(0, d), 1)
    
    A_lin <- cbind(-A, diag(d), rep(0, d))
    A_lin <- rbind(A_lin, c(rep(1, K), rep(0, d), 0))
    rhs_lin <- c(rep(0, d), 1)
    dir_lin <- c(rep("==", d), ">=")
    
    v_types <- c(rep("B", K), rep("C", d + 1))
    
    prob <- OP(objective = L_objective(L = obj_coeff),
               constraints = L_constraint(L = A_lin, dir = dir_lin, rhs = rhs_lin),
               types = v_types)
    
    soc_indices <- c(K + d + 1, (K + 1):(K + d))
    
    L_soc <- Matrix::sparseMatrix(i = 1:(d+1), j = soc_indices, x = 1, dims = c(d+1, num_vars))
    
    prob$constraints <- c(prob$constraints, 
                          C_constraint(L = L_soc, cones = K_soc(d + 1), rhs = rep(0, d + 1)))
    
    res <- tryCatch({
      ROI_solve(prob, solver = "ecos", control = list(maxit = 1000))
    }, error = function(e) {
      message("ROI error: ", e$message)
      return(NULL)
    })
    
    if(is.null(res) || is.null(solution(res))) return(integer(0))
    
    sol <- solution(res)
    
    selected <- which(sol[1:K] > 0.5)
    return(selected)
  }
  
  socp_best_subset <- tryCatch({
    solve_internal_roi(A_mat, socp_lambda)
  }, error = function(e) {
    warning("SOCP solver failed; falling back to the strategy of selecting no source domains: ", e$message)
    return(integer(0))
  })
  
  other_sources <- setdiff(1:M, socp_best_subset)
  order_idx <- c(socp_best_subset, other_sources)
  
  candidate_sets <- lapply(0:M, function(r) if(r == 0) integer(0) else order_idx[1:r])
  candidate_names <- sapply(0:M, function(r) if(r == 0) "G0_target_only" else paste0("G", r))
  
  if (n_target < 4) {
    stop("The target-domain sample size is too small to perform validation-set-based screening.")
  }
  
  split_idx <- floor(n_target / 2)
  if (split_target_random) {
    idx_all <- sample(1:n_target, n_target, replace = FALSE)
  } else {
    idx_all <- 1:n_target
  }
  idx_I <- sort(idx_all[1:split_idx])
  idx_Ic <- sort(idx_all[(split_idx + 1):n_target])
  
  X_I <- X_target[idx_I, , drop = FALSE]
  N_I <- N_target[idx_I, , drop = FALSE]
  y_I <- y_target[idx_I]
  X_Ic <- X_target[idx_Ic, , drop = FALSE]
  N_Ic <- N_target[idx_Ic, , drop = FALSE]
  y_Ic <- y_target[idx_Ic]
  
  Q_values <- rep(NA_real_, length(candidate_sets))
  
  for (g in seq_along(candidate_sets)) {
    curr_set <- candidate_sets[[g]]
    
    if (length(curr_set) == 0) {
      data_I <- list(X = X_I, N = N_I, y = y_I, tind = tind)
      fit_g <- cv_classo(data = data_I, p = p, lam0_seq = lam0_seq, 
                         nfold = max(2, min(nfold, length(y_I))), 
                         maxiter = maxiter, tol = tol, mu = mu, nu = nu,
                         constraint_type = constraint_type, seed = seed + g)
      beta_g <- fit_g$beta
      if (is.null(beta_g) || length(beta_g) == 0) beta_g <- rep(0, p)
      beta_g <- as.numeric(beta_g)
      a_g <- fit_g$a
      if (is.null(a_g) || length(a_g) == 0) a_g <- numeric(0)
      a_g <- as.numeric(a_g)
    } else {
      X_comb_g <- rbind(X_I, do.call(rbind, xsourcelist[curr_set]))
      N_comb_g <- rbind(N_I, do.call(rbind, Nsourcelist[curr_set]))
      y_comb_g <- c(y_I, unlist(ysourcelist[curr_set]))
      n_vec_g <- c(length(idx_I), n[curr_set + 1])
      
      fit_g <- Oracle.subCodalasso(X = X_comb_g, N = N_comb_g, y = y_comb_g, 
                                   tind = tind, A0 = 1:length(curr_set), 
                                   n.vec = n_vec_g, lam0_seq = lam0_seq,
                                   nfold = nfold, maxiter = maxiter, tol = tol,
                                   mu = mu, nu = nu, seed = seed + g, 
                                   constraint_type = constraint_type)
      beta_g <- fit_g$beta
      if (is.null(beta_g) || length(beta_g) == 0) beta_g <- rep(0, p)
      beta_g <- as.numeric(beta_g)
      a_g <- fit_g$a
      if (is.null(a_g) || length(a_g) == 0) a_g <- numeric(0)
      a_g <- as.numeric(a_g)
    }
    
    if (ncol(N_Ic) > 0) {
      y_pred_Ic <- as.vector(N_Ic %*% a_g + X_Ic %*% beta_g)
    } else {
      y_pred_Ic <- as.vector(X_Ic %*% beta_g)
    }
    Q_values[g] <- mean((y_Ic - y_pred_Ic)^2)
  }
  
  best_idx <- which.min(Q_values)
  best_sources <- candidate_sets[[best_idx]]
  
  if (length(best_sources) > 0) {
    X_final <- rbind(X_target, do.call(rbind, xsourcelist[best_sources]))
    N_final <- rbind(N_target, do.call(rbind, Nsourcelist[best_sources]))
    y_final <- c(y_target, unlist(ysourcelist[best_sources]))
    n_final_vec <- c(n_target, n[best_sources + 1])
    
    final_fit <- Oracle.subCodalasso(X = X_final, N = N_final, y = y_final, 
                                     tind = tind, A0 = 1:length(best_sources), 
                                     n.vec = n_final_vec, lam0_seq = lam0_seq,
                                     nfold = nfold, maxiter = maxiter, tol = tol,
                                     mu = mu, nu = nu, seed = seed, 
                                     constraint_type = constraint_type)
    beta_hat <- final_fit$beta
    if (is.null(beta_hat) || length(beta_hat) == 0) beta_hat <- rep(0, p)
    beta_hat <- as.numeric(beta_hat)
    a_hat <- final_fit$a
    if (is.null(a_hat) || length(a_hat) == 0) a_hat <- numeric(0)
    a_hat <- as.numeric(a_hat)
    se_beta <- final_fit$se_beta
    se_a <- final_fit$se_a
  } else {
    data_full_target <- list(X = X_target, N = N_target, y = y_target, tind = tind)
    final_fit <- cv_classo(data = data_full_target, p = p, lam0_seq = lam0_seq,
                           nfold = nfold, maxiter = maxiter, tol = tol,
                           mu = mu, nu = nu, constraint_type = constraint_type, seed = seed)
    beta_hat <- final_fit$beta
    if (is.null(beta_hat) || length(beta_hat) == 0) beta_hat <- rep(0, p)
    beta_hat <- as.numeric(beta_hat)
    a_hat <- final_fit$a
    if (is.null(a_hat) || length(a_hat) == 0) a_hat <- numeric(0)
    a_hat <- as.numeric(a_hat)
    se_beta <- final_fit$se_beta
    se_a <- final_fit$se_a
  }
  
  return(list(
    beta_hat = beta_hat,
    a_hat = a_hat,
    selected_sources = best_sources,
    socp_recommended = socp_best_subset,
    candidate_Q = Q_values,
    best_candidate_index = best_idx,
    se_beta = se_beta,
    se_a = se_a,
    A_mat = A_mat  
  ))

}
