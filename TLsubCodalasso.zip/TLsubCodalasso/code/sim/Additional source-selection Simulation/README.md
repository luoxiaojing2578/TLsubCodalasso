# Outline

```
├── README.md
├── main.R # simulation instructor
├── Func-sim-socp.R # simulation
├── Func-coefgen-socp.R # coeffcient generation
├── Func-datagen-sub.R # data generation
├── Func-lambda-init.R # lambda initialization
├── Func-TransCodaLasso.R # main function
├── Func-Trans-subCodaLasso-socp.R # a method based on integer programming to achieve the source selection jointly(not a marginal rule) 
├── model_eval.R # model evaluation 
├── utils.R # auxiliary code for TransFusion algorithm
├── TransFusion.CoDa.R # constrained TransFusion algorithm 
├── TransLasso-functions-robust.R # Trans-Lasso(one of the competitors)
├── cclasso1.cpp # auxiliary function for the constrained optimization problem


``````
# Brief description
This is the code for investigating the advantages and disadvantages of joint source detection method, comparing with the marginal rule of our method.

# Run simulation

For the simulation, we only need to run `Func-sim-socp.R` following the guideline `main.R`, which instructs the order of code execution.

Required R package:
```
install.packages("MASS","glmtrans","Matrix","glmnet","dplyr","writexl","magrittr","Rcpp","RcppArmadillo","tidyverse","ROI","ROI.plugin.ecos","ROI.plugin.glpk")
```
### Parameters in `Func-sim-socp.R`


1. data parameters:
- `n_target`: sample size for the target domain
- `n_source_per`: sample size for each source domain
- `M`: total source numbers 
- `p`: the dimension of compositional covariates
- `p_n`: the dimension of non-compositional covariates
- `snr`: signal-noise ratio, using in the generation of the noise's standard deviation 
- `h`: the number of selected variables to be perturbed
- `num_perturbed_groups`: the number of selected groups to be perturbed

2. model parameters:
- `epsilon`: the added threshold controlling the strictness of source selection

3. simulation parameters:
- `nsim`: number of simulations
  
### Outputs
Files will be automatedly saved in `results.xlsx` and `results.RData`.

