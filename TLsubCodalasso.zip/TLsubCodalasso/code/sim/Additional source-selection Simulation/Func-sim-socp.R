# Function(Simulation)

library(dplyr)
library(writexl)
library(glmtrans)
library(glmnet)

###################### Experimental Setup ######################
n_target <- 100   
n_source_per <- 100 
p <- 100
M <- 3
h <- 2
n.vec <- c(n_target, rep(n_source_per, M))
nsim <- 100
p_n <- 0
snr <- 3
seed <- 2025  
epsilon <- 0.01
num_perturbed_groups <- 2
sim_results <- data.frame()  
coef_results <- data.frame() 
source_results <- data.frame() 
for (sim in 1:nsim) {
  cat("\n===========================================\n")
  cat(" sim =", sim, "\n")
  cat("===========================================\n")
  
  B <- Coef.gen(
    h=h,
    p=p,
    M=M,
    p_n=p_n,
    num_perturbed_groups = num_perturbed_groups,
    seed = seed
  )
  
  all_data <- Data.gen(
    n.vec = n.vec,
    M = M,
    p = p,
    B = B,
    snr = snr,
    seed = seed + sim
  )
  
  lambda_init <- compute_lambda_init(all_data$data_train, snr=10)
  lam0_seq <- exp(seq(log(lambda_init*0.005), log(lambda_init*0.5), length.out=50))
  lam0_seq <- unique(sort(lam0_seq, decreasing=TRUE))
  
  M_selected <- 3 
  
  # TransFusion data preparation
  cum_n <- cumsum(n.vec)
  if (p_n > 0) {
    X0_combined <- cbind(all_data$data_train$N[1:cum_n[1], , drop = FALSE], 
                         all_data$data_train$X[1:cum_n[1], , drop = FALSE])
  } else {
    X0_combined <- all_data$data_train$X[1:cum_n[1], , drop = FALSE]
  }
  
  tf_dataset <- list(
    X0 = X0_combined,
    y0 = all_data$data_train$y[1:cum_n[1]],
    
    X = lapply(1:M_selected, function(k) {
      start_idx <- cum_n[k] + 1
      end_idx   <- cum_n[k + 1]
      
      if (p_n > 0) {
        return(cbind(all_data$data_train$N[start_idx:end_idx, , drop = FALSE], 
                     all_data$data_train$X[start_idx:end_idx, , drop = FALSE]))
      } else {
        return(all_data$data_train$X[start_idx:end_idx, , drop = FALSE])
      }
    }),
    
    y = lapply(1:M_selected, function(k) {
      start_idx <- cum_n[k] + 1
      end_idx   <- cum_n[k + 1]
      all_data$data_train$y[start_idx:end_idx]
    })
  )
  
  N_input <- all_data$data_train$N
  if (p_n == 0 || is.null(N_input)) {
    N_input <- matrix(0, nrow = sum(n.vec), ncol = 0)
  }
  N_test_input <- all_data$data_test$N
  if (p_n == 0 || is.null(N_test_input)) {
    N_test_input <- matrix(0, nrow = nrow(all_data$data_test$X), ncol = 0)
  }
  
  # Trans-subCodalasso
  cat("sim =", sim, ", size.A0 =", size.A0, "\n")
  cat("Trans-subCodalasso\n")
  time_trans_sub <- system.time(fit_trans_sub <- Trans.Codalasso.sub(
    Xtrain = all_data$data_train$X,
    Ntrain = N_input,
    ytrain = all_data$data_train$y,
    tind = all_data$data_train$tind,
    n = n.vec,
    M = M,
    lam0_seq = lam0_seq,
    maxiter = 1000, tol = 1e-5,
    seed = seed + sim,
    constraint_type = "sub"
  ))[3]
  
  eval_trans_sub <- model_evaluation(
    est_a = fit_trans_sub$a_hat, 
    true_a = all_data$data_train$target_a,
    est_beta = fit_trans_sub$beta_hat, 
    true_beta = all_data$data_train$target_beta,
    tind = all_data$data_train$tind, 
    fit_model = fit_trans_sub,
    y_test = all_data$data_test$y[1:n.vec[1]],
    X_test = all_data$data_test$X[1:n.vec[1], ],
    N_test = N_test_input[1:n.vec[1], , drop = FALSE]
  )
  
  # IP-Trans-subCodalasso
  cat("IP-Trans-subCodalasso\n")
  
  time_socp <- system.time({
    fit_socp <- Trans.Codalasso.rank.socp(
      Xtrain              = all_data$data_train$X, 
      Ntrain              = N_input, 
      ytrain              = all_data$data_train$y, 
      tind                = all_data$data_train$tind, 
      n                   = n.vec, 
      M                   = M,
      lam0_seq            = lam0_seq,
      alpha               = 1,             
      nfold               = 10,   
      maxiter = 1000, tol = 1e-5,
      seed                = seed + sim,
      constraint_type     = "sub", 
      split_target_random = TRUE,         
      socp_lambda         = 0            
    )
  })[3]
  
  eval_socp <- model_evaluation(
    est_a     = fit_socp$a_hat, 
    true_a    = all_data$data_train$target_a,
    est_beta  = fit_socp$beta_hat, 
    true_beta = all_data$data_train$target_beta,
    tind      = all_data$data_train$tind, 
    fit_model = fit_socp,
    y_test    = all_data$data_test$y_clr[1:n.vec[1]], 
    X_test    = all_data$data_test$X_clr[1:n.vec[1], ], 
    N_test    = N_test_input[1:n.vec[1], , drop = FALSE]
  )
  
  # subCodalasso
  cat("sim =", sim, ", size.A0 =", size.A0, "\n")
  cat("subCodalasso\n")
  raw_N <- all_data$data_train$N
  
  if (!is.null(raw_N) && ncol(as.matrix(raw_N)) > 0) {
    N_sliced <- raw_N[1:n.vec[1], , drop = FALSE]
  } else {
    N_sliced <- matrix(numeric(0), nrow = n.vec[1], ncol = 0)
  }
  
  classo_data <- list(
    X = all_data$data_train$X[1:n.vec[1], , drop = FALSE],
    y = all_data$data_train$y[1:n.vec[1]],
    N = N_sliced,
    tind = all_data$data_train$tind
  )
  
  time_classo <- system.time(fit_classo <- cv_classo(
    data = classo_data,
    p = p,
    lam0_seq = lam0_seq,
    maxiter = 1000,
    tol = 1e-5,
    seed = seed + sim
  ))[3]
  
  eval_classo <- model_evaluation(
    est_a = fit_classo$a,
    true_a = all_data$data_train$target_a,
    est_beta = fit_classo$beta, 
    true_beta = all_data$data_train$target_beta,
    tind = all_data$data_train$tind, 
    se_beta = fit_classo$se_beta,
    y_test = all_data$data_test$y[1:n.vec[1]], 
    X_test = all_data$data_test$X[1:n.vec[1], ], 
    N_test = N_test_input[1:n.vec[1], , drop = FALSE]
  )
  
  # Con-TransFusion
  cat("sim =", sim, ", size.A0 =", size.A0, "\n")
  cat("Con-TransFusion\n")
  
  time_tf <- system.time({
    cv_res_tf <- cv.TransFusion.CoDa(
      dataset = tf_dataset, tind = all_data$data_train$tind,
      p_n = p_n, nfolds = 10, lam0_seq = NULL, seed = seed + sim
    )
  })[3]
  
  eval_tf <- model_evaluation(
    est_a = cv_res_tf$a, true_a = all_data$data_train$target_a,
    est_beta = cv_res_tf$beta, true_beta = all_data$data_train$target_beta,
    tind = all_data$data_train$tind, 
    fit_model = cv_res_tf,
    y_test = all_data$data_test$y[1:n.vec[1]],
    X_test = all_data$data_test$X[1:n.vec[1], ],
    N_test = N_test_input[1:n.vec[1], , drop = FALSE]
  )
  
  # Trans-GLM-alr
  cat("sim =", sim, ", size.A0 =", size.A0, "\n")
  cat("Trans-GLM-alr\n")
  z_target <- all_data$data_train$Z[1:n.vec[1], , drop = FALSE]
  y_z_target <- all_data$data_train$y_z[1:n.vec[1]]
  raw_N_all <- all_data$data_train$N
  p_n <- if (is.null(raw_N_all) || length(raw_N_all) == 0) 0 else ncol(raw_N_all)
  if (p_n > 0) {
    N_target <- raw_N_all[1:n.vec[1], , drop = FALSE]
    z_target_full <- cbind(N_target, z_target)
  } else {
    N_target <- matrix(numeric(0), nrow = n.vec[1], ncol = 0)
    z_target_full <- z_target  
  }
  target_glmtrans_alr <- list(
    x = as.matrix(z_target_full),
    y = as.vector(y_z_target)
  )
  
  source_glmtrans_alr <- list()
  start_idx <- n.vec[1] + 1
  p_x <- ncol(all_data$data_train$Z)
  for (k in 1:M) {
    n_source <- n.vec[k+1]
    end_idx <- start_idx + n_source - 1
    z_source <- all_data$data_train$Z[start_idx:end_idx, , drop = FALSE]
    if (p_n > 0) {
      n_source_data <- raw_N_all[start_idx:end_idx, , drop = FALSE]
      z_source_full <- cbind(n_source_data, z_source)
    } else {
      z_source_full <- z_source
    }
    source_glmtrans_alr[[k]] <- list(
      x = as.matrix(z_source_full),
      y = as.vector(all_data$data_train$y_z[start_idx:end_idx]) 
    )
    start_idx <- end_idx + 1
  }
  
  time_glmtrans_alr <- system.time(fit_glmtrans_alr <- glmtrans(
    target = target_glmtrans_alr,                
    source = source_glmtrans_alr,               
    family = "gaussian",                     
    transfer.source.id = "auto",            
    alpha = 1,                              
    standardize = TRUE,                     
    intercept = FALSE,                       
    nfolds = 10,                             
    cores = 1,                              
    detection = TRUE                       
  ))[3]
  coef_full_glmtrans <- as.numeric(fit_glmtrans_alr$beta)[-1]
  se_full_glmtrans <- as.numeric(fit_glmtrans_alr$se.beta)[-1]
  if (p_n > 0) {
    a_glmtrans <- coef_full_glmtrans[1:p_n]
    beta_glmtrans <- coef_full_glmtrans[(p_n+1):length(coef_full_glmtrans)]
    se_a_glmtrans <- se_full_glmtrans[1:p_n]
    se_beta_glmtrans <- se_full_glmtrans[(p_n+1):length(se_full_glmtrans)]
  } else {
    a_glmtrans <- numeric(0) 
    beta_glmtrans <- coef_full_glmtrans
    se_a_glmtrans <- numeric(0)
    se_beta_glmtrans <- se_full_glmtrans
  }
  
  if (p_n > 0) {
    se_a_glmtrans[se_a_glmtrans == 0 | is.na(se_a_glmtrans) | is.infinite(se_a_glmtrans)] <- 1e-6
  }
  se_beta_glmtrans[se_beta_glmtrans == 0 | is.na(se_beta_glmtrans) | is.infinite(se_beta_glmtrans)] <- 1e-6
  glmtrans_alr_fit_obj <- list(se_a = se_a_glmtrans, se_beta = se_beta_glmtrans)
  
  eval_glmtrans_alr <- model_evaluation(
    est_a = a_glmtrans,
    true_a = all_data$data_train$target_a,
    est_beta = beta_glmtrans,
    true_beta = all_data$data_train$target_beta_z,
    tind = all_data$data_train$tind,
    se_beta = glmtrans_alr_fit_obj$se_beta,
    y_test = all_data$data_test$y_z[1:n.vec[1]],
    X_test = all_data$data_test$Z[1:n.vec[1], , drop = FALSE],
    N_test = N_test_input[1:n.vec[1], , drop = FALSE]
  )
  
  # Trans-Lasso-alr
  cat("sim =", sim, ", size.A0 =", size.A0, "\n")
  cat("Trans-Lasso-alr\n")
  raw_N_all <- all_data$data_train$N
  p_n <- if (is.null(raw_N_all) || length(raw_N_all) == 0) 0 else ncol(raw_N_all)
  get_combined_features <- function(start, end) {
    z_part <- all_data$data_train$Z[start:end, , drop = FALSE]
    if (p_n > 0) {
      n_part <- raw_N_all[start:end, , drop = FALSE]
      return(cbind(n_part, z_part))
    } else {
      return(z_part)
    }
  }
  
  tl_alr_dataset <- list(
    X0 = get_combined_features(1, n.vec[1]),
    y0 = all_data$data_train$y_z[1:n.vec[1]],
    X  = lapply(1:M, function(k) {
      start_idx <- sum(n.vec[1:k]) + 1
      end_idx   <- sum(n.vec[1:(k+1)])
      get_combined_features(start_idx, end_idx)
    }),
    y  = lapply(1:M, function(k) {
      start_idx <- sum(n.vec[1:k]) + 1
      end_idx   <- sum(n.vec[1:(k+1)])
      all_data$data_train$y_z[start_idx:end_idx]
    })
  )
  
  time_tl_alr <- system.time({
    fit_tl_alr <- fit.TransLasso.Full(dataset = tl_alr_dataset, K = M, split_ratio = 0.5)
  })[3]
  
  coef_full_tl <- as.numeric(fit_tl_alr$coef)
  se_full_tl <- as.numeric(fit_tl_alr$se.beta) 
  if(length(se_full_tl) > length(coef_full_tl)) se_full_tl <- se_full_tl[-1]
  if (p_n > 0) {
    a_tl_est <- coef_full_tl[1:p_n]
    beta_tl_est <- coef_full_tl[(p_n + 1):length(coef_full_tl)]
    se_a_tl <- se_full_tl[1:p_n]
    se_beta_tl <- se_full_tl[(p_n + 1):length(se_full_tl)]
    se_a_tl[se_a_tl == 0 | is.na(se_a_tl) | is.infinite(se_a_tl)] <- 1e-6
  } else {
    a_tl_est <- numeric(0)
    beta_tl_est <- coef_full_tl
    se_a_tl <- numeric(0)
    se_beta_tl <- se_full_tl
  }
  se_beta_tl[se_beta_tl == 0 | is.na(se_beta_tl) | is.infinite(se_beta_tl)] <- 1e-6
  
  eval_tl_alr <- model_evaluation(
    est_a = a_tl_est,
    true_a = all_data$data_train$target_a,
    est_beta = beta_tl_est,
    true_beta = all_data$data_train$target_beta_z,
    tind = all_data$data_train$tind,
    se_beta = se_beta_tl,
    y_test = all_data$data_test$y_z[1:n.vec[1]],
    X_test = all_data$data_test$Z[1:n.vec[1], , drop = FALSE],
    N_test = N_test_input[1:n.vec[1], , drop = FALSE]
  )
  
  df_trans_sub      <- as.data.frame(eval_trans_sub)
  df_socp           <- as.data.frame(eval_socp)
  df_classo_sub     <- as.data.frame(eval_classo)
  df_tf             <- as.data.frame(eval_tf)
  df_glm            <- as.data.frame(eval_glmtrans_alr)
  df_tl             <- as.data.frame(eval_tl_alr)
  
  model_names <- c(
    "Trans-subCodalasso", "IP-Trans-subCodalasso", "subCodalasso", "Con-TransFusion", "Trans-GLM-alr", "Trans-Lasso-alr")
  
  
  model_runtimes <- c(
    time_trans_sub, time_socp, time_classo, time_tf, time_glmtrans_alr, time_tl_alr)
  
  
  num_models <- length(model_names)
  meta_info <- data.frame(
    sim_id               = rep(sim, num_models),
    sig.delta1           = rep(sig.delta1, num_models),
    num_perturbed_groups = rep(num_perturbed_groups, num_models),
    size.A0              = rep(size.A0, num_models),
    M                    = rep(M, num_models),
    model                = model_names,
    runtime              = model_runtimes
  )
  
  
  metrics_combined <- rbind(
    df_trans_sub, df_socp, df_classo_sub, df_tf, df_glm, df_tl)
  
  
  current_res <- cbind(meta_info, metrics_combined)
  sim_results <- rbind(sim_results, current_res)
  
  format_coef_row <- function(m_name, est_a, est_beta) {
    
    res <- data.frame(
      sim_id = sim,
      sig.delta1 = sig.delta1,
      num_perturbed_groups = num_perturbed_groups,
      size.A0 = size.A0,
      model = m_name,
      stringsAsFactors = FALSE
    )
    
    if (p_n > 0) {
      a_val <- if(!is.null(est_a) && length(est_a) > 0) as.numeric(est_a) else rep(NA, p_n)
      a_df <- as.data.frame(t(setNames(a_val, paste0("a", seq_len(p_n)))))
      res <- cbind(res, a_df)
    }
    
    if (!is.null(est_beta) && length(est_beta) > 0) {
      beta_val <- as.numeric(est_beta)
      beta_df <- as.data.frame(t(setNames(beta_val, paste0("b", seq_len(length(beta_val))))))
      res <- cbind(res, beta_df)
    }
    
    return(res)
  }
  
  
  coef_list <- list(
    format_coef_row("Trans-subCodalasso", fit_trans_sub$a_hat, fit_trans_sub$beta_hat),
    format_coef_row("IP-Trans-subCodalasso", fit_socp$a_hat, fit_socp$beta_hat),
    format_coef_row("subCodalasso", fit_classo$a, fit_classo$beta),
    format_coef_row("Con-TransFusion", cv_res_tf$a, cv_res_tf$beta),
    format_coef_row("Trans-GLM-alr", a_glmtrans, beta_glmtrans),
    format_coef_row("Trans-Lasso-alr", a_tl_est, beta_tl_est)
    )
  
  coef_results <- bind_rows(coef_results, coef_list)
  
  format_sources <- function(m_name, src_vec) {
    src_str <- if(!is.null(src_vec) && length(src_vec) > 0) {
      paste(sort(unique(as.numeric(src_vec))), collapse = ",")
    } else {
      "None" 
    }
    
    data.frame(
      sim_id = sim,
      sig.delta1 = sig.delta1,
      num_perturbed_groups = num_perturbed_groups,
      size.A0 = size.A0,
      model = m_name,
      selected_sources = src_str
    )
  }
  
  source_list <- list(
    format_sources("Trans-subCodalasso", fit_trans_sub$selected_sources),
    format_sources("IP-Trans-subCodalasso", fit_socp$selected_sources),
    format_sources("Trans-GLM-alr",  fit_glmtrans_alr$transfer.source.id))
  
  source_results <- bind_rows(source_results, source_list)
  
  
  rm(all_data, fit_trans_sub, fit_socp, fit_classo, cv_res_tf,
     fit_transglm_alr, fit_tl_alr, tf_dataset, tl_alr_dataset)
  
  gc()
}

###################### Results ######################
non_metric_cols <- c("sim_id", "sig.delta1", "num_perturbed_groups", "size.A0", "M", "model")
metrics <- setdiff(names(sim_results), non_metric_cols)
summary_res <- sim_results %>%
  group_by(sig.delta1, num_perturbed_groups, size.A0, model) %>% 
  summarise(
    across(all_of(metrics), 
           list(mean = ~mean(.x, na.rm=TRUE), sd = ~sd(.x, na.rm=TRUE)),
           .names = "{.col}_{.fn}"),
    .groups = "drop"
  )

summary_res <- summary_res %>% 
  arrange(sig.delta1, num_perturbed_groups, size.A0, model)

print(as.data.frame(summary_res))
write_xlsx(list(
  "Summary_Metrics"   = summary_res, 
  "Model_Evaluations" = sim_results,
  "Estimated_Coefs"   = coef_results,
  "Selected_Sources"  = source_results  
), "E:/p_n=0.xlsx")
