#TransFusion.CoDa

TransFusion.CoDa = function(dataset, tind, p_n = 2, lam0=NULL, debias=FALSE, maxiter=5000, tol=1e-8, mu=1, nu=1.05) {
  p_n <- if (is.null(p_n) || length(p_n) == 0) 0 else as.integer(p_n)
  X0_raw = dataset$X0
  y0 = dataset$y0
  X_list_raw = dataset$X
  y_list = dataset$y
  K = length(X_list_raw)
  p_total = ncol(X0_raw)
  p_c = p_total - p_n 
  
  TF_data = create_TF_data(y_list, y0, X_list_raw, X0_raw)
  X_TF = TF_data$X_TF
  y_TF = TF_data$y_TF
  p_stack = ncol(X_TF) 
  
  C = NULL
  ngrp <- length(tind) - 1
  C = matrix(0, nrow = (K + 1) * ngrp , ncol = p_stack)
  for (k in 1:(K + 1)) {
    for (ii in 1:ngrp) {
      row_idx = (k - 1) * ngrp + ii
      
      start_comp = (k - 1) * p_total + p_n + tind[ii] + 1
      end_comp   = (k - 1) * p_total + p_n + tind[ii + 1]
      
      C[row_idx, start_comp:end_comp] <- 1
    }
  }
  
  we = rep(1, p_stack)
  for (k in 1:(K + 1)) {
    idx_a = (k - 1) * p_total + seq_len(p_n)
    we[idx_a] = 0.001 
  }
  target_indices = (K * p_total + 1):p_stack
  we[target_indices] = we[target_indices] * 0.1
  
  row_norms = sqrt(rowSums(C))
  row_norms[row_norms == 0] = 1 
  
  U_dense = t(C / row_norms) 
  U_sparse = as(U_dense, "sparseMatrix")
  
  Zt = as.matrix(X_TF - (X_TF %*% U_sparse) %*% t(U_sparse)) 
  
  sfac = apply(Zt, 2, sd)
  idx_non_comp = outer(seq_len(p_n), (0:K) * p_total, "+") 
  sfac[as.vector(idx_non_comp)] = 1
  sfac[sfac < 1e-10] = 1
  sfac_inv = 1 / sfac 
  
  Zt_std = sweep(Zt, 2, sfac_inv, "*")
  Ct_std = sweep(C, 2, sfac_inv, "*")
  
  res_raw = classoshe(Zt_std, y_TF - mean(y_TF), Ct_std, we, lam0, maxiter, tol, mu, nu)
  
  beta_full_std = res_raw$beta * sfac_inv
  beta_full_mat = matrix(beta_full_std, nrow = p_total, ncol = K + 1)
  
  n_vec_all = c(sapply(X_list_raw, nrow), nrow(X0_raw))
  w_norm = n_vec_all / sum(n_vec_all)
  
  beta_target_est = beta_full_mat[, K+1]
  beta_sources = sweep(beta_full_mat[, 1:K], 1, beta_target_est, "+")
  beta_final = cbind(beta_sources, beta_target_est) %*% w_norm
  
  if(debias == TRUE) {
    bias = y0 - as.vector(X0_raw %*% beta_final)
    C_target = matrix(0, nrow = ngrp, ncol = p_total)
    for (ii in 1:ngrp) {
      start_c = p_n + tind[ii] + 1
      end_c   = p_n + tind[ii + 1]
      C_target[ii, start_c:end_c] <- 1
    }
    
    we_debias = rep(1, p_total)
    we_debias[1:p_n] = 0.001 
    
    row_norms_t = sqrt(rowSums(C_target))
    U_t = t(C_target / row_norms_t)
    
    Z_target = as.matrix(X0_raw - (X0_raw %*% U_t) %*% t(U_t))
    
    sfac_t = apply(Z_target, 2, sd)
    sfac_t_inv = rep(0, length(sfac_t)) 
    sfac_t[sfac_t < 1e-10] = 1  
    sfac_t_inv = 1 / sfac_t
    Z_target_std = sweep(Z_target, 2, sfac_t_inv, "*")
    C_target_std = sweep(C_target, 2, sfac_t_inv, "*")
    
    lam_debias = ifelse(is.null(lam0), 0.01, lam0 * 0.01) 
    res_debias = classoshe(Z_target_std, bias - mean(bias), C_target_std, 
                           we_debias, lam_debias, maxiter, tol, mu, nu)
    
    delta_beta = res_debias$beta * sfac_t_inv
    
    beta_final = beta_final + delta_beta
  }
  
  y0_pred = X0_raw %*% beta_final
  resid = y0 - y0_pred
  sigma2_est = mean(resid^2)
  
  df_est = sum(abs(beta_final) > 1e-8)
  n_target = nrow(X0_raw)
  
  se_val = sqrt(sigma2_est / max(1, n_target - df_est))
  se_full_vec = rep(se_val, p_total) 
  
  return(list(
    a         = if(p_n > 0) beta_final[1:p_n] else numeric(0), 
    beta      = if(p_n > 0) beta_final[(p_n + 1):p_total] else beta_final,  
    beta_full = as.vector(beta_final),            
    se_full   = se_full_vec,                     
    se_beta   = se_full_vec[(p_n + 1):p_total],  
    se_a      = se_full_vec[1:p_n],              
    sigma2    = sigma2_est,                      
    df        = df_est                           
  ))
}

cv.TransFusion.CoDa = function(dataset, tind, p_n = 2, nfolds = 10, seed = 123, lam0_seq = NULL) {
  library(doParallel)
  library(foreach)
  library(Matrix)
  library(Rcpp)
  
  p_n_fix <- if (is.null(p_n) || length(p_n) == 0) 0L else as.integer(p_n)
  
  X0_val = as.matrix(dataset$X0)
  y0_val = as.numeric(dataset$y0)
  X_list_val = lapply(dataset$X, as.matrix)
  y_list_val = lapply(dataset$y, as.numeric)
  K_val = length(X_list_val)
  p_total = ncol(X0_val)
  
  if (is.null(lam0_seq)) {
    TF_temp = create_TF_data(y_list_val, y0_val, X_list_val, X0_val)
    X_TF_temp = TF_temp$X_TF
    y_TF_temp = TF_temp$y_TF - mean(TF_temp$y_TF)
    
    we_temp = rep(1, ncol(X_TF_temp))
    for (k in 1:(K_val + 1)) {
      if (p_n_fix > 0) {
        idx_pn = (k - 1) * p_total + (1:p_n_fix)
        we_temp[idx_pn] = 0.001
      }
    }
    target_idx = (K_val * p_total + 1):ncol(X_TF_temp)
    we_temp[target_idx] = we_temp[target_idx] * 0.5
    
    grad = abs(as.vector(t(X_TF_temp) %*% y_TF_temp))
    valid_idx = we_temp > 0.01
    lambda_max = max(grad[valid_idx] / we_temp[valid_idx]) / nrow(X_TF_temp)
    
    lam0_seq = exp(seq(log(lambda_max * 1.05), log(lambda_max * 0.001), length.out = 30))
    rm(TF_temp, X_TF_temp, y_TF_temp); gc() 
  }
  
  set.seed(seed)
  folds0_val = sample(rep(1:nfolds, length.out = nrow(X0_val)))
  folds_list_val = lapply(X_list_val, function(xk) sample(rep(1:nfolds, length.out = nrow(xk))))
  
  num_cores <- min(nfolds, parallel::detectCores() - 1)
  cl <- makeCluster(num_cores)
  on.exit({ if (exists("cl")) stopCluster(cl) }) 
  registerDoParallel(cl)
  
  cat(sprintf("core=%d, p_n=%d, lambda_max=%.4f\n", num_cores, p_n_fix, lam0_seq[1]))
  tind_fix <- as.numeric(tind)
  
  mse_results <- foreach(f = 1:nfolds, .combine = 'rbind', 
                         .packages = c("Matrix", "Rcpp"),
                         .export = c("TransFusion.CoDa", "create_TF_data", 
                                     "X0_val", "y0_val", "X_list_val", "y_list_val",
                                     "K_val", "folds0_val", "folds_list_val", "lam0_seq", "tind_fix", "p_n_fix")) %dopar% {
                                       
                                       core_cache = paste0("tmp_cache_f", f)
                                       if(!dir.exists(core_cache)) dir.create(core_cache)
                                       Rcpp::sourceCpp("cclasso1.cpp", cacheDir = core_cache)
                                       
                                       idx_train0 = (folds0_val != f)
                                       train_data_sub = list(
                                         X0 = X0_val[idx_train0, , drop = FALSE],
                                         y0 = y0_val[idx_train0],
                                         X = lapply(1:K_val, function(k) X_list_val[[k]][folds_list_val[[k]] != f, , drop = FALSE]),
                                         y = lapply(1:K_val, function(k) y_list_val[[k]][folds_list_val[[k]] != f])
                                       )
                                       test_X0_sub = X0_val[!idx_train0, , drop = FALSE]
                                       test_y0_sub = y0_val[!idx_train0]
                                       
                                       fold_mse = rep(NA, length(lam0_seq))
                                       for (l in seq_along(lam0_seq)) {
                                         res <- tryCatch({
                                           fit = TransFusion.CoDa(train_data_sub, tind = tind_fix, p_n = p_n_fix, lam0 = lam0_seq[l], 
                                                                  maxiter = 300, tol = 1e-3) 
                                           
                                           if(length(fit$a) != p_n_fix || length(fit$beta) != (p_total - p_n_fix)) return(NA)
                                           
                                           pred = rep(0, nrow(test_X0_sub))
                                           if (p_n_fix > 0) {
                                             pred = pred + as.vector(test_X0_sub[, 1:p_n_fix, drop=FALSE] %*% fit$a)
                                           }
                                           pred = pred + as.vector(test_X0_sub[, (p_n_fix+1):p_total, drop=FALSE] %*% fit$beta)
                                           
                                           mean((test_y0_sub - pred)^2)
                                         }, error = function(e) NA)
                                         fold_mse[l] = res
                                       }
                                       
                                       unlink(core_cache, recursive = TRUE) 
                                       return(as.vector(fold_mse))
                                     }
  
  mse_matrix = as.matrix(mse_results)
  if (all(is.na(mse_matrix))) {
    stop("All cross-validation runs failed. Please check the data or the p_n setting.")
  }
  
  mean_mse = colMeans(mse_matrix, na.rm = TRUE)
  best_lam0 = lam0_seq[which.min(mean_mse)]
  
  Rcpp::sourceCpp("cclasso1.cpp") 
  cat("lam0:", best_lam0, "\n")
  final_fit = TransFusion.CoDa(dataset, tind = tind_fix, p_n = p_n_fix, lam0 = best_lam0, maxiter = 1000, tol = 1e-5)
  
  return(list(
    best_lam0 = best_lam0,
    mean_mse  = mean_mse,
    lam0_seq  = lam0_seq,
    mse_matrix = mse_matrix,
    a         = final_fit$a,
    beta      = final_fit$beta,
    se_beta   = final_fit$se_beta,
    se_full   = final_fit$se_full,
    sigma2    = final_fit$sigma2,
    df        = final_fit$df,
    final_fit = final_fit
  ))
}