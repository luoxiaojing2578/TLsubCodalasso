## TransFusion Algorithm Utilities

create_TF_data = function(y, y0, X, X0){
  K = length(X)
  
  Xapp = X
  Xapp[[K+1]] = X0
  
  dimensions = lapply(Xapp, dim)
  
  zeros_list = lapply(dimensions, function(d) matrix(0, nrow = d[1], ncol = d[2]))
  
  X_final = list()
  
  for (i in 1:(K + 1)) {
    row_list = list()
    for (j in 1:(K + 1)) {
      if (j == i) {
        row_list[[j]] = Xapp[[i]]
      } else if(j == K + 1) {
        row_list[[j]] = Xapp[[i]]
      } else {
        row_list[[j]] = zeros_list[[i]]
      }
    }
    X_final[[i]] = do.call(cbind, row_list)
  }
  
  X_final = do.call(rbind, X_final)
  
  y[[K+1]] = y0
  y_final = do.call(c, y)
  
  res = list()
  res$y_TF = y_final
  res$X_TF = X_final
  return(res)
}

