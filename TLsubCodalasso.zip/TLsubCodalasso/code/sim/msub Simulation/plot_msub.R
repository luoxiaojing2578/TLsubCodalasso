library(ggplot2)
library(scales)
library(readxl)
library(dplyr)

load_and_label <- function(path, scenario_name, d_name) {
  df <- read_excel(path, sheet = "Summary_Metrics")
  df$scenario <- scenario_name  
  df$d_val <- d_name          
  return(df)
}

d1 <- load_and_label("msub_tg_Simulation2_4.xlsx", "d=4", "Homogeneous")
d2 <- load_and_label("msub_tg_Simulation2_12.xlsx", "d=12", "Homogeneous")
d3 <- load_and_label("msub_yyg_Simulation2_4.xlsx", "d=4", "Heterogeneous")
d4 <- load_and_label("msub_yyg_Simulation2_12.xlsx", "d=12", "Heterogeneous")
df_all <- rbind(d1, d2, d3, d4)

df_all$scenario <- factor(df_all$scenario, 
                          levels = c("d=4", "d=12"))

df_all$d_val <- factor(df_all$d_val, 
                       levels = c("Homogeneous", "Heterogeneous"))
df_all$model <- dplyr::case_when(
  df_all$model == "Classo.sub" ~ "subCodalasso",
  df_all$model == "Classo.single" ~ "singleCodalasso",
  df_all$model == "Trans.sub" ~ "Trans-subCodalasso",
  df_all$model == "Trans.msub" ~ "Trans-msubCodalasso",
  df_all$model == "Oracle.msub.Raw" ~ "Oracle-Trans-msubCodalasso",
  df_all$model == "Oracle.sub.Raw" ~ "Oracle-Trans-subCodalasso",
  df_all$model == "Oracle.sub.CLR" ~ "Oracle-Trans-subCodalasso-clr",
  df_all$model == "Oracle.single.Raw" ~ "Oracle-Trans-singleCodalasso",
  df_all$model == "Oracle.sub.Single" ~ "Oracle-Trans-singleCodalasso",
  df_all$model == "Oracle.TransGLM.ALR" ~ "Oracle-Trans-GLM-clr",
  df_all$model == "Oracle.TransLasso.ALR" ~ "Oracle-Trans-Lasso-clr",
  df_all$model == "Naive.subCodalasso" ~ "Naive-Trans-subCodalasso",
  df_all$model == "Pooled.subCodalasso" ~ "Pooled-subCodalasso",
  df_all$model == "TransGLM.ALR" ~ "Trans-GLM-alr",
  df_all$model == "TransGLM.Raw" ~ "Trans-GLM-raw",
  df_all$model == "TransGLM.CLR" ~ "Trans-GLM-clr",
  df_all$model == "TransLasso.CLR" ~ "Trans-Lasso-clr",
  df_all$model == "TransLasso.ALR" ~ "Trans-Lasso-alr",
  df_all$model == "TransLasso.Raw" ~ "Trans-Lasso-raw",
  TRUE ~ df_all$model
)

df_filtered <- df_all[
  !grepl("Naive|single|clr|raw", df_all$model, ignore.case = TRUE), 
]
target_order <- c(
  "subCodalasso",
  "Oracle-Trans-subCodalasso",
  "Trans-subCodalasso",
  "Oracle-Trans-msubCodalasso",
  "Trans-msubCodalasso",
  "Pooled-subCodalasso",
  "Trans-Lasso-alr",
  "Trans-GLM-alr"
)

df_filtered$model <- factor(df_filtered$model, levels = target_order)

my_shapes <- c(
  "Oracle-Trans-subCodalasso"     = 17, 
  "Oracle-Trans-msubCodalasso"    = 16, 
  "subCodalasso"                  = 15, 
  "Trans-subCodalasso"            = 18, 
  "Trans-msubCodalasso"           = 11,
  
  "Trans-Lasso-alr"               = 8,  
  "Trans-GLM-alr"                 = 3,  
  "Pooled-subCodalasso"         = 13  
)

my_colors <- c(
  "Oracle-Trans-subCodalasso"     = "#2E8B57", 
  "Trans-subCodalasso"            = "#A2AD00", 
  "Oracle-Trans-msubCodalasso"    = "#FFBF00", 
  "Trans-msubCodalasso"           = "#556B2F",  
  "subCodalasso"                  = "#E76BF3", 
  "Pooled-subCodalasso"         = "#9400D3", 
  "Trans-Lasso-alr"               = "#1E90FF", 
  "Trans-GLM-alr"                 = "#F8766D"  
)

p <- ggplot(df_filtered, aes(x = size.A0, y = l2_total_mean, color = model, shape = model)) +
  geom_line(linewidth = 0.3, alpha = 0.9) +
  geom_point(size = 1.5, alpha = 0.9) +
  facet_grid(scenario ~ d_val) + 
  scale_x_continuous(breaks = unique(df_filtered$size.A0)) +
  labs(x = "|A|", y = expression("L"[2] ~ "error"), color = "Method", shape = "Method") +
  theme_bw(base_size = 12) +  
  theme(
    legend.position = "bottom",
    legend.box = "horizontal",
    legend.direction = "horizontal",
    legend.title = element_text(face = "bold", size = 14),  
    legend.text = element_text(size = 12),  
    strip.text = element_text(face = "bold", size = 11), 
    strip.background = element_rect(fill = "gray95"),  
    legend.key.size = unit(1.2, "lines"),
    panel.grid.minor = element_blank(),
    plot.margin = margin(10, 20, 10, 20),
    axis.text = element_text(size = 9), 
    axis.title = element_text(size = 12) 
  )

p_final <- p + 
  scale_color_manual(values = my_colors) +
  scale_shape_manual(values = my_shapes) +
  guides(color = guide_legend(nrow= 2, byrow = TRUE), 
         shape = guide_legend(nrow = 2, byrow = TRUE))
print(p_final)
ggsave("E:/.../msub-l2 error.pdf", p_final, width = 12, height = 7)
