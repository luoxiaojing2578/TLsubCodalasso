# Trans-msubCodalasso

library(MASS) 
library(stats)
library(magrittr)
# msubCodalasso 
mclasso <- function(data, p, lam0 = NULL, maxiter = 5000, tol = 1e-8,
                    mu = 1, nu = 1.05, seed = 2025, constraint_type = "sub") {
  set.seed(seed)
  X <- data$X
  N <- data$N
  y <- data$y
  tind <- data$tind
  
  p_n <- if (is.null(N) || ncol(as.matrix(N)) == 0) 0 else ncol(as.matrix(N))
  if (p_n > 0) N <- as.matrix(N) 
  
  w_init <- if (!is.null(data$w_init)) data$w_init else rep(0, p) 
  
  C <- NULL
  if (constraint_type == "sub") {
    ngrp <- length(tind) - 1
    C <- matrix(0, ngrp, p)
    for (ii in 1:ngrp)
      C[ii, (tind[ii] + 1):tind[ii + 1]] <- 1
  } else if (constraint_type == "single") {
    ngrp <- 1 
    C <- matrix(1, nrow = ngrp, ncol = p)
  }
  
  Z <- if (p_n > 0) cbind(N, X) else X
  p_total <- ncol(Z) 
  n <- nrow(Z)       
  k <- nrow(C) 
  
  if (p_n > 0) C <- cbind(matrix(0, nrow = k, ncol = p_n), C)
  
  if (p_n == 0) {
    we <- rep(1, p)
  } else {
    we <- c(0, rep(1, p_n - 1), rep(1, p))
  }
  intercept_index <- if (p_n > 0) 1 else NA

  Zt <- crossprod(t(Z), subtract(diag(1, p_total, p_total), svd(t(C))$u %>% tcrossprod()))  
  xmean <- colMeans(Zt)
  if(p_n > 0) xmean[intercept_index] <- 0
  sfac <- apply(Zt, 2, sd)
  sfac[sfac == 0] <- 1
  if(p_n > 0) sfac[intercept_index] <- 1
  sfac[sfac < 1e-6] <- 1e-6
  sfac <- drop(1 / sfac) 
  
  Zt <- t(t(Zt) - xmean) * rep(sfac, each = n)
  C_std <- C * rep(sfac, each = k) 
  
  y_orig <- y
  if (p_n > 0) {
    mu_y <- mean(y_orig)
    y <- y_orig - mu_y
  } else {
    mu_y <- 0
    y <- y_orig
  }
  
  w_full_init <- if (p_n > 0) c(rep(0, p_n), w_init) else w_init
  w_std <- w_full_init * sfac
  cw <- as.vector(C_std %*% w_std)
  
  model_res <- classoshe1(Zt, y, C_std, we, lam0, maxiter, tol, mu, nu, cw)
  
  tem <- model_res$beta * sfac  
  offset <- sum(tem[2:p_total] * xmean[2:p_total])
  
  if (p_n > 0) {
    a_est <- tem[1:p_n]
    a_est[1] <- mu_y + tem[1] - offset
    beta_est <- tem[(p_n + 1):p_total]
    y_hat <- as.vector(N %*% a_est + X %*% beta_est)
  } else {
    a_est <- NULL 
    beta_est <- tem
    y_hat <- as.vector(X %*% beta_est)
  }
  
  resid <- y_orig - y_hat
  train_mse <- mean(resid^2)
  sigma2_est <- mean(resid^2)
  df_est = sum(abs(beta_est) > 1e-8)
  
  df_free <- max(1, (n - df_est))
  se_val <- sqrt(sigma2_est / df_free)
  
  se_beta <- rep(se_val, length(beta_est))
  if(!is.null(colnames(X))){names(se_beta) = colnames(X)}else{names(se_beta) = 1:length(beta_est)}
  
  se_a <- NULL
  if (p_n > 0) {
    se_a_val = sqrt(sigma2_est / df_free)
    se_a = rep(se_a_val, length(a_est))
    if(!is.null(colnames(N))){names(se_a) = colnames(N)}else{names(se_a) = 1:length(a_est)}
  }
  se_full = c(se_a, se_beta)
  
  return(list(a = a_est,
              beta = beta_est, 
              sigma2 = mean(resid^2),
              df = sum(abs(beta_est) > 1e-8),
              train_mse = train_mse,
              y_pred = y_hat,
              X = X,
              N = N,
              y_orig = y_orig,
              se_a = se_a,       
              se_beta = se_beta,  
              se_full = se_full  
  ))
}

# cv_msubCodalasso
cv_mclasso <- function(data, p, lam0_seq, nfold = 10,
                       maxiter = 5000, tol = 1e-8, mu = 1, nu = 1.05,
                       seed = 2025, constraint_type = "sub", type = "min") {
  set.seed(seed)
  X <- data$X; y <- data$y; tind <- data$tind
  w_init <- if (!is.null(data$w_init)) data$w_init else rep(0, p)
  n <- length(y)
  
  if (is.null(data$N) || ncol(as.matrix(data$N)) == 0) {
    p_n <- 0
    N <- NULL
  } else {
    N <- as.matrix(data$N)
    p_n <- ncol(N)
  }
  
  foldid <- sample(rep(1:nfold, length.out = n))
  pred <- matrix(NA, nrow = nfold, ncol = length(lam0_seq))
  valid_n <- numeric(nfold)
  
  for (i in 1:nfold) {
    train_idx <- which(foldid != i); valid_idx <- which(foldid == i)
    valid_n[i] <- length(valid_idx)
    
    data_train <- list(X = X[train_idx, , drop = FALSE], 
                       y = y[train_idx], 
                       tind = tind,
                       N = if(p_n > 0) N[train_idx, , drop = FALSE] else NULL,
                       w_init = w_init)
    
    for (j in seq_along(lam0_seq)) {
      lam0_j <- lam0_seq[j]
      fit_j <- mclasso(
        data = data_train,
        p = p,
        lam0 = lam0_j,
        maxiter = maxiter,
        tol = tol,
        mu = mu,
        nu = nu,
        seed = seed + i + j,
        constraint_type = constraint_type
      )
      
      y_pred <- if(p_n > 0) {
        as.vector(N[valid_idx, , drop = FALSE] %*% fit_j$a + X[valid_idx, , drop = FALSE] %*% fit_j$beta)
      } else {
        as.vector(X[valid_idx, , drop = FALSE] %*% fit_j$beta)
      }
      pred[i, j] <- sum((y[valid_idx] - y_pred)^2)
    }
    
  }
  
  
  pred_mse <- t(t(pred) / valid_n)
  weights <- valid_n / sum(valid_n)
  cvm <- colSums(pred_mse * weights, na.rm = TRUE)
  cvse <- apply(pred_mse, 2, function(col) {
    valid_vals <- col[!is.na(col)]
    if (length(valid_vals) < 2) return(NA)
    sd(valid_vals) / sqrt(length(valid_vals))
  })
  
  
  imin <- which.min(cvm)
  if (type == "1se") {
    ilam <- which(cvm <= cvm[imin] + cvse[imin])[1]
  } else {
    ilam <- imin
  }
  lam_best <- lam0_seq[ilam]
  
  
  data_full <- list(
    X = X,         
    N = N,         
    y = y,          
    tind = tind    
  )
  
  fit_best <- mclasso(
    data = data_full,
    p = p,
    lam0 = lam_best,
    maxiter = maxiter,
    tol = tol,
    mu = mu,
    nu = nu,
    seed = seed,
    constraint_type = constraint_type
  )
  
  return(list(
    a = fit_best$a,              
    beta = fit_best$beta,        
    lam0_best = lam_best,        
    lam0_seq = lam0_seq,          
    cvm = cvm,                   
    cvse = cvse,                 
    foldid = foldid,             
    fit_best = fit_best,         
    se_a = fit_best$se_a,        
    se_beta = fit_best$se_beta   
  ))
}

# Oracle-Trans-msubCodalasso 
Oracle.msubCodalasso <- function(X, N, y, tind, A0, n.vec, 
                                 lam0_seq, nfold = 10, maxiter=5000, tol=1e-8, 
                                 mu=1, nu=1.05, seed=2025, constraint_type = "sub") { 
  set.seed(seed)
  p <- ncol(X)  
  
  p_n <- if (is.null(N) || ncol(as.matrix(N)) == 0) 0 else ncol(as.matrix(N))
  
  if (length(A0) == 2 && all(A0 == c(1, 0))) {  
    A0 <- integer(0)  
  }  
  size.A0 <- length(A0) 
  
  a.KA <- if(p_n > 0) numeric(p_n) else NULL
  a.udb <- if(p_n > 0) numeric(p_n) else NULL
  beta.kA <- numeric(p)   
  w.kA <- numeric(p)      
  
  se_beta_kA <- numeric(p)
  se_a_KA <- if(p_n > 0) numeric(p_n) else NULL
  se_beta_udb <- numeric(p)
  se_a_udb <- if(p_n > 0) numeric(p_n) else NULL
  
  if(size.A0 > 0){ 
    k.vec <- c(1, A0+1)
    ind.kA <- NULL      
    for(k in k.vec){ 
      if(k==1){ 
        ind.kA <- c(ind.kA, 1:n.vec[1]) 
      }else{ 
        ind.kA <- c(ind.kA, (sum(n.vec[1:(k-1)])+1):sum(n.vec[1:k]))
      }
    }
    ind.1 <- 1:n.vec[1]
    
    X1 <- X[ind.kA, , drop = FALSE]
    y1 <- y[ind.kA]
    
    if (p_n > 0) {
      N1 <- N[ind.kA, , drop = FALSE]
      X_full1 <- cbind(N1, X1)
      colnames(X_full1) <- c(paste0("N", 1:p_n), paste0("X", 1:p))
    } else {
      X_full1 <- X1
      colnames(X_full1) <- paste0("X", 1:p)
    }
    
    cv_glm <- cv.glmnet(x = X_full1, y = y1, family = "gaussian", intercept = FALSE, standardize = TRUE, nfolds = nfold)
    coef_w_raw <- as.numeric(coef(cv_glm, s = "lambda.1se"))[-1]
    
    if (p_n > 0) {
      a.udb <- coef_w_raw[1:p_n]
      w.kA <- coef_w_raw[(p_n+1):(p_n+p)]
      se_a_udb <- rep(1e-6, p_n)
    } else {
      a.udb <- NULL
      w.kA <- coef_w_raw
      se_a_udb <- NULL
    }
    se_beta_udb <- rep(1e-6, p)
    
    y_pred_w <- if (p_n > 0) {
      as.vector(N[ind.1, , drop = FALSE] %*% a.udb + X[ind.1, , drop = FALSE] %*% w.kA)
    } else {
      as.vector(X[ind.1, , drop = FALSE] %*% w.kA)
    }
    
    res <- as.numeric(y[ind.1] - y_pred_w)
    data_delta <- list(X = X[ind.1, , drop = FALSE], 
                       N = if(p_n > 0) N[ind.1, , drop = FALSE] else NULL, 
                       y = res, tind = tind, w_init = w.kA)
    
    delta_res <- cv_mclasso(data = data_delta, p = p, lam0_seq = lam0_seq, nfold = nfold, 
                            maxiter = maxiter, tol = tol, mu = mu, nu = nu, seed = seed, constraint_type = constraint_type)
    
    beta.kA <- w.kA + as.numeric(delta_res$beta)
    se_beta_kA <- sqrt(se_beta_udb^2 + delta_res$se_beta^2)
    
    if (p_n > 0) {
      a.KA <- a.udb + as.numeric(delta_res$a)
      se_a_KA <- sqrt(se_a_udb^2 + delta_res$se_a^2)
    }
    
  } else { 
    ind.1 <- 1:n.vec[1]  
    data.kA <- list(
      X = X[ind.1, , drop = FALSE],
      N = N[ind.1, , drop = FALSE],
      y = y[ind.1],
      tind = tind
    )
    w <- cv_classo(
      data = data.kA,
      p = p,
      lam0_seq = lam0_seq,
      nfold = nfold,
      maxiter = maxiter,
      tol = tol,
      mu = mu,
      nu = nu,
      seed = seed,
      constraint_type = constraint_type
      # type = "1se"
    )
    beta.kA <- as.numeric(w$beta)
    a.KA    <- as.numeric(w$a)
    se_beta_kA <- w$se_beta
    se_a_KA    <- w$se_a
    w.kA    <- beta.kA
    a.udb   <- a.KA
    se_w_kA <- se_beta_kA
    se_w_a  <- se_a_KA
    names(se_beta_kA) <- colnames(X)
    if (p_n > 0 && !is.null(colnames(N))) {
      names(se_a_KA) <- colnames(N)
    }
  }
  
  return(list(a = if(!is.null(a.KA)) as.numeric(a.KA) else NULL, 
              beta = as.numeric(beta.kA),    
              a.udb = if(!is.null(a.udb)) as.numeric(a.udb) else NULL,      
              beta.udb = as.numeric(w.kA),   
              se_beta = se_beta_kA,        
              se_a = se_a_KA,              
              se_beta_udb = se_beta_udb,   
              se_a_udb = se_a_udb          
  ))                
}

# Trans-msubCodalasso 
Trans.Codalasso.msub <- function(Xtrain, Ntrain, ytrain, tind, n, M, epsilon = 0.01, 
                                 lam0_seq, nfold = 10, maxiter = 5000, tol = 1e-8, 
                                 mu = 1, nu = 1.05, seed = 2025, constraint_type = "sub") {
  set.seed(seed)
  
  x.target <- Xtrain[1:n[1], , drop = FALSE]
  x.source <- Xtrain[(n[1] + 1):sum(n), , drop = FALSE]
  y.target <- ytrain[1:n[1]]
  y.source <- ytrain[(n[1] + 1):sum(n)]
  n.target <- n[1]
  
  p_n <- if (is.null(Ntrain) || ncol(as.matrix(Ntrain)) == 0) 0 else ncol(as.matrix(Ntrain))
  
  N.target <- if(p_n > 0) Ntrain[1:n[1], , drop = FALSE] else NULL
  N.source <- if(p_n > 0) Ntrain[(n[1] + 1):sum(n), , drop = FALSE] else NULL
  
  xsourcelist <- list() 
  ysourcelist <- list()
  Nsourcelist <- list()
  start_row <- 1  
  for (k in 1:M) { 
    end_row <- start_row + n[k+1] - 1  
    xsourcelist[[k]] <- x.source[start_row:end_row, , drop = FALSE]
    ysourcelist[[k]] <- y.source[start_row:end_row]
    Nsourcelist[[k]] <- if(p_n > 0) N.source[start_row:end_row, , drop = FALSE] else NULL
    start_row <- end_row + 1  
  }
  
  if (n.target %% 2 == 0) {
    split_idx <- n.target / 2
  } else {
    split_idx <- floor(n.target / 2)
  }
  X_train <- x.target[1:split_idx, , drop = FALSE]
  y_train <- y.target[1:split_idx]
  N_train <- if(p_n > 0) N.target[1:split_idx, , drop = FALSE] else NULL
  
  X_test <- x.target[(split_idx + 1):n.target, , drop = FALSE]
  y_test <- y.target[(split_idx + 1):n.target]
  N_test <- if(p_n > 0) N.target[(split_idx + 1):n.target, , drop = FALSE] else NULL
  
  beta_hat_list <- list()
  Q_list <- list()
  
  data_init <- list(X = X_train, N = N_train, y = y_train, tind = tind)
  
  cv_init <- cv_classo(data = data_init, p = ncol(X_train), lam0_seq = lam0_seq, 
                        nfold = nfold, maxiter = maxiter, tol = tol, mu = mu, nu = nu,
                        seed = seed, constraint_type = constraint_type)
  
  beta_0_hat <- cv_init$beta
  a_0_hat <- cv_init$a
  
  y_test_pred <- if (p_n > 0) {
    as.vector(N_test %*% a_0_hat + X_test %*% beta_0_hat)
  } else {
    as.vector(X_test %*% beta_0_hat)
  }
  Q_list[["Q0"]] <- mean((y_test - y_test_pred) ^ 2)
  
  for (k in 1:M) {
    x_comb <- rbind(X_train, xsourcelist[[k]])
    y_comb <- c(y_train, ysourcelist[[k]])
    N_comb <- if(p_n > 0) rbind(N_train, Nsourcelist[[k]]) else NULL
    
    data_comb <- list(X = x_comb, N = N_comb, y = y_comb, tind = tind)
    
    cv_comb <- cv_classo(data = data_comb, p = ncol(x_comb), lam0_seq = lam0_seq,
                          nfold = nfold, maxiter = maxiter, tol = tol, mu = mu, nu = nu,
                          seed = seed + k, constraint_type = constraint_type)
    
    beta_hat_k <- as.vector(cv_comb$beta)
    a_hat_k <- cv_comb$a
    
    y_test_pred_k <- if (p_n > 0) {
      as.vector(N_test %*% a_hat_k + X_test %*% beta_hat_k)
    } else {
      as.vector(X_test %*% beta_hat_k)
    }
    Q_list[[paste0("Q", k)]] <- mean((y_test - y_test_pred_k) ^ 2)
  }
  
  indexQR <- c()
  for (k in 1:M) {
    if (Q_list[[paste0("Q", k)]] <= (1 + epsilon) * Q_list[["Q0"]]) {
      indexQR <- c(indexQR, k)
    }
  }
  effective_source_count <- length(indexQR)
  
  if (length(indexQR) != 0) {
    x_source1 <- xsourcelist[indexQR]  
    y_source1 <- ysourcelist[indexQR]  
    N_source1 <- if(p_n > 0) Nsourcelist[indexQR] else NULL
    
    x_combined <- rbind(x.target, do.call(rbind, x_source1))
    y_combined <- c(y.target, unlist(y_source1))
    N_combined <- if(p_n > 0) rbind(N.target, do.call(rbind, N_source1)) else NULL
    n_selected <- c(n[1], n[indexQR + 1])  
    
    kA <- Oracle.msubCodalasso(
      X = x_combined, N = N_combined, y = y_combined, tind = tind,
      A0 = 1:length(indexQR), n.vec = n_selected,
      lam0_seq = lam0_seq, nfold = nfold, maxiter = maxiter,
      tol = tol, mu = mu, nu = nu, seed = seed, constraint_type = constraint_type
    )
    
    beta_hat <- kA$beta
    a_hat <- kA$a
    int <- if(!is.null(a_hat)) a_hat[1] else NA
    w.kA <- kA$beta.udb
    se_beta <- kA$se_beta
    se_a <- kA$se_a
    
  } else { 
    data_target <- list(X = x.target, N = N.target, y = y.target, tind = tind)
    
    cv_target <- cv_classo(data = data_target, p = ncol(x.target), lam0_seq = lam0_seq,
                            nfold = nfold, maxiter = maxiter, tol = tol, mu = mu, nu = nu,
                            seed = seed, constraint_type = constraint_type)
    
    beta_hat <- cv_target$beta
    a_hat <- cv_target$a
    int <- if(!is.null(a_hat)) a_hat[1] else NA
    w.kA <- NA
    se_beta <- cv_target$se_beta
    se_a <- cv_target$se_a
  }
  
  return(list(
    beta_hat = as.numeric(beta_hat), 
    a_hat = if(!is.null(a_hat)) as.numeric(a_hat) else NULL,
    int = int, 
    w.kA = w.kA,
    se_beta = se_beta,
    se_a = se_a,
    selected_sources = indexQR
  ))
}