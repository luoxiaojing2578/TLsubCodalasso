library(readxl)
library(dplyr)
library(writexl)
library(ggplot2)
library(ggh4x)
library(patchwork)
library(tidyverse)

file_configs <- list(
  list(path = "C:/.../n0_50.xlsx",  n0_val = 50),
  list(path = "C:/.../n0_100.xlsx", n0_val = 100),
  list(path = "C:/.../n0_200.xlsx", n0_val = 200),
  list(path = "C:/.../n0_300.xlsx", n0_val = 300),
  list(path = "C:/.../n0_400.xlsx", n0_val = 400)
)

process_sheet <- function(config) {
  df <- read_xlsx(config$path, sheet = "Model_Evaluations")
  
  df_processed <- df %>%
    mutate(n0 = config$n0_val) %>%
    filter(`size.A0` %in% c(0, 4, 8)) %>% 
    dplyr::select(n0, everything())
  
  return(df_processed)
}

combined_data <- lapply(file_configs, process_sheet) %>% bind_rows()

df_all <- combined_data %>%
  dplyr::select(-any_of(c("sig.delta1", "num_perturbed_groups", "M"))) %>% 
  group_by(n0, size.A0, model) %>% 
  summarise(
    across(where(is.numeric), list(mean = mean), .names = "{.col}_{.fn}"), 
    .groups = "drop"
  )
df_all$model <- dplyr::case_when(
  df_all$model == "Classo.sub" ~ "subCodalasso",
  df_all$model == "Trans.sub" ~ "Trans-subCodalasso",
  df_all$model == "Oracle.sub.Raw" ~ "Oracle-Trans-subCodalasso",
  df_all$model == "Naive.subCodalasso" ~ "Naive-Trans-subCodalasso",
  df_all$model == "Pooled.subCodalasso" ~ "Pooled-subCodalasso",
  df_all$model == "TransGLM.ALR" ~ "Trans-GLM-alr",
  df_all$model == "TransGLM.Raw" ~ "Trans-GLM-raw",
  df_all$model == "TransGLM.CLR" ~ "Trans-GLM-clr",
  df_all$model == "TransLasso.CLR" ~ "Trans-Lasso-clr",
  df_all$model == "TransLasso.ALR" ~ "Trans-Lasso-alr",
  df_all$model == "TransLasso.Raw" ~ "Trans-Lasso-raw",
  TRUE ~ df_all$model
)

df_filtered <- df_all
target_order <- c(
  "Oracle-Trans-subCodalasso",
  "Trans-subCodalasso",
  "Naive-Trans-subCodalasso",
  "Pooled-subCodalasso",
  "subCodalasso",
  "Trans-Lasso-raw",  
  "Trans-Lasso-alr",  
  "Trans-Lasso-clr",
  "Trans-GLM-clr",
  "Trans-GLM-raw",
  "Trans-GLM-alr"
  
)

df_filtered$model <- factor(df_filtered$model, levels = target_order)

my_shapes <- c(
  "Oracle-Trans-subCodalasso" = 17, 
  "subCodalasso"              = 15, 
  "Trans-subCodalasso"        = 18, 
  "Trans-Lasso-raw"           = 1,  
  "Trans-Lasso-alr"           = 8, 
  "Trans-Lasso-clr"           = 4, 
  "Trans-GLM-raw"             = 7,  
  "Trans-GLM-alr"             = 3, 
  "Trans-GLM-clr"             = 9,  
  "Naive-Trans-subCodalasso"  = 10, 
  "Pooled-subCodalasso"     = 13
)
my_colors <- c(
  "Oracle-Trans-subCodalasso" = "#2E8B57",  
  "Naive-Trans-subCodalasso"  = "#3CB371",  
  "Trans-subCodalasso"        = "#A2AD00", 
  "subCodalasso"              = "#E76BF3", 
  "Pooled-subCodalasso"     = "#9400D3",
  "Trans-Lasso-raw"           = "#4682B4", 
  "Trans-Lasso-alr"           = "#1E90FF", 
  "Trans-Lasso-clr"           = "#00BFFF",  
  "Trans-GLM-raw"             = "#FFBF00",  
  "Trans-GLM-alr"             = "#F8766D", 
  "Trans-GLM-clr"             = "#FF4500"  
)

p_final <- ggplot(df_filtered, aes(x = factor(n0), y = l2_total_mean, 
                                   color = model, shape = model, 
                                   group = model)) +
  geom_line(linewidth = 0.4, alpha = 0.9) +
  geom_point(size = 1.5, alpha = 0.9) + 
  
  facetted_pos_scales(
    x = list(scale_x_discrete(guide = "axis")),
    y = list(TRUE ~ scale_y_continuous(guide = "axis"))
  ) +
  
  facet_wrap2(
    ~ size.A0, 
    nrow = 1, 
    scales = "free_y", 
    axes = "all",
    labeller = labeller(size.A0 = function(x) paste0("|A| = ", x))
  ) +
  
  scale_color_manual(name = "Method", values = my_colors) +
  scale_shape_manual(name = "Method", values = my_shapes) +
  
  labs(x = expression(n[0]), 
       y = expression("L"[2] ~ "error"), 
       color = "Method", 
       shape = "Method") +
  
  theme_bw(base_size = 12) +
  theme(
    strip.background = element_rect(fill = "gray95"),
    strip.text = element_text(size = 11),
    
    legend.position = "bottom",
    legend.box = "horizontal",
    legend.direction = "horizontal",
    legend.title = element_text(size = 14), 
    legend.text = element_text(size = 12),
    legend.key.size = unit(1.2, "lines"),
    legend.spacing.x = unit(0.1, "cm"),
    legend.spacing.y = unit(0.5, "cm"),
    axis.text.x = element_text(size = 9, color = "black", vjust = 0.5),
    axis.text.y = element_text(size = 9, color = "black"),
    
    panel.spacing.x = unit(2, "lines"), 
    panel.spacing.y = unit(1.5, "lines"),
    panel.grid.minor = element_blank(),
    axis.line = element_line(color = "black"),
    plot.margin = margin(10, 20, 10, 20)
  ) +
  
  force_panelsizes(rows = 1, cols = 1) +
  
  guides(
    color = guide_legend(title = "Method", ncol = 4, byrow = TRUE),
    shape = guide_legend(title = "Method", ncol = 4, byrow = TRUE)
  )

print(p_final)

p_pred <- ggplot(df_filtered, aes(x = factor(n0), y = pe_mean, 
                                   color = model, shape = model, 
                                   group = model)) +
  geom_line(linewidth = 0.4, alpha = 0.9) +
  geom_point(size = 1.5, alpha = 0.9) + 
  
  facetted_pos_scales(
    x = list(scale_x_discrete(guide = "axis")),
    y = list(TRUE ~ scale_y_continuous(guide = "axis"))
  ) +
  
  facet_wrap2(
    ~ size.A0, 
    nrow = 1, 
    scales = "free_y", 
    axes = "all",
    labeller = labeller(size.A0 = function(x) paste0("|A| = ", x))
  ) +
  
  scale_color_manual(name = "Method", values = my_colors) +
  scale_shape_manual(name = "Method", values = my_shapes) +
  
  labs(x = expression(n[0]), 
       y = "Prediction error", 
       color = "Method", 
       shape = "Method") +
  
  theme_bw(base_size = 12) +
  theme(
    strip.background = element_rect(fill = "gray95"),
    strip.text = element_text(size = 11),
    legend.position = "bottom",
    legend.box = "horizontal",
    legend.direction = "horizontal",
    legend.title = element_text(size = 14), 
    legend.text = element_text(size = 12),
    legend.key.size = unit(1.2, "lines"),
    legend.spacing.x = unit(0.1, "cm"),
    legend.spacing.y = unit(0.5, "cm"),
    axis.text.x = element_text(size = 9, color = "black", vjust = 0.5),
    axis.text.y = element_text(size = 9, color = "black"),
    panel.spacing.x = unit(2, "lines"), 
    panel.spacing.y = unit(1.5, "lines"),
    panel.grid.minor = element_blank(),
    axis.line = element_line(color = "black"),
    plot.margin = margin(10, 20, 10, 20)
  ) +
  
  force_panelsizes(rows = 1, cols = 1) +
  
  guides(
    color = guide_legend(title = "Method", ncol = 4, byrow = TRUE),
    shape = guide_legend(title = "Method", ncol = 4, byrow = TRUE)
  )

print(p_pred)
df_long <- df_filtered %>%
  dplyr::select(n0, model, size.A0, l2_total_mean, pe_mean) %>%
  pivot_longer(
    cols = c(l2_total_mean, pe_mean),
    names_to = "metric",
    values_to = "value"
  ) %>%
  mutate(
    metric_label = case_when(
      metric == "l2_total_mean" ~ "L[2]~error",
      metric == "pe_mean" ~ "Prediction~error"
    ),
    metric_label = factor(metric_label, 
                          levels = c("L[2]~error", "Prediction~error"))
  )

p_combined <- ggplot(df_long, 
                     aes(x = factor(n0), y = value, 
                         color = model, shape = model, 
                         group = model)) +
  geom_line(linewidth = 0.3, alpha = 0.9) +
  geom_point(size = 1.5, alpha = 0.9) +
  
  facet_grid(
    rows = vars(metric_label),
    cols = vars(size.A0),
    scales = "free_y",
    labeller = labeller(
      metric_label = label_parsed,  
      size.A0 = function(x) paste0("|A| = ", x)
    )
  ) +
  
  scale_color_manual(name = "Method", values = my_colors) +
  scale_shape_manual(name = "Method", values = my_shapes) +
  
  labs(x = expression(n[0]), y = NULL) +
  
  theme_bw(base_size = 12) +
  theme(
    strip.background = element_rect(fill = "gray95"),
    strip.text = element_text(size = 11),
    strip.text.y = element_text(size = 12),  
    
    legend.position = "bottom",
    legend.box = "horizontal",
    legend.direction = "horizontal",
    legend.title = element_text(size = 14),
    legend.text = element_text(size = 12),
    legend.key.size = unit(1.2, "lines"),
    
    axis.text.x = element_text(size = 9, color = "black", vjust = 0.5),
    axis.text.y = element_text(size = 9, color = "black"),
    
    panel.spacing = unit(1.5, "lines"),
    panel.grid.minor = element_blank(),
    axis.line = element_line(color = "black"),
    plot.margin = margin(10, 20, 10, 20)
  ) +
  
  guides(
    color = guide_legend(title = "Method", ncol = 4, byrow = TRUE),
    shape = guide_legend(title = "Method", ncol = 4, byrow = TRUE)
  )

print(p_combined)

ggsave("E:/.../target size.pdf", p_combined, width = 12, height = 7)
