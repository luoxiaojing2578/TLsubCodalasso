# realdata(compositon)

library(openxlsx)
library(glmtrans)
source("Func-TransCodaLasso.R")  
source("Func-TransLasso1.R") 

###################### Data Preparation ######################
data <- read.csv("abundance_stoolsubset.csv")
data <- data[!is.na(data$bmi) & data$bmi != "na" & data$bmi != "nd", ] 
genus_columns <- names(data)[ 
  grepl("\\.g__", names(data)) & 
    !grepl("\\.s__", names(data)) & 
    !grepl("\\.t__", names(data)) 
]
genus_mat <- data[, genus_columns, drop = FALSE]
zero_ratio <- colMeans(genus_mat == 0) 
genus_columns <- genus_columns[zero_ratio <= 0.9] 
cat("raw genus :", ncol(genus_mat), "\n") 
cat("new genus :", length(genus_columns), "\n") 
extract_phylum <- function(x){ 
  if (grepl("p__", x)) { 
    sub(".*p__([^\\.\\|;]+).*", "\\1", x) 
  } else { 
    NA_character_ 
  }
}
genus_phylum <- sapply(genus_columns, extract_phylum) 
phylum_count <- table(genus_phylum) 
valid_phylum <- names(phylum_count[phylum_count >= 2]) 
genus_columns <- genus_columns[genus_phylum %in% valid_phylum] 
genus_phylum  <- genus_phylum[genus_phylum %in% valid_phylum] 
cat("phylum(genus >= 2):", length(valid_phylum), "\n") 
cat("genus:", length(genus_columns), "\n") 
ord <- order(genus_phylum, genus_columns, na.last = TRUE) 
genus_columns_ordered <- genus_columns[ord] 
genus_phylum_ordered <- genus_phylum[ord] 
group_sizes <- as.numeric(table(genus_phylum_ordered)) 
tind <- c(0, cumsum(group_sizes)) 
data$bmi <- as.numeric(data$bmi)
data <- data[, c("gender", "disease", "bmi", genus_columns)]
data <- na.omit(data)

###################### Compositonal and Subcomposional data ######################
process_data <- function(df){
  comp_mat <- as.matrix(df[, genus_columns_ordered, drop = FALSE]) 
  comp_mat[comp_mat == 0] <- 0.5 
  comp_total <- comp_mat / rowSums(comp_mat) 
  comp_sub <- matrix(0, nrow = nrow(comp_mat), ncol = ncol(comp_mat)) 
  for (g in 1:(length(tind)-1)) { 
    idx <- (tind[g]+1):tind[g+1] 
    comp_sub[, idx] <- comp_mat[, idx, drop = FALSE] / rowSums(comp_mat[, idx, drop = FALSE]) 
  }
  X_logcomp_total <- log(comp_total) 
  X_logcomp_sub   <- log(comp_sub) 
  X_subalr        <- subcomp_alr_transform(comp_total, tind) 
  X_clr           <- clr_transform(comp_total, tind) 
  X_alr_global    <- global_alr_transform(comp_total)   
  X_clr_global    <- global_clr_transform(comp_total) 
  
  list(
    X_logcomp_total = X_logcomp_total,
    X_logcomp_sub   = X_logcomp_sub,
    X_subalr        = X_subalr,
    X_clr           = X_clr,
    X_alr_global    = X_alr_global,    
    X_clr_global    = X_clr_global,   
    y               = df$bmi
  )
}

global_alr_transform <- function(C_total){
  p <- ncol(C_total) 
  ref_col <- C_total[, p]  
  num_cols <- C_total[, -p, drop = FALSE]  
  Z_alr <- log(sweep(num_cols, 1, ref_col, "/"))  
  
  return(Z_alr)
}

global_clr_transform <- function(C_total){
  gm <- exp(rowMeans(log(C_total)))  
  Z_clr <- log(sweep(C_total, 1, gm, "/"))  
  return(Z_clr)
}

subcomp_alr_transform <- function(C_total, tind){ 
  z_list <- vector("list", length(tind) - 1) 
  for (g in 1:(length(tind) - 1)) { 
    group_idx <- (tind[g] + 1):tind[g + 1] 
    C_g <- C_total[, group_idx, drop = FALSE] 
    p_g <- ncol(C_g) 
    ref_col <- C_g[, p_g]
    num_cols <- C_g[, -p_g, drop = FALSE] 
    z_list[[g]] <- log(sweep(num_cols, 1, ref_col, "/"))
  }
  do.call(cbind, z_list)
}

clr_transform <- function(C_total, tind){ 
  z_list <- vector("list", length(tind) - 1) 
  for (g in 1:(length(tind) - 1)) { 
    idx <- (tind[g]+1):tind[g+1] 
    C_g <- C_total[, idx, drop = FALSE] 
    gm <- exp(rowMeans(log(C_g))) 
    z_list[[g]] <- log(sweep(C_g, 1, gm, "/")) 
  }
  
  do.call(cbind, z_list) 
}

###################### Target+Source ######################
# S1 = female + ibd_ulcerative_colitis
# S2 = female + n
# S3 = male   + n
# S4 = male   + ibd_ulcerative_colitis
global_data_raw <- list(
  S1 = data[data$gender == "female" & data$disease == "ibd_ulcerative_colitis", ],
  S2 = data[data$gender == "female" & data$disease == "n", ],
  S3 = data[data$gender == "male"   & data$disease == "n", ],
  S4 = data[data$gender == "male"   & data$disease == "ibd_ulcerative_colitis", ]
)
global_data_proc <- lapply(global_data_raw, process_data) 

# UC(female)
setting_list <- list(
  list(setting_id = 1, target_id = 1, source_ids = c(2, 3, 4))
)

# Normal(female)
# setting_list <- list(
#   list(setting_id = 2, target_id = 2, source_ids = c(1, 3, 4))
# )

# Normal(male)
# setting_list <- list(
#   list(setting_id = 3, target_id = 3, source_ids = c(1, 2, 4))
# )

# UC(female)
# setting_list <- list(
#   list(setting_id = 4, target_id = 4, source_ids = c(1, 2, 3))
# )

###################### Experimental Setup ######################
nrep <- 100
epsilon_values <- c(0.0001, 0.001, 0.01, 0.1, 1)
lam0_seq <- exp(seq(log(0.1), log(0.5), length.out = 100))

total_runs <- length(setting_list) * nrep 
pe <- matrix(0, total_runs, 20) 
colnames(pe) <- c(
  "coda", "subcoda",
  "trans_single", "trans_sub",
  "naive_single", "naive_sub",
  "pool_single", "pool_sub",
  "transglm_raw_single", "transglm_alr_single", "transglm_clr_single",
  "transglm_raw_sub", "transglm_alr_sub", "transglm_clr_sub",
  "translasso_raw_single", "translasso_alr_single", "translasso_clr_single",
  "translasso_raw_sub", "translasso_alr_sub", "translasso_clr_sub"
)
r2 <- matrix(NA_real_, total_runs, 20)
colnames(r2) <- colnames(pe)
calc_r2 <- function(y_true, y_pred){
  sst <- sum((y_true - mean(y_true))^2)
  sse <- sum((y_true - y_pred)^2)
  if (sst <= 0) return(NA_real_)
  1 - sse / sst
}
run_info <- data.frame(
  Run = 1:total_runs, 
  Setting = integer(total_runs), 
  Rep = integer(total_runs), 
  Target = character(total_runs), 
  stringsAsFactors = FALSE 
)
beta_store <- vector("list", ncol(pe)) 
names(beta_store) <- colnames(pe) 
for (k in seq_along(beta_store)) beta_store[[k]] <- list() 
selection_cols <- c(
  "S1", "S2", "S3", "S4", 
  "S12", "S13", "S14", "S23", "S24", "S34", 
  "S123", "S124", "S134", "S234" 
)
init_selection_df <- function(total_runs, selection_cols){ 
  df <- data.frame( 
    Setting = integer(total_runs), 
    Rep = integer(total_runs), 
    Target = character(total_runs), 
    stringsAsFactors = FALSE 
  )
  for (nm in selection_cols) df[[nm]] <- 0 
  df 
}

fill_selection_row <- function(df, row_id, setting_id, rep_id, target_global_id, selected_global_ids, selection_cols){
  df$Setting[row_id] <- setting_id 
  df$Rep[row_id] <- rep_id 
  df$Target[row_id] <- paste0("S", target_global_id) 
  target_col <- paste0("S", target_global_id) 
  if (target_col %in% selection_cols) df[row_id, target_col] <- 1 
  if (length(selected_global_ids) > 0) { 
    for (gid in selected_global_ids) { 
      one_col <- paste0("S", gid) 
      if (one_col %in% selection_cols) df[row_id, one_col] <- 1 
    }
  }
  if (length(selected_global_ids) >= 2) { 
    combo_col <- paste0("S", paste(sort(selected_global_ids), collapse = "")) 
    if (combo_col %in% selection_cols) df[row_id, combo_col] <- 1 
  }
  df  
}
map_local_to_global <- function(local_sel, source_global_ids){
  if (is.null(local_sel) || length(local_sel) == 0) return(integer(0)) 
  source_global_ids[local_sel] 
}
selection_trans_single <- init_selection_df(total_runs, selection_cols)
selection_trans_sub    <- init_selection_df(total_runs, selection_cols)
selection_glm_raw_single      <- init_selection_df(total_runs, selection_cols)
selection_glm_alr_single      <- init_selection_df(total_runs, selection_cols)
selection_glm_clr_single      <- init_selection_df(total_runs, selection_cols)
selection_glm_raw_sub      <- init_selection_df(total_runs, selection_cols)
selection_glm_alr_sub      <- init_selection_df(total_runs, selection_cols)
selection_glm_clr_sub      <- init_selection_df(total_runs, selection_cols)

###################### Real Data ######################
run_idx <- 0 
for (cfg in setting_list) { 
  setting_id <- cfg$setting_id 
  target_id  <- cfg$target_id 
  source_ids <- cfg$source_ids 
  target_label <- paste0("S", target_id) 
  source_labels <- paste0("S", source_ids) 
  target <- global_data_proc[[target_label]] 
  sources <- global_data_proc[source_labels] 
  X_target_logcomp_total <- target$X_logcomp_total
  X_target_logcomp_sub   <- target$X_logcomp_sub
  X_target_subalr        <- target$X_subalr
  X_target_clr           <- target$X_clr
  X_target_alr_global <- target$X_alr_global  
  X_target_clr_global <- target$X_clr_global 
  y_target               <- target$y
  X_source_logcomp_total <- do.call(rbind, lapply(sources, function(x) x$X_logcomp_total))
  X_source_logcomp_sub   <- do.call(rbind, lapply(sources, function(x) x$X_logcomp_sub))
  X_source_subalr        <- do.call(rbind, lapply(sources, function(x) x$X_subalr))
  X_source_clr           <- do.call(rbind, lapply(sources, function(x) x$X_clr))
  X_source_alr_global <- do.call(rbind, lapply(sources, function(x) x$X_alr_global))  
  X_source_clr_global <- do.call(rbind, lapply(sources, function(x) x$X_clr_global)) 
  y_source               <- unlist(lapply(sources, function(x) x$y))
  N_target <- matrix(1, nrow = nrow(X_target_logcomp_total), ncol = 1) 
  N_source <- matrix(1, nrow = nrow(X_source_logcomp_total), ncol = 1) 
  colnames(N_target) <- "Intercept" 
  colnames(N_source) <- "Intercept" 
  p_n <- 1 
  n_target <- length(y_target) 
  n_source <- sapply(sources, function(x) length(x$y)) 
  n.vec <- c(n_target, n_source) 
  ntrn <- floor(n_target * 0.7) 
  n.vectrain <- c(ntrn, n_source) 
  M <- length(sources) 
  cat("\n================ Data Info ================\n")
  cat("Setting:", setting_id, "\n")
  cat("Target:", target_label, "\n")
  cat("Sources:", paste(source_labels, collapse = ", "), "\n")
  cat("Target sample size:", n_target, "\n")
  cat("Source sample sizes:", paste(n_source, collapse = ", "), "\n")
  cat("===========================================\n\n")
  
  for (i in 1:nrep) {
    run_idx <- run_idx + 1 
    run_info$Setting[run_idx] <- setting_id 
    run_info$Rep[run_idx] <- i 
    run_info$Target[run_idx] <- target_label 
    set.seed(1000 * setting_id + i)
    itrn <- sample(n_target, ntrn) 
    itst <- setdiff(1:n_target, itrn) 
    Xtr_logcomp_total <- X_target_logcomp_total[itrn, , drop = FALSE] 
    Xte_logcomp_total <- X_target_logcomp_total[itst, , drop = FALSE] 
    Xtr_logcomp_sub <- X_target_logcomp_sub[itrn, , drop = FALSE]
    Xte_logcomp_sub <- X_target_logcomp_sub[itst, , drop = FALSE] 
    Xtr_subalr <- X_target_subalr[itrn, , drop = FALSE] 
    Xte_subalr <- X_target_subalr[itst, , drop = FALSE] 
    Xtr_clr <- X_target_clr[itrn, , drop = FALSE] 
    Xte_clr <- X_target_clr[itst, , drop = FALSE]
    Xtr_alr_global <- X_target_alr_global[itrn, , drop = FALSE] 
    Xte_alr_global <- X_target_alr_global[itst, , drop = FALSE] 
    Xtr_clr_global <- X_target_clr_global[itrn, , drop = FALSE] 
    Xte_clr_global <- X_target_clr_global[itst, , drop = FALSE] 
    Ytr <- y_target[itrn] 
    Yte <- y_target[itst] 
    Ntr <- N_target[itrn, , drop = FALSE] 
    Nte <- N_target[itst, , drop = FALSE] 
    X_train_logcomp_total <- rbind(Xtr_logcomp_total, X_source_logcomp_total) 
    X_train_logcomp_sub   <- rbind(Xtr_logcomp_sub, X_source_logcomp_sub) 
    Y_train <- c(Ytr, y_source) 
    N_train <- rbind(Ntr, N_source) 
    
    cat("Setting", setting_id, "Rep", i, "- Start\n") 
    
    ######## Method 1 coda ########
    cat("Setting", setting_id, "Rep", i, "\n")
    cat("  Method 1: coda\n")
    fit1 <- cv_classo(
      data = list(X = Xtr_logcomp_total, N = Ntr, y = Ytr, tind = tind),
      p = ncol(Xtr_logcomp_total), 
      lam0_seq = lam0_seq, 
      seed = 2025+i,
      constraint_type = "single"
    )
    pred1 <- as.vector(Nte %*% fit1$a + Xte_logcomp_total %*% fit1$beta) 
    pe[run_idx, 1] <- mean((Yte - pred1)^2) 
    r2[run_idx, 1] <- calc_r2(Yte, pred1)
    beta_store$coda[[run_idx]] <- fit1$beta 
    
    ######## Method 2 subcoda ########
    cat("Setting", setting_id, "Rep", i, "\n")
    cat("  Method 2: subcoda\n")
    fit2 <- cv_classo(
      data = list(X = Xtr_logcomp_sub, N = Ntr, y = Ytr, tind = tind),
      p = ncol(Xtr_logcomp_sub),
      lam0_seq = lam0_seq,
      seed = 2025+i,
      constraint_type = "sub"
    )
    pred2 <- as.vector(Nte %*% fit2$a + Xte_logcomp_sub %*% fit2$beta)
    pe[run_idx, 2] <- mean((Yte - pred2)^2)
    r2[run_idx, 2] <- calc_r2(Yte, pred2)
    beta_store$subcoda[[run_idx]] <- fit2$beta
    
    ######## Method 3 trans single ########
    cat("Setting", setting_id, "Rep", i, "\n")
    cat("  Method 3: trans single\n")
    best_pe_single <- Inf 
    best_model_single <- NULL 
    for (eps in epsilon_values) { 
      tmp <- Trans.Codalasso.sub(
        Xtrain = X_train_logcomp_total,
        Ntrain = N_train,
        ytrain = Y_train,
        tind = tind,
        n = n.vectrain, 
        M = M, 
        epsilon = eps,
        lam0_seq = lam0_seq,
        seed = 2025+i,
        constraint_type = "single"
      )
      pred_tmp <- as.vector(Nte %*% tmp$a_hat + Xte_logcomp_total %*% tmp$beta_hat)
      pe_tmp <- mean((Yte - pred_tmp)^2)
      r2_tmp <- calc_r2(Yte, pred_tmp)
      if (pe_tmp < best_pe_single) {
        best_pe_single <- pe_tmp
        best_r2_single <- r2_tmp
        best_model_single <- tmp
      }
    }
    pe[run_idx, 3] <- best_pe_single
    r2[run_idx, 3] <- best_r2_single
    beta_store$trans_single[[run_idx]] <- best_model_single$beta_hat
    sel_single_global <- map_local_to_global(best_model_single$selected_sources, source_ids)
    selection_trans_single <- fill_selection_row(
      selection_trans_single, run_idx, setting_id, i, target_id, sel_single_global, selection_cols
    )
    
    ######## Method 4 trans sub ########
    cat("Setting", setting_id, "Rep", i, "\n")
    cat("  Method 4: trans sub\n")
    best_pe_sub <- Inf
    best_model_sub <- NULL
    for (eps in epsilon_values) {
      tmp <- Trans.Codalasso.sub(
        Xtrain = X_train_logcomp_sub,
        Ntrain = N_train,
        ytrain = Y_train,
        tind = tind,
        n = n.vectrain,
        M = M,
        epsilon = eps,
        lam0_seq = lam0_seq,
        seed = 2025+i,
        constraint_type = "sub"
      )
      pred_tmp <- as.vector(Nte %*% tmp$a_hat + Xte_logcomp_sub %*% tmp$beta_hat)
      pe_tmp <- mean((Yte - pred_tmp)^2)
      r2_tmp <- calc_r2(Yte, pred_tmp)
      if (pe_tmp < best_pe_sub) {
        best_pe_sub <- pe_tmp
        best_r2_sub <- r2_tmp
        best_model_sub <- tmp
      }
    }
    pe[run_idx, 4] <- best_pe_sub
    r2[run_idx, 4] <- best_r2_sub
    beta_store$trans_sub[[run_idx]] <- best_model_sub$beta_hat
    sel_sub_global <- map_local_to_global(best_model_sub$selected_sources, source_ids)
    selection_trans_sub <- fill_selection_row(
      selection_trans_sub, run_idx, setting_id, i, target_id, sel_sub_global, selection_cols
    )
    
    ######## Method 5 naive single ########
    cat("Setting", setting_id, "Rep", i, "\n")
    cat("  Method 5: naive single\n")
    fit5 <- Naive.subCodalasso(
      X = X_train_logcomp_total, 
      N = N_train,
      y = Y_train,
      tind = tind,
      n.vec = n.vectrain,
      lam0_seq = lam0_seq,
      seed = 2025+i,
      constraint_type = "single"
    )
    pred5 <- as.vector(Nte %*% fit5$a + Xte_logcomp_total %*% fit5$beta)
    pe[run_idx, 5] <- mean((Yte - pred5)^2)
    r2[run_idx, 5] <- calc_r2(Yte, pred5)
    beta_store$naive_single[[run_idx]] <- fit5$beta
    
    ######## Method 6 naive sub ########
    cat("Setting", setting_id, "Rep", i, "\n")
    cat("  Method 6: naive sub\n")
    fit6 <- Naive.subCodalasso(
      X = X_train_logcomp_sub,
      N = N_train,
      y = Y_train,
      tind = tind,
      n.vec = n.vectrain,
      lam0_seq = lam0_seq,
      seed = 2025+i,
      constraint_type = "sub"
    )
    pred6 <- as.vector(Nte %*% fit6$a + Xte_logcomp_sub %*% fit6$beta)
    pe[run_idx, 6] <- mean((Yte - pred6)^2)
    r2[run_idx, 6] <- calc_r2(Yte, pred6)
    beta_store$naive_sub[[run_idx]] <- fit6$beta
    
    ######## Method 7 pool single ########
    cat("Setting", setting_id, "Rep", i, "\n")
    cat("  Method 7: pool single\n")
    fit7 <- cv_classo(
      data = list(X = X_train_logcomp_total, N = N_train, y = Y_train, tind = tind), # 输入合并后的 total 特征
      p = ncol(X_train_logcomp_total), 
      lam0_seq = lam0_seq,
      seed = 2025+i,
      constraint_type = "single"
    )
    pred7 <- as.vector(Nte %*% fit7$a + Xte_logcomp_total %*% fit7$beta)
    pe[run_idx, 7] <- mean((Yte - pred7)^2)
    r2[run_idx, 7] <- calc_r2(Yte, pred7)
    beta_store$pool_single[[run_idx]] <- fit7$beta
    
    ######## Method 8 pool sub ########
    cat("Setting", setting_id, "Rep", i, "\n")
    cat("  Method 8: pool sub\n")
    fit8 <- cv_classo(
      data = list(X = X_train_logcomp_sub, N = N_train, y = Y_train, tind = tind),
      p = ncol(X_train_logcomp_sub),
      lam0_seq = lam0_seq,
      seed = 2025+i,
      constraint_type = "sub"
    )
    pred8 <- as.vector(Nte %*% fit8$a + Xte_logcomp_sub %*% fit8$beta)
    pe[run_idx, 8] <- mean((Yte - pred8)^2)
    r2[run_idx, 8] <- calc_r2(Yte, pred8)
    beta_store$pool_sub[[run_idx]] <- fit8$beta
    
    ######## Method 9 TransGLM.raw_single ########
    cat("Setting", setting_id, "Rep", i, "\n")
    cat("  Method 9: TransGLM.raw_single\n")
    dataset_glm_raw_single <- list(
      X0 = cbind(Ntr, Xtr_logcomp_total), 
      y0 = Ytr, 
      X  = lapply(seq_along(sources), function(k) cbind(rep(1, nrow(sources[[k]]$X_logcomp_total)), sources[[k]]$X_logcomp_total)), 
      y  = lapply(sources, function(s) s$y) 
    )
    fit9 <- glmtrans(
      target = list(x = dataset_glm_raw_single$X0, y = dataset_glm_raw_single$y0),
      source = lapply(seq_along(dataset_glm_raw_single$X), function(k) list(x = dataset_glm_raw_single$X[[k]], y = dataset_glm_raw_single$y[[k]])),
      family = "gaussian",
      transfer.source.id = "auto",
      alpha = 1,
      standardize = TRUE,
      intercept = FALSE,
      nfolds = 10,
      cores = 1,
      lambda.seq = list(
        transfer  = lam0_seq,
        debias    = lam0_seq,
        detection = lam0_seq
      ),    
      detection.info = FALSE
    )
    Xte_glm_raw_single <- cbind(Nte, Xte_logcomp_total)
    beta9 <- as.numeric(fit9$beta[-1]) 
    pred9 <- as.vector(Xte_glm_raw_single %*% beta9)
    pe[run_idx, 9] <- mean((Yte - pred9)^2)
    r2[run_idx, 9] <- calc_r2(Yte, pred9)
    beta_store$transglm_raw_single[[run_idx]] <- beta9[-1] 
    glm_raw_global_single <- map_local_to_global(fit9$transfer.source.id, source_ids)
    selection_glm_raw_single <- fill_selection_row(
      selection_glm_raw_single, run_idx, setting_id, i, target_id, glm_raw_global_single, selection_cols
    )
    
    ######## Method 10 TransGLM.alr_single ########
    cat("Setting", setting_id, "Rep", i, "\n")
    cat("  Method 10: TransGLM.alr_single\n")
    dataset_glm_alr_single <- list(
      X0 = cbind(Ntr, Xtr_alr_global),   
      y0 = Ytr,  
      X  = lapply(sources, function(s) cbind(1, s$X_alr_global)), 
      y  = lapply(sources, function(s) s$y) 
    )
    fit10 <- glmtrans(
      target = list(x = dataset_glm_alr_single$X0, y = dataset_glm_alr_single$y0),
      source = lapply(seq_along(dataset_glm_alr_single$X), function(k) list(x = dataset_glm_alr_single$X[[k]], y = dataset_glm_alr_single$y[[k]])),
      family = "gaussian",
      transfer.source.id = "auto",
      alpha = 1,
      standardize = TRUE,
      intercept = FALSE,
      nfolds = 10,
      cores = 1,
      lambda.seq = list(
        transfer  = lam0_seq,
        debias    = lam0_seq,
        detection = lam0_seq
      ),    
      detection.info = FALSE
    )
    Xte_glm_alr_single <- cbind(Nte, Xte_alr_global) 
    beta10 <- as.numeric(fit10$beta[-1])
    pred10 <- as.vector(Xte_glm_alr_single %*% beta10)
    pe[run_idx, 10] <- mean((Yte - pred10)^2)
    r2[run_idx, 10] <- calc_r2(Yte, pred10)
    beta_store$transglm_alr_single[[run_idx]] <- beta10[-1] 
    glm_alr_global_single <- map_local_to_global(fit10$transfer.source.id, source_ids)
    selection_glm_alr_single <- fill_selection_row(
      selection_glm_alr_single, run_idx, setting_id, i, target_id, glm_alr_global_single, selection_cols
    )
    
    ######## Method 11 TransGLM.clr_single ########
    cat("Setting", setting_id, "Rep", i, "\n")
    cat("  Method 11: TransGLM.clr\n")
    dataset_glm_clr_single <- list(
      X0 = cbind(Ntr, Xtr_clr_global),   
      y0 = Ytr, 
      X  = lapply(sources, function(s) cbind(1, s$X_clr_global)), 
      y  = lapply(sources, function(s) s$y) 
    )
    fit11 <- glmtrans(
      target = list(x = dataset_glm_clr_single$X0, y = dataset_glm_clr_single$y0),
      source = lapply(seq_along(dataset_glm_clr_single$X), function(k) list(x = dataset_glm_clr_single$X[[k]], y = dataset_glm_clr_single$y[[k]])),
      family = "gaussian",
      transfer.source.id = "auto",
      alpha = 1,
      standardize = TRUE,
      intercept = FALSE,
      nfolds = 10,
      cores = 1,
      lambda.seq = list(
        transfer  = lam0_seq,
        debias    = lam0_seq,
        detection = lam0_seq
      ),    
      detection.info = FALSE
    )
    Xte_glm_clr_single <- cbind(Nte, Xte_clr_global)  
    beta11 <- as.numeric(fit11$beta[-1])
    pred11 <- as.vector(Xte_glm_clr_single %*% beta11)
    pe[run_idx, 11] <- mean((Yte - pred11)^2)
    r2[run_idx, 11] <- calc_r2(Yte, pred11)
    beta_store$transglm_clr_single[[run_idx]] <- beta11[-1] 
    glm_clr_global_single <- map_local_to_global(fit11$transfer.source.id, source_ids)
    selection_glm_clr_single <- fill_selection_row(
      selection_glm_clr_single, run_idx, setting_id, i, target_id, glm_clr_global_single, selection_cols
    )
    
    ######## Method 12 TransGLM.raw_sub ########
    cat("Setting", setting_id, "Rep", i, "\n")
    cat("  Method 12: TransGLM.raw_sub\n")
    dataset_glm_raw_sub <- list(
      X0 = cbind(Ntr, Xtr_logcomp_sub),
      y0 = Ytr,
      X  = lapply(seq_along(sources), function(k) cbind(rep(1, nrow(sources[[k]]$X_logcomp_sub)), sources[[k]]$X_logcomp_sub)), # 每个源域输入也补一列1
      y  = lapply(sources, function(s) s$y) 
    )
    fit12 <- glmtrans(
      target = list(x = dataset_glm_raw_sub$X0, y = dataset_glm_raw_sub$y0),
      source = lapply(seq_along(dataset_glm_raw_sub$X), function(k) list(x = dataset_glm_raw_sub$X[[k]], y = dataset_glm_raw_sub$y[[k]])),
      family = "gaussian",
      transfer.source.id = "auto",
      alpha = 1,
      standardize = TRUE,
      intercept = FALSE,
      nfolds = 10,
      cores = 1,
      lambda.seq = list(
        transfer  = lam0_seq,
        debias    = lam0_seq,
        detection = lam0_seq
      ),    
      detection.info = FALSE
    )
    Xte_glm_raw_sub <- cbind(Nte, Xte_logcomp_sub)
    beta12 <- as.numeric(fit12$beta[-1]) 
    pred12 <- as.vector(Xte_glm_raw_sub %*% beta12)
    pe[run_idx, 12] <- mean((Yte - pred12)^2)
    r2[run_idx, 12] <- calc_r2(Yte, pred12)
    beta_store$transglm_raw_sub[[run_idx]] <- beta12[-1] 
    glm_raw_global_sub <- map_local_to_global(fit12$transfer.source.id, source_ids)
    selection_glm_raw_sub <- fill_selection_row(
      selection_glm_raw_sub, run_idx, setting_id, i, target_id, glm_raw_global_sub, selection_cols
    )
    
    ######## Method 13 TransGLM.alr_sub ########
    cat("Setting", setting_id, "Rep", i, "\n")
    cat("  Method 13: TransGLM.alr_sub\n")
    dataset_glm_alr_sub <- list(
      X0 = cbind(Ntr, Xtr_subalr), 
      y0 = Ytr,  
      X  = lapply(seq_along(sources), function(k) cbind(rep(1, nrow(sources[[k]]$X_subalr)), sources[[k]]$X_subalr)), # 每个源域 ALR 输入
      y  = lapply(sources, function(s) s$y) 
    )
    
    fit13 <- glmtrans(
      target = list(x = dataset_glm_alr_sub$X0, y = dataset_glm_alr_sub$y0),
      source = lapply(seq_along(dataset_glm_alr_sub$X), function(k) list(x = dataset_glm_alr_sub$X[[k]], y = dataset_glm_alr_sub$y[[k]])),
      family = "gaussian",
      transfer.source.id = "auto",
      alpha = 1,
      standardize = TRUE,
      intercept = FALSE,
      nfolds = 10,
      cores = 1,
      lambda.seq = list(
        transfer  = lam0_seq,
        debias    = lam0_seq,
        detection = lam0_seq
      ),   
      detection.info = FALSE
    )
    Xte_glm_alr_sub <- cbind(Nte, Xte_subalr)
    beta13 <- as.numeric(fit13$beta[-1])
    pred13 <- as.vector(Xte_glm_alr_sub %*% beta13)
    pe[run_idx, 13] <- mean((Yte - pred13)^2)
    r2[run_idx, 13] <- calc_r2(Yte, pred13)
    beta_store$transglm_alr_sub[[run_idx]] <- beta13[-1] 
    glm_alr_global_sub <- map_local_to_global(fit13$transfer.source.id, source_ids)
    selection_glm_alr_sub <- fill_selection_row(
      selection_glm_alr_sub, run_idx, setting_id, i, target_id, glm_alr_global_sub, selection_cols
    )
    
    ######## Method 14 TransGLM.clr_sub ########
    cat("Setting", setting_id, "Rep", i, "\n")
    cat("  Method 14: TransGLM.clr_sub\n")
    dataset_glm_clr_sub <- list(
      X0 = cbind(Ntr, Xtr_clr), 
      y0 = Ytr, 
      X  = lapply(seq_along(sources), function(k) cbind(rep(1, nrow(sources[[k]]$X_clr)), sources[[k]]$X_clr)), 
      y  = lapply(sources, function(s) s$y)
    )
    fit14 <- glmtrans(
      target = list(x = dataset_glm_clr_sub$X0, y = dataset_glm_clr_sub$y0),
      source = lapply(seq_along(dataset_glm_clr_sub$X), function(k) list(x = dataset_glm_clr_sub$X[[k]], y = dataset_glm_clr_sub$y[[k]])),
      family = "gaussian",
      transfer.source.id = "auto",
      alpha = 1,
      standardize = TRUE,
      intercept = FALSE,
      nfolds = 10,
      cores = 1,
      lambda.seq = list(
        transfer  = lam0_seq,
        debias    = lam0_seq,
        detection = lam0_seq
      ),   
      detection.info = FALSE
    )
    
    Xte_glm_clr_sub <- cbind(Nte, Xte_clr)
    beta14 <- as.numeric(fit14$beta[-1])
    pred14 <- as.vector(Xte_glm_clr_sub %*% beta14)
    pe[run_idx, 14] <- mean((Yte - pred14)^2)
    r2[run_idx, 14] <- calc_r2(Yte, pred14)
    beta_store$transglm_clr_sub[[run_idx]] <- beta14[-1] 
    glm_clr_global_sub <- map_local_to_global(fit14$transfer.source.id, source_ids)
    selection_glm_clr_sub <- fill_selection_row(
      selection_glm_clr_sub, run_idx, setting_id, i, target_id, glm_clr_global_sub, selection_cols
    )
    
    ######## Method 15 TransLasso.raw_single ########
    cat("Setting", setting_id, "Rep", i, "\n")
    cat("  Method 15: TransLasso.raw_single\n")
    dataset_tl_raw_single <- list(
      X0 = cbind(Ntr, Xtr_logcomp_total), 
      y0 = Ytr, 
      X  = lapply(sources, function(s) cbind(1, s$X_logcomp_total)), 
      y  = lapply(sources, function(s) s$y) 
    )
    fit15 <- fit.TransLasso.Full(
      dataset = dataset_tl_raw_single,
      K = M, 
      split_ratio = 0.5, 
      base_lambda_seq = lam0_seq
    )
    Xte_tl_raw_single <- cbind(Nte, Xte_logcomp_total)
    beta15 <- as.numeric(fit15$coef)
    pred15 <- as.vector(Xte_tl_raw_single %*% beta15)
    pe[run_idx, 15] <- mean((Yte - pred15)^2)
    r2[run_idx, 15] <- calc_r2(Yte, pred15)
    beta_store$translasso_raw_single[[run_idx]] <- beta15[-1]
    
    ######## Method 16 TransLasso.alr_single ########
    cat("Setting", setting_id, "Rep", i, "\n")
    cat("  Method 16: TransLasso.alr_single\n")
    dataset_tl_alr_single <- list(
      X0 = cbind(Ntr, Xtr_alr_global),   
      y0 = Ytr, 
      X  = lapply(sources, function(s) cbind(1, s$X_alr_global)),  
      y  = lapply(sources, function(s) s$y) 
    )
    fit16 <- fit.TransLasso.Full(
      dataset = dataset_tl_alr_single,
      K = M,
      split_ratio = 0.5,
      base_lambda_seq = lam0_seq
    )
    Xte_tl_alr_single <- cbind(Nte, Xte_alr_global)  
    beta16 <- as.numeric(fit16$coef)
    pred16 <- as.vector(Xte_tl_alr_single %*% beta16)
    pe[run_idx, 16] <- mean((Yte - pred16)^2)
    r2[run_idx, 16] <- calc_r2(Yte, pred16)
    beta_store$translasso_alr_single[[run_idx]] <- beta16[-1]
    
    ######## Method 17 TransLasso.clr_single ########
    cat("Setting", setting_id, "Rep", i, "\n")
    cat("  Method 17: TransLasso.clr_single\n")
    dataset_tl_clr_single <- list(
      X0 = cbind(Ntr, Xtr_clr_global),   
      y0 = Ytr, 
      X  = lapply(sources, function(s) cbind(1, s$X_clr_global)), 
      y  = lapply(sources, function(s) s$y)
    )
    fit17 <- fit.TransLasso.Full(
      dataset = dataset_tl_clr_single,
      K = M,
      split_ratio = 0.5,
      base_lambda_seq = lam0_seq
    )
    Xte_tl_clr_single <- cbind(Nte, Xte_clr_global) 
    beta17 <- as.numeric(fit17$coef)
    pred17 <- as.vector(Xte_tl_clr_single %*% beta17)
    pe[run_idx, 17] <- mean((Yte - pred17)^2)
    r2[run_idx, 17] <- calc_r2(Yte, pred17)
    beta_store$translasso_clr_single[[run_idx]] <- beta17[-1]
    
    ######## Method 18 TransLasso.raw_sub ########
    cat("Setting", setting_id, "Rep", i, "\n")
    cat("  Method 18: TransLasso.raw_sub\n")
    dataset_tl_raw_sub <- list(
      X0 = cbind(Ntr, Xtr_logcomp_sub),
      y0 = Ytr,
      X  = lapply(sources, function(s) cbind(1, s$X_logcomp_sub)), 
      y  = lapply(sources, function(s) s$y) 
    )
    fit18 <- fit.TransLasso.Full(
      dataset = dataset_tl_raw_sub,
      K = M, 
      split_ratio = 0.5, 
      base_lambda_seq = lam0_seq
    )
    Xte_tl_raw_sub <- cbind(Nte, Xte_logcomp_sub)
    beta18 <- as.numeric(fit18$coef)
    pred18 <- as.vector(Xte_tl_raw_sub %*% beta18)
    pe[run_idx, 18] <- mean((Yte - pred18)^2)
    r2[run_idx, 18] <- calc_r2(Yte, pred18)
    beta_store$translasso_raw_sub[[run_idx]] <- beta18[-1]
    
    ######## Method 19 TransLasso.alr_sub ########
    cat("Setting", setting_id, "Rep", i, "\n")
    cat("  Method 19: TransLasso.alr_sub\n")
    dataset_tl_alr_sub <- list(
      X0 = cbind(Ntr, Xtr_subalr), 
      y0 = Ytr,
      X  = lapply(sources, function(s) cbind(1, s$X_subalr)), 
      y  = lapply(sources, function(s) s$y)  
    )
    fit19 <- fit.TransLasso.Full(
      dataset = dataset_tl_alr_sub,
      K = M,
      split_ratio = 0.5,
      base_lambda_seq = lam0_seq
    )
    Xte_tl_alr_sub <- cbind(Nte, Xte_subalr)
    beta19 <- as.numeric(fit19$coef)
    pred19 <- as.vector(Xte_tl_alr_sub %*% beta19)
    pe[run_idx, 19] <- mean((Yte - pred19)^2)
    r2[run_idx, 19] <- calc_r2(Yte, pred19)
    beta_store$translasso_alr_sub[[run_idx]] <- beta19[-1]
    
    ######## Method 20 TransLasso.clr_sub ########
    cat("Setting", setting_id, "Rep", i, "\n")
    cat("  Method 20: TransLasso.clr_sub\n")
    dataset_tl_clr_sub <- list(
      X0 = cbind(Ntr, Xtr_clr),
      y0 = Ytr, 
      X  = lapply(sources, function(s) cbind(1, s$X_clr)), 
      y  = lapply(sources, function(s) s$y) 
    )
    fit20 <- fit.TransLasso.Full(
      dataset = dataset_tl_clr_sub,
      K = M,
      split_ratio = 0.5,
      base_lambda_seq = lam0_seq
    )
    Xte_tl_clr_sub <- cbind(Nte, Xte_clr)
    beta20 <- as.numeric(fit20$coef)
    pred20 <- as.vector(Xte_tl_clr_sub %*% beta20)
    pe[run_idx, 20] <- mean((Yte - pred20)^2)
    r2[run_idx, 20] <- calc_r2(Yte, pred20)
    beta_store$translasso_clr_sub[[run_idx]] <- beta20[-1]
    
    cat("Setting", setting_id, "Rep", i, "done\n")
  }
}

###################### Result ######################
pad_list_to_df <- function(lst){
  max_len <- max(sapply(lst, length)) 
  out <- lapply(lst, function(x){ 
    c(x, rep(NA_real_, max_len - length(x))) 
  })
  as.data.frame(out)
}

export_to_excel <- function(res, filename){
  wb <- createWorkbook() 
  
  pe_df <- data.frame(
    Method = names(res$pe_mean),
    PE = as.numeric(res$pe_mean)
  )
  addWorksheet(wb, "PE_mean") 
  writeData(wb, "PE_mean", pe_df) 
  
  addWorksheet(wb, "PE_raw")
  writeData(wb, "PE_raw", res$pe_raw_df) 
  
  r2_df <- data.frame(
    Method = names(res$r2_mean),
    R2 = as.numeric(res$r2_mean)
  )
  addWorksheet(wb, "R2_mean")
  writeData(wb, "R2_mean", r2_df)
  
  addWorksheet(wb, "R2_raw")
  writeData(wb, "R2_raw", res$r2_raw_df)
  
  addWorksheet(wb, "selection_trans_single") 
  writeData(wb, "selection_trans_single", res$selection_trans_single)
  
  addWorksheet(wb, "selection_trans_sub") 
  writeData(wb, "selection_trans_sub", res$selection_trans_sub)
  
  addWorksheet(wb, "selection_glm_raw_single") 
  writeData(wb, "selection_glm_raw_single", res$selection_glm_raw)
  
  addWorksheet(wb, "selection_glm_alr_single") 
  writeData(wb, "selection_glm_alr_single", res$selection_glm_alr)
  
  addWorksheet(wb, "selection_glm_clr_single") 
  writeData(wb, "selection_glm_clr_single", res$selection_glm_clr)
  
  addWorksheet(wb, "selection_glm_raw_sub")
  writeData(wb, "selection_glm_raw_sub", res$selection_glm_raw)
  
  addWorksheet(wb, "selection_glm_alr_sub") 
  writeData(wb, "selection_glm_alr_sub", res$selection_glm_alr)
  
  addWorksheet(wb, "selection_glm_clr_sub") 
  writeData(wb, "selection_glm_clr_sub", res$selection_glm_clr)
  
  beta_pos <- lapply(res$beta_store, function(method_list){ 
    mat <- do.call(cbind, method_list) 
    rowMeans(mat > 0) 
  })
  beta_pos_df <- pad_list_to_df(beta_pos) 
  addWorksheet(wb, "beta_pos_prob") 
  writeData(wb, "beta_pos_prob", beta_pos_df) 
  
  beta_neg <- lapply(res$beta_store, function(method_list){ 
    mat <- do.call(cbind, method_list) 
    rowMeans(mat < 0) 
  })
  beta_neg_df <- pad_list_to_df(beta_neg) 
  addWorksheet(wb, "beta_neg_prob") 
  writeData(wb, "beta_neg_prob", beta_neg_df) 
  
  for (nm in names(res$beta_store)) { 
    method_list <- res$beta_store[[nm]] 
    mat <- do.call(cbind, method_list) 
    colnames(mat) <- paste0("run", seq_len(ncol(mat))) 
    sheet_name <- substr(paste0("beta_", nm), 1, 31) 
    addWorksheet(wb, sheet_name) 
    writeData(wb, sheet_name, as.data.frame(mat)) 
  }
  
  saveWorkbook(wb, filename, overwrite = TRUE)  
}

pe_raw_df <- cbind(run_info, as.data.frame(pe)) 
r2_raw_df <- cbind(run_info, as.data.frame(r2))

res <- list(
  pe_raw = pe,
  pe_raw_df = pe_raw_df,
  pe_mean = colMeans(pe, na.rm = TRUE),
  r2_raw = r2,
  r2_raw_df = r2_raw_df,
  r2_mean = colMeans(r2, na.rm = TRUE),
  beta_store = beta_store,
  selection_trans_single = selection_trans_single,
  selection_trans_sub = selection_trans_sub,
  selection_glm_raw_single = selection_glm_raw_single,
  selection_glm_alr_single = selection_glm_alr_single,
  selection_glm_clr_single = selection_glm_clr_single,
  selection_glm_raw_sub = selection_glm_raw_sub,
  selection_glm_alr_sub = selection_glm_alr_sub,
  selection_glm_clr_sub = selection_glm_clr_sub
)

export_to_excel(res, "81set1-100-singlesub.xlsx") 
print(
  data.frame(
    Method = names(res$pe_mean),
    PE = as.numeric(res$pe_mean),
    R2 = as.numeric(res$r2_mean)
  )
)








