# Top10 selected genera - single

library(readxl)
library(dplyr)
library(tidyr)
library(openxlsx)
library(stringr)
library(purrr)

result_dir <- "E:/..."

data_file <- "E:/.../abundance_stoolsubset.csv"

out_file <- file.path(result_dir, "Top10_selected_taxa_comparison_method_rows.xlsx")

files_comp <- file.path(result_dir, c(
  "81set1-100-singlesub.xlsx",
  "81set2-100-singlesub.xlsx",
  "81set3-100-singlesub.xlsx",
  "81set4-100-singlesub.xlsx"
))

files_age <- file.path(result_dir, c(
  "81set1-100-singlesub-ncn0105.xlsx",
  "81set2-100-singlesub-ncn0105.xlsx",
  "81set3-100-singlesub-ncn0105.xlsx",
  "81set4-100-singlesub-ncn0105.xlsx"
))

target_labels <- c(
  "Target: UC female",
  "Target: Normal female",
  "Target: Normal male",
  "Target: UC male"
)

methods_to_compare <- c(
  "coda",
  "trans_single",
  "naive_single",
  "pool_single",
  "transglm_alr_single",
  "translasso_alr_single"
)

method_labels <- c(
  "coda" = "SubCoda-Lasso",
  "trans_single" = "Trans-subCodaLasso",
  "naive_single" = "Naive Trans-subCodaLasso",
  "pool_single" = "Pooled-subCodaLasso",
  "transglm_alr_single" = "Trans-GLM-alr",
  "translasso_alr_single" = "Trans-Lasso-alr"
)

data_raw <- read.csv(data_file)

data_raw <- data_raw[
  !is.na(data_raw$bmi) &
    data_raw$bmi != "na" &
    data_raw$bmi != "nd",
]

genus_columns <- names(data_raw)[
  grepl("(^|[\\.\\|;])g__", names(data_raw)) &
    !grepl("(^|[\\.\\|;])s__", names(data_raw)) &
    !grepl("(^|[\\.\\|;])t__", names(data_raw))
]

genus_mat <- data_raw[, genus_columns, drop = FALSE]
zero_ratio <- colMeans(genus_mat == 0)
genus_columns <- genus_columns[zero_ratio <= 0.9]

extract_phylum <- function(x) {
  if (grepl("p__", x)) {
    sub(".*p__([^\\.\\|;]+).*", "\\1", x)
  } else {
    NA_character_
  }
}

extract_genus <- function(x) {
  if (grepl("g__", x)) {
    sub(".*g__([^\\.\\|;]+).*", "\\1", x)
  } else {
    x
  }
}

genus_phylum <- sapply(genus_columns, extract_phylum)

valid_idx <- !is.na(genus_phylum)
genus_columns <- genus_columns[valid_idx]
genus_phylum <- genus_phylum[valid_idx]

phylum_count <- table(genus_phylum)
valid_phylum <- names(phylum_count[phylum_count >= 2])

genus_columns <- genus_columns[genus_phylum %in% valid_phylum]
genus_phylum <- genus_phylum[genus_phylum %in% valid_phylum]

ord <- order(genus_phylum, genus_columns, na.last = TRUE)

genus_columns_ordered <- genus_columns[ord]
genus_phylum_ordered <- genus_phylum[ord]

feature_info <- data.frame(
  Feature_ID = seq_along(genus_columns_ordered),
  Genus_full = genus_columns_ordered,
  Genus = sapply(genus_columns_ordered, extract_genus),
  Phylum = genus_phylum_ordered,
  stringsAsFactors = FALSE
)

read_top10_one_method <- function(file, target_label, data_type, method_name, feature_info) {
  
  sheet_name <- paste0("beta_", method_name)
  
  beta_raw <- read_excel(file, sheet = sheet_name)
  beta_pos <- read_excel(file, sheet = "beta_pos_prob")
  beta_neg <- read_excel(file, sheet = "beta_neg_prob")
  
  beta_mat <- as.matrix(beta_raw)
  
  p_use <- min(nrow(feature_info), nrow(beta_mat))
  
  beta_mat <- beta_mat[seq_len(p_use), , drop = FALSE]
  feature_sub <- feature_info[seq_len(p_use), , drop = FALSE]
  
  sel_prob <- rowMeans(beta_mat != 0, na.rm = TRUE)
  mean_beta <- rowMeans(beta_mat, na.rm = TRUE)
  mean_abs_beta <- rowMeans(abs(beta_mat), na.rm = TRUE)
  
  pos_prob <- beta_pos[[method_name]][seq_len(p_use)]
  neg_prob <- beta_neg[[method_name]][seq_len(p_use)]
  
  out <- feature_sub %>%
    mutate(
      Data_Type = data_type,
      Target = target_label,
      Method = method_name,
      Method_Label = method_labels[method_name],
      Selection_Probability = sel_prob,
      Mean_Beta = mean_beta,
      Mean_Abs_Beta = mean_abs_beta,
      Pos_Prob = pos_prob,
      Neg_Prob = neg_prob,
      Sign = ifelse(Pos_Prob >= Neg_Prob, "Positive", "Negative")
    ) %>%
    filter(Selection_Probability > 0) %>%
    arrange(desc(Selection_Probability), desc(Mean_Abs_Beta)) %>%
    slice_head(n = 10) %>%
    mutate(Rank = row_number()) %>%
    select(
      Data_Type, Target, Method, Method_Label, Rank,
      Genus, Phylum, Selection_Probability,
      Mean_Beta, Mean_Abs_Beta, Pos_Prob, Neg_Prob, Sign
    )
  
  return(out)
}

build_top10_table <- function(files, data_type) {
  
  map2_dfr(files, target_labels, function(file, target_label) {
    
    map_dfr(methods_to_compare, function(mtd) {
      
      tryCatch(
        read_top10_one_method(
          file = file,
          target_label = target_label,
          data_type = data_type,
          method_name = mtd,
          feature_info = feature_info
        ),
        error = function(e) {
          message("Skipped: ", basename(file), " - ", mtd, "; reason: ", e$message)
          NULL
        }
      )
    })
  })
}

top10_comp <- build_top10_table(files_comp, "Compositional")
top10_age  <- build_top10_table(files_age,  "Compositional + Non-compositional")

top10_long <- bind_rows(top10_comp, top10_age)

top10_table_method_rows <- top10_long %>%
  mutate(
    Method_Label = factor(Method_Label, levels = method_labels[methods_to_compare]),
    
    Taxa_Display = paste0(
      Genus,
      " (", Phylum, ")",
      "; P=", sprintf("%.2f", Selection_Probability),
      "; ", Sign
    ),
    
    Top = paste0("Top", Rank)
  ) %>%
  select(
    Data_Type,
    Target,
    Method_Label,
    Top,
    Taxa_Display
  ) %>%
  pivot_wider(
    names_from = Top,
    values_from = Taxa_Display
  ) %>%
  arrange(
    Data_Type,
    Target,
    Method_Label
  )

top10_table_method_rows_genus_only <- top10_long %>%
  mutate(
    Method_Label = factor(Method_Label, levels = method_labels[methods_to_compare]),
    Taxa_Display = Genus,
    Top = paste0("Top", Rank)
  ) %>%
  select(
    Data_Type,
    Target,
    Method_Label,
    Top,
    Taxa_Display
  ) %>%
  pivot_wider(
    names_from = Top,
    values_from = Taxa_Display
  ) %>%
  arrange(
    Data_Type,
    Target,
    Method_Label
  )

overlap_summary <- top10_long %>%
  group_by(Data_Type, Target) %>%
  group_modify(~{
    
    trans_set <- .x %>%
      filter(Method == "trans_single") %>%
      pull(Genus) %>%
      unique()
    
    .x %>%
      group_by(Method, Method_Label) %>%
      summarise(
        Top10_Genus = paste(unique(Genus), collapse = "; "),
        Overlap_with_Trans_single = sum(unique(Genus) %in% trans_set),
        Overlap_Genus = paste(intersect(unique(Genus), trans_set), collapse = "; "),
        Different_Genus = paste(setdiff(unique(Genus), trans_set), collapse = "; "),
        .groups = "drop"
      )
  }) %>%
  ungroup()

wb <- createWorkbook()

addWorksheet(wb, "Method_rows_full")
writeData(wb, "Method_rows_full", top10_table_method_rows)

addWorksheet(wb, "Method_rows_genus_only")
writeData(wb, "Method_rows_genus_only", top10_table_method_rows_genus_only)

addWorksheet(wb, "Top10_long")
writeData(wb, "Top10_long", top10_long)

addWorksheet(wb, "Overlap_summary")
writeData(wb, "Overlap_summary", overlap_summary)

saveWorkbook(wb, out_file, overwrite = TRUE)

