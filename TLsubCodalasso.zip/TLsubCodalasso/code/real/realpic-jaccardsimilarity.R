# Jaccard similarity and intersection count

library(readxl)
library(dplyr)
library(purrr)
library(openxlsx)
library(stringr)
library(tibble)

result_dir <- "E:/..."

files_info <- tibble(
  Setting_ID = c("set1", "set2", "set3", "set4",
                 "set1", "set2", "set3", "set4"),
  Target = c("UC female", "Normal female", "Normal male", "UC male",
             "UC female", "Normal female", "Normal male", "UC male"),
  Setting = c(rep("Compositional", 4),
              rep("Compositional + non-compositional", 4)),
  File = c(
    file.path(result_dir, "81set1-100-singlesub.xlsx"),
    file.path(result_dir, "81set2-100-singlesub.xlsx"),
    file.path(result_dir, "81set3-100-singlesub.xlsx"),
    file.path(result_dir, "81set4-100-singlesub.xlsx"),
    file.path(result_dir, "81set1-100-singlesub-ncn0105.xlsx"),
    file.path(result_dir, "81set2-100-singlesub-ncn0105.xlsx"),
    file.path(result_dir, "81set3-100-singlesub-ncn0105.xlsx"),
    file.path(result_dir, "81set4-100-singlesub-ncn0105.xlsx")
  )
)

out_file <- file.path(
  result_dir,
  "Jaccard_and_intersection_nonzero_freq_gt_0.5.xlsx"
)

eps <- 1e-8
freq_cutoff <- 0.5

method_sheets_single <- c(
  "SubCoda-Lasso" = "beta_subcoda",
  "Naive Trans-subCodaLasso" = "beta_naive_single",
  "Pooled-subCodaLasso" = "beta_pool_single",
  "Trans-GLM-alr" = "beta_transglm_alr_single",
  "Trans-Lasso-alr" = "beta_translasso_alr_single"
)

ours_single_sheet <- "beta_trans_single"

method_sheets_sub <- c(
  "SubCoda-Lasso" = "beta_subcoda",
  "Naive Trans-subCodaLasso" = "beta_naive_sub",
  "Pooled-subCodaLasso" = "beta_pool_sub",
  "Trans-GLM-alr" = "beta_transglm_alr_sub",
  "Trans-Lasso-alr" = "beta_translasso_alr_sub"
)

ours_sub_sheet <- "beta_trans_sub"

get_selected_features_by_freq <- function(file,
                                          sheet,
                                          eps = 1e-8,
                                          cutoff = 0.5) {
  
  dat <- read_excel(file, sheet = sheet, col_names = TRUE)
  dat <- as.data.frame(dat)
  
  first_col <- dat[[1]]
  first_col_is_name <- !all(suppressWarnings(!is.na(as.numeric(first_col))))
  
  if (first_col_is_name) {
    feature_names <- as.character(first_col)
    beta_dat <- dat[, -1, drop = FALSE]
  } else {
    feature_names <- paste0("V", seq_len(nrow(dat)))
    beta_dat <- dat
  }
  
  beta_mat <- as.matrix(beta_dat)
  suppressWarnings(storage.mode(beta_mat) <- "numeric")
  
  sel_freq <- rowMeans(abs(beta_mat) > eps, na.rm = TRUE)
  
  selected <- feature_names[which(sel_freq > cutoff)]
  
  return(list(
    selected = unique(selected),
    freq_table = tibble(
      Feature = feature_names,
      Selection_Frequency = sel_freq
    )
  ))
}

# Jaccard similarity: |A ∩ B| / |A ∪ B|
jaccard_similarity <- function(A, B) {
  A <- unique(na.omit(A))
  B <- unique(na.omit(B))
  
  if (length(union(A, B)) == 0) return(NA_real_)
  
  length(intersect(A, B)) / length(union(A, B))
}

# |A ∩ B|
intersection_size <- function(A, B) {
  A <- unique(na.omit(A))
  B <- unique(na.omit(B))
  
  length(intersect(A, B))
}

calc_freq_table <- function(files_info,
                            ours_sheet,
                            method_sheets,
                            constraint_label,
                            eps = 1e-8,
                            cutoff = 0.5) {
  
  jaccard_res <- list()
  intersection_res <- list()
  count_res <- list()
  
  for (i in seq_len(nrow(files_info))) {
    
    file_i <- files_info$File[i]
    target_i <- files_info$Target[i]
    setting_i <- files_info$Setting[i]
    
    cat("Reading:", basename(file_i), "\n")
    
    ours_obj <- get_selected_features_by_freq(
      file = file_i,
      sheet = ours_sheet,
      eps = eps,
      cutoff = cutoff
    )
    
    ours_set <- ours_obj$selected
    
    tmp_jac <- tibble(
      Constraint = constraint_label,
      Target = target_i,
      Setting = setting_i,
      Ours_Selected_Number = length(ours_set)
    )
    
    tmp_inter <- tibble(
      Constraint = constraint_label,
      Target = target_i,
      Setting = setting_i,
      Ours_Selected_Number = length(ours_set)
    )
    
    tmp_count <- tibble(
      Constraint = constraint_label,
      Target = target_i,
      Setting = setting_i,
      Method = "Trans-subCodaLasso",
      Selected_Number = length(ours_set)
    )
    
    for (m in names(method_sheets)) {
      
      other_obj <- get_selected_features_by_freq(
        file = file_i,
        sheet = method_sheets[[m]],
        eps = eps,
        cutoff = cutoff
      )
      
      other_set <- other_obj$selected
      
      tmp_jac[[m]] <- round(
        jaccard_similarity(ours_set, other_set),
        3
      )
      
      tmp_inter[[m]] <- intersection_size(
        ours_set,
        other_set
      )
      
      tmp_count <- bind_rows(
        tmp_count,
        tibble(
          Constraint = constraint_label,
          Target = target_i,
          Setting = setting_i,
          Method = m,
          Selected_Number = length(other_set)
        )
      )
    }
    
    jaccard_res[[i]] <- tmp_jac
    intersection_res[[i]] <- tmp_inter
    count_res[[i]] <- tmp_count
  }
  
  list(
    jaccard = bind_rows(jaccard_res),
    intersection = bind_rows(intersection_res),
    selected_count = bind_rows(count_res)
  )
}

res_single <- calc_freq_table(
  files_info = files_info,
  ours_sheet = ours_single_sheet,
  method_sheets = method_sheets_single,
  constraint_label = "Single compositional constraints",
  eps = eps,
  cutoff = freq_cutoff
)

res_sub <- calc_freq_table(
  files_info = files_info,
  ours_sheet = ours_sub_sheet,
  method_sheets = method_sheets_sub,
  constraint_label = "Sub-compositional constraints",
  eps = eps,
  cutoff = freq_cutoff
)

jaccard_single <- res_single$jaccard
jaccard_sub <- res_sub$jaccard

intersection_single <- res_single$intersection
intersection_sub <- res_sub$intersection

count_single <- res_single$selected_count
count_sub <- res_sub$selected_count

target_order <- c("UC female", "Normal female", "Normal male", "UC male")
setting_order <- c("Compositional", "Compositional + non-compositional")

jaccard_single <- jaccard_single %>%
  mutate(
    Target = factor(Target, levels = target_order),
    Setting = factor(Setting, levels = setting_order)
  ) %>%
  arrange(Target, Setting)

jaccard_sub <- jaccard_sub %>%
  mutate(
    Target = factor(Target, levels = target_order),
    Setting = factor(Setting, levels = setting_order)
  ) %>%
  arrange(Target, Setting)

intersection_single <- intersection_single %>%
  mutate(
    Target = factor(Target, levels = target_order),
    Setting = factor(Setting, levels = setting_order)
  ) %>%
  arrange(Target, Setting)

intersection_sub <- intersection_sub %>%
  mutate(
    Target = factor(Target, levels = target_order),
    Setting = factor(Setting, levels = setting_order)
  ) %>%
  arrange(Target, Setting)

count_single <- count_single %>%
  mutate(
    Target = factor(Target, levels = target_order),
    Setting = factor(Setting, levels = setting_order)
  ) %>%
  arrange(Target, Setting, Method)

count_sub <- count_sub %>%
  mutate(
    Target = factor(Target, levels = target_order),
    Setting = factor(Setting, levels = setting_order)
  ) %>%
  arrange(Target, Setting, Method)

wb <- createWorkbook()

addWorksheet(wb, "Jaccard_single_freq_gt_0.5")
writeData(wb, "Jaccard_single_freq_gt_0.5", jaccard_single)

addWorksheet(wb, "Jaccard_sub_freq_gt_0.5")
writeData(wb, "Jaccard_sub_freq_gt_0.5", jaccard_sub)

addWorksheet(wb, "Intersection_single_gt_0.5")
writeData(wb, "Intersection_single_gt_0.5", intersection_single)

addWorksheet(wb, "Intersection_sub_gt_0.5")
writeData(wb, "Intersection_sub_gt_0.5", intersection_sub)

addWorksheet(wb, "Selected_count_single")
writeData(wb, "Selected_count_single", count_single)

addWorksheet(wb, "Selected_count_sub")
writeData(wb, "Selected_count_sub", count_sub)

header_style <- createStyle(
  textDecoration = "bold",
  halign = "center",
  valign = "center",
  border = "Bottom"
)

body_style <- createStyle(
  halign = "center",
  valign = "center"
)

for (sh in names(wb)) {
  
  df <- switch(
    sh,
    "Jaccard_single_freq_gt_0.5" = jaccard_single,
    "Jaccard_sub_freq_gt_0.5" = jaccard_sub,
    "Intersection_single_gt_0.5" = intersection_single,
    "Intersection_sub_gt_0.5" = intersection_sub,
    "Selected_count_single" = count_single,
    "Selected_count_sub" = count_sub
  )
  
  addStyle(
    wb, sh,
    style = header_style,
    rows = 1,
    cols = 1:ncol(df),
    gridExpand = TRUE
  )
  
  addStyle(
    wb, sh,
    style = body_style,
    rows = 2:(nrow(df) + 1),
    cols = 1:ncol(df),
    gridExpand = TRUE
  )
  
  setColWidths(wb, sh, cols = 1:ncol(df), widths = "auto")
  freezePane(wb, sh, firstRow = TRUE)
}

saveWorkbook(wb, out_file, overwrite = TRUE)

cat("Finished!\n")
cat("Selection frequency cutoff =", freq_cutoff, "\n")
cat("Output file:\n", out_file, "\n")



