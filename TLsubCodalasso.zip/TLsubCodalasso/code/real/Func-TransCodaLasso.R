# Trans−subCodalasso

library(MASS) 
library(stats) 
library(magrittr) 

Rcpp::sourceCpp("cclasso1.cpp")

# classo
classo <- function(data, p, lam0 = NULL, maxiter = 5000, 
                   tol = 1e-8, mu = 1, nu = 1.05, seed = 2025,
                   constraint_type = "sub") { 
  set.seed(seed) 
  
  X <- data$X 
  N <- data$N 
  y <- data$y 
  tind <- data$tind 
  p_n <- if (is.null(dim(N))) 0 else ncol(N) 
  
  Z <- cbind(N, X)
  n <- nrow(Z)
  p_total <- ncol(Z)  
  
  
  C <- NULL
  if (constraint_type == "sub") {
    ngrp <- length(tind)-1
    C <- matrix(0, ngrp, p_total)
    for (ii in 1:ngrp) {
      C[ii, (p_n + tind[ii] + 1):(p_n + tind[ii + 1])] <- 1
    }
  } else if (constraint_type == "single") {
    ngrp <- 1
    C <- matrix(0, ngrp, p_total)
    C[, (p_n + 1):p_total] <- 1  
  }
  
  if (p_n == 0) {
    we <- rep(1, p)
  } else {
    we <- c(0, rep(1, p_n - 1), rep(1, p))
  }
  intercept_index <- if (p_n > 0) 1 else NA
  
  Zt <- Z  
  Zt <- crossprod(t(Zt), subtract(diag(1, p_total, p_total), svd(t(C))$u %>% tcrossprod()))
  xmean <- colMeans(Zt)
  if (p_n > 0) {
    xmean[intercept_index] <- 0
  }
  sfac <- apply(Zt, 2, sd)
  sfac[sfac == 0] <- 1 
  if (p_n > 0) {
    sfac[intercept_index] <- 1
  }
  sfac[sfac < 1e-6] <- 1e-6 
  sfac <- drop(1 / sfac) 
  Zt <- t(t(Zt) - xmean) * rep(sfac, each = n) 
  C <- C * rep(sfac, each = nrow(C)) 
  
  y_orig <- y
  if (p_n > 0) {
    mu_y <- mean(y_orig)
    y <- y_orig - mu_y
  } else {
    mu_y <- 0
    y <- y_orig
  }
  
  model_res <- classoshe(Zt, y, C, we, lam0, maxiter, tol, mu, nu) 
  
  tem <- model_res$beta * sfac 
  beta_est <- tem[(p_n + 1):p_total]
  if (p_n > 0) {
    a_est <- tem[1:p_n]
    offset <- sum(tem[-1] * xmean[-1])
    a_est[1] <- mu_y + tem[1] - offset
  } else {
    a_est <- numeric(0)
  }
  
  if (p_n > 0) {
    y_train_pred <- as.vector(N %*% a_est + X %*% beta_est)
  } else {
    y_train_pred <- as.vector(X %*% beta_est)
  }
  resid <- y_orig - y_train_pred
  train_mse <- mean(resid^2)
  
  sigma2_est = mean(resid^2)  
  df_est = sum(abs(beta_est) > 1e-8)
  n_sample = nrow(X) # 样本量
  se_beta = sqrt(sigma2_est / (n_sample - df_est))
  se_a = sqrt(sigma2_est / (n_sample - df_est))   
  se_beta_vec = rep(se_beta, length(beta_est))    
  se_a_vec = rep(se_a, length(a_est))             
  names(se_beta_vec) = colnames(X)             
  names(se_a_vec) = colnames(N)                
  se_full = c(se_a_vec, se_beta_vec)           
  
  return(list(a = a_est, 
              beta = beta_est, 
              beta_full = c(a_est, beta_est), 
              lam0 = lam0,
              sigma2 = sigma2_est,
              df = df_est,
              y_pred = y_train_pred,
              N = N,
              X = X,
              y_orig = y_orig,
              se_a = se_a_vec,        
              se_beta = se_beta_vec, 
              se_full = se_full       
  )) 
}

# cv_classo
cv_classo <- function(data, p, lam0_seq, nfold = 10,
                      maxiter = 5000, tol = 1e-8, mu = 1, nu = 1.05, 
                      seed = 2025, constraint_type = "sub", type = "min") {
  set.seed(seed)
  
  X <- data$X
  N <- data$N      
  y <- data$y
  tind <- data$tind
  n <- length(y)
  p_original <- ncol(X)
  p_n <- if (is.null(dim(N))) 0 else ncol(N)
  if (p_n > 0 && (p_n == 1 || is.vector(N))) {
    N <- as.matrix(N, ncol = 1)
    p_n <- 1
  }
  
  foldid <- sample(rep(1:nfold, length.out = n))
  
  pred <- matrix(NA, nrow = nfold, ncol = length(lam0_seq))
  valid_n <- numeric(nfold) 
  
  for (i in 1:nfold) {
    train_idx <- which(foldid != i)
    valid_idx <- which(foldid == i)
    valid_n[i] <- length(valid_idx) 
    y_train <- y[train_idx]
    X_train <- X[train_idx, , drop = FALSE]
    y_valid <- y[valid_idx]
    X_valid <- X[valid_idx, , drop = FALSE]
    N_train <- N[train_idx, , drop = FALSE]
    N_valid <- N[valid_idx, , drop = FALSE]
    
    data_train_fold <- list(
      X = X_train,
      N = N_train,      
      y = y_train,
      tind = tind
    )
    
    for (j in seq_along(lam0_seq)) {
      lam0_j <- lam0_seq[j]
      fit_j <- classo(
        data = data_train_fold,
        p = p,
        lam0 = lam0_j,
        maxiter = maxiter,
        tol = tol,
        mu = mu,
        nu = nu,
        seed = seed + i + j, 
        constraint_type = constraint_type
      )
      
      if (p_n > 0) {
        y_valid_pred <- as.vector(
          N_valid %*% fit_j$a +
            X_valid %*% fit_j$beta
        )
      } else {
        y_valid_pred <- as.vector(X_valid %*% fit_j$beta)
      }
      valid_sse <- sum((y_valid - y_valid_pred)^2) 
      pred[i, j] <- valid_sse
    }
    
    
  }
  
  pred_mse <- t(t(pred) / valid_n)
  weights <- valid_n / sum(valid_n)
  cvm <- colSums(pred_mse * weights, na.rm = TRUE) 
  cvse <- apply(pred_mse, 2, function(col) {
    valid_vals <- col[!is.na(col)]
    if (length(valid_vals) < 2) return(NA)
    sd(valid_vals) / sqrt(length(valid_vals))
  })
  
  imin <- which.min(cvm)
  if (type == "1se") {
    ilam <- which(cvm <= cvm[imin] + cvse[imin])[1]
  } else {
    ilam <- imin
  }
  lam_best <- lam0_seq[ilam]
  
  data_full <- list(
    X = X,         
    N = N,         
    y = y,        
    tind = tind    
  )
  
  fit_best <- classo(
    data = data_full,
    p = p,
    lam0 = lam_best,
    maxiter = maxiter,
    tol = tol,
    mu = mu,
    nu = nu,
    seed = seed,
    constraint_type = constraint_type
  )
  
  return(list(
    a = fit_best$a,               
    beta = fit_best$beta,        
    lam0_best = lam_best,        
    lam0_seq = lam0_seq,       
    cvm = cvm,                  
    cvse = cvse,                  
    foldid = foldid,             
    fit_best = fit_best,          
    se_a = fit_best$se_a,        
    se_beta = fit_best$se_beta   
  ))
}

# Oracle.subCodalasso
Oracle.subCodalasso <- function(X, N, y, tind, A0, n.vec, nfold = 10, 
                                maxiter=5000, tol=1e-8, mu=1, nu=1.05, seed=2025,
                                constraint_type = "sub", lam0_seq) {  
  p<-ncol(X)  
  p_n <- if (is.null(dim(N))) 0 else ncol(N)
  if (length(A0) == 2 && all(A0 == c(1, 0))) {  
    A0 <- integer(0)  
  }  
  size.A0<- length(A0) 
  a.KA <- numeric(p_n)   
  a.udb <- numeric(p_n)   
  
  if(size.A0 > 0){ 
    k.vec <- c(1, A0+1)  
    ind.kA <- NULL       
    for(k in k.vec){ 
      if(k==1){ 
        ind.kA <- c(ind.kA, 1:n.vec[1])  
      }else{ 
        ind.kA <- c(ind.kA, (sum(n.vec[1:(k-1)])+1):sum(n.vec[1:k]))
      }
    }
    ind.1<-1:n.vec[1]
    data.kA <- list(
      X = X[ind.kA, , drop = FALSE],    
      N = N[ind.kA, , drop = FALSE],   
      y = y[ind.kA],     
      tind = tind
    )
    
    w <- cv_classo(
      data = data.kA,
      p = p,
      lam0_seq = lam0_seq,
      nfold = nfold,
      maxiter = maxiter,
      tol = tol,
      mu = mu,
      nu = nu,
      seed = seed,
      constraint_type = constraint_type,
      type = "1se"
    )
    a.udb <- as.numeric(w$a) 
    w.kA <- as.numeric(w$beta) 
    se_w_kA <- w$se_beta        
    se_w_a <- w$se_a            
    
    if (p_n > 0) {
      y_pred_w <- as.vector(
        N[ind.1, , drop = FALSE] %*% a.udb +
          X[ind.1, , drop = FALSE] %*% w.kA
      )
    } else {
      y_pred_w <- as.vector(X[ind.1, , drop = FALSE] %*% w.kA)
    }
    res <- as.numeric(y[ind.1] - y_pred_w)  
    
    data.delta <- list(
      X = X[ind.1, , drop = FALSE],    
      N = N[ind.1, , drop = FALSE],   
      y = res,                       
      tind = tind
    )
    
    delta <- cv_classo(
      data = data.delta,
      p = p,
      lam0_seq = lam0_seq,
      nfold = nfold,
      maxiter = maxiter,
      tol = tol,
      mu = mu,
      nu = nu,
      seed = seed,
      constraint_type = constraint_type
    )
    a.delta <- as.numeric(delta$a)      
    delta.kA <- as.numeric(delta$beta)  
    se_delta_kA <- delta$se_beta        
    se_delta_a <- delta$se_a            
    
    beta.kA <- w.kA + delta.kA   
    a.KA <- a.udb + a.delta      
    se_beta_kA <- sqrt(se_w_kA^2 + se_delta_kA^2)
    se_a_KA <- sqrt(se_w_a^2 + se_delta_a^2)
    names(se_beta_kA) = colnames(X)
    if (p_n > 0) names(se_a_KA) <- colnames(N)
    
  }else{ 
    ind.1 <- 1:n.vec[1]  
    data.kA <- list(
      X = X[ind.1, , drop = FALSE],
      N = N[ind.1, , drop = FALSE],
      y = y[ind.1],
      tind = tind
    )
    w <- cv_classo(
      data = data.kA,
      p = p,
      lam0_seq = lam0_seq,
      nfold = nfold,
      maxiter = maxiter,
      tol = tol,
      mu = mu,
      nu = nu,
      seed = seed,
      constraint_type = constraint_type
    )
    
    beta.kA <- as.numeric(w$beta)
    a.KA    <- as.numeric(w$a)
    se_beta_kA <- w$se_beta
    se_a_KA    <- w$se_a
    w.kA    <- beta.kA
    a.udb   <- a.KA
    se_w_kA <- se_beta_kA
    se_w_a  <- se_a_KA
    names(se_beta_kA) <- colnames(X)
    if (p_n > 0 && !is.null(colnames(N))) {
      names(se_a_KA) <- colnames(N)
    }
  }
  
  return(list(beta = as.numeric(beta.kA), 
              a = a.KA,
              beta.udb = w.kA, 
              a.udb = a.udb, 
              se_beta = se_beta_kA,       
              se_a = se_a_KA,          
              se_beta_udb = se_w_kA,   
              se_a_udb = se_w_a          
              
  ))            
}

# Trans.Codalasso.sub
Trans.Codalasso.sub <- function(Xtrain, Ntrain, ytrain, tind, n, M, epsilon = 0.01, 
                                lam0_seq, nfold = 10, maxiter = 5000, tol = 1e-8, 
                                mu = 1, nu = 1.05, seed = 2025, constraint_type = "sub") {
  set.seed(seed)
  
  if (is.null(Ntrain) || length(Ntrain) == 0) {
    p_n <- 0
    Ntrain <- matrix(numeric(0), nrow = nrow(Xtrain), ncol = 0)
  } else if (is.vector(Ntrain)) {
    Ntrain <- matrix(Ntrain, ncol = 1)
    p_n <- 1
  } else {
    Ntrain <- as.matrix(Ntrain)
    p_n <- ncol(Ntrain)
  }
  
  x.target <- Xtrain[1:n[1], , drop = FALSE]
  x.source <- Xtrain[(n[1] + 1):sum(n), , drop = FALSE]
  y.target <- ytrain[1:n[1]]
  y.source <- ytrain[(n[1] + 1):sum(n)]
  n.target <- n[1]
  N.target <- Ntrain[1:n[1], , drop = FALSE]
  N.source <- Ntrain[(n[1] + 1):sum(n), , drop = FALSE]
  
  xsourcelist <- list() 
  ysourcelist <- list()
  Nsourcelist <- list()
  start_row <- 1  
  for (k in 1:M) { 
    end_row <- start_row + n[k+1] - 1  
    xsourcelist[[k]] <- x.source[start_row:end_row, , drop = FALSE]
    ysourcelist[[k]] <- y.source[start_row:end_row]
    Nsourcelist[[k]] <- N.source[start_row:end_row, , drop = FALSE]
    start_row <- end_row + 1  
  }
  
  if (n.target %% 2 == 0) {
    split_idx <- n.target / 2
  } else {
    split_idx <- floor(n.target / 2)
  }
  X_train <- x.target[1:split_idx, , drop = FALSE]
  y_train <- y.target[1:split_idx]
  N_train <- N.target[1:split_idx, , drop = FALSE]
  X_test <- x.target[(split_idx + 1):n.target, , drop = FALSE]
  y_test <- y.target[(split_idx + 1):n.target]
  N_test <- N.target[(split_idx + 1):n.target, , drop = FALSE]
  
  beta_hat_list <- list()
  Q_list <- list()
  data_init <- list(
    X = X_train,
    N = N_train,
    y = y_train,
    tind = tind
  )
  cv_init <- cv_classo(data = data_init, p = ncol(X_train), lam0_seq = lam0_seq, 
                       nfold = nfold, maxiter = maxiter, tol = tol, mu = mu, nu = nu,
                       seed = seed, constraint_type = constraint_type)
  beta_0_hat <- cv_init$beta
  a_0_hat <- cv_init$a
  int_0 <- if (p_n > 0) a_0_hat[1] else NA
  if (p_n > 0) {
    y_test_pred <- as.vector(N_test %*% a_0_hat + X_test %*% beta_0_hat)
  } else {
    y_test_pred <- as.vector(X_test %*% beta_0_hat)
  }
  Q_list[["Q0"]] <- mean((y_test - y_test_pred)^2)
  
  for (k in 1:M) {
    x_comb <- rbind(X_train, xsourcelist[[k]])
    y_comb <- c(y_train, ysourcelist[[k]])
    if (p_n > 0) {
      N_comb <- rbind(N_train, Nsourcelist[[k]])
    } else {
      N_comb <- matrix(numeric(0), nrow = nrow(x_comb), ncol = 0)
    }
    data_comb <- list(
      X = x_comb,
      N = N_comb,
      y = y_comb,
      tind = tind
    )
    cv_comb <- cv_classo(data = data_comb, p = ncol(x_comb), lam0_seq = lam0_seq,
                         nfold = nfold, maxiter = maxiter, tol = tol, mu = mu, nu = nu,
                         seed = seed + k, constraint_type = constraint_type)
    beta_hat_list[[paste0("beta_", k, "_hat")]] <- as.vector(cv_comb$beta)
    a_hat_k <- cv_comb$a
    if (p_n > 0) {
      y_test_pred_k <- as.vector(
        N_test %*% a_hat_k + X_test %*% beta_hat_list[[paste0("beta_", k, "_hat")]]
      )
    } else {
      y_test_pred_k <- as.vector(
        X_test %*% beta_hat_list[[paste0("beta_", k, "_hat")]]
      )
    }
    Q_list[[paste0("Q", k)]] <- mean((y_test - y_test_pred_k)^2)
  }
  
  indexQR <- c()
  for (k in 1:M) {
    if (Q_list[[paste0("Q", k)]] <= (1 + epsilon) * Q_list[["Q0"]]) {
      indexQR <- c(indexQR, k)
    }
  }
  effective_source_count <- length(indexQR)
  
  if (length(indexQR) != 0) {
    x_source1 <- xsourcelist[indexQR]  
    y_source1 <- ysourcelist[indexQR]  
    N_source1 <- Nsourcelist[indexQR]
    x_combined <- rbind(x.target, do.call(rbind, x_source1))
    y_combined <- c(y.target, unlist(y_source1))
    if (p_n > 0) {
      N_combined <- rbind(N.target, do.call(rbind, N_source1))
    } else {
      N_combined <- matrix(numeric(0), nrow = nrow(x_combined), ncol = 0)
    }
    n_selected <- c(n[1], n[indexQR + 1])  
    
    kA <- Oracle.subCodalasso(
      X = x_combined, 
      N = N_combined,
      y = y_combined, 
      tind = tind,
      A0 = 1:length(indexQR), 
      n.vec = n_selected,
      nfold = nfold,
      maxiter = maxiter,
      tol = tol,
      mu = mu,
      nu = nu,
      seed = seed,
      constraint_type = constraint_type,
      lam0_seq = lam0_seq
    )
    
    beta_hat <- kA$beta
    a_hat <- kA$a
    int <- if (p_n > 0) a_hat[1] else NA
    w.kA <- kA$beta.udb
    se_beta <- kA$se_beta
    se_a <- kA$se_a
    
  } else {
    data_target <- list(
      X = x.target,
      N = N.target,
      y = y.target,
      tind = tind
    )
    
    cv_target <- cv_classo(data = data_target, p = ncol(x.target), lam0_seq = lam0_seq,
                           nfold = nfold, maxiter = maxiter, tol = tol, mu = mu, nu = nu,
                           seed = seed, constraint_type = constraint_type)
    
    beta_hat <- cv_target$beta
    a_hat <- cv_target$a
    int <- if (p_n > 0) a_hat[1] else NA
    w.kA <- NA
    se_beta <- cv_target$se_beta
    se_a <- cv_target$se_a
  }
  
  return(list(
    beta_hat = as.numeric(beta_hat), 
    a_hat = as.numeric(a_hat), 
    int = int, 
    w.kA = w.kA,
    se_beta = se_beta,
    se_a = se_a,
    selected_sources = indexQR 
  ))
}

# Naive.subCodalasso
Naive.subCodalasso <- function(X, N, y, tind, n.vec, nfold = 10, 
                               maxiter=5000, tol=1e-8, mu=1, nu=1.05, seed=2025,
                               constraint_type = "sub", lam0_seq) {  
  p <- ncol(X) 
  if (is.null(N) || length(N) == 0) {
    p_n <- 0
    N <- matrix(numeric(0), nrow = nrow(X), ncol = 0)
  } else if (is.vector(N)) {
    N <- matrix(N, ncol = 1)
    p_n <- 1
  } else {
    N <- as.matrix(N)
    p_n <- ncol(N)
  }
  a.KA <- numeric(p_n)   
  a.udb <- numeric(p_n)   
  beta.kA <- numeric(p)  
  w.kA <- numeric(p)     
  
  ind.1 <- 1:n.vec[1]
  ind.kA <- 1:sum(n.vec)
  
  data.kA <- list(
    X = X[ind.kA, , drop = FALSE],   
    N = N[ind.kA, , drop = FALSE],    
    y = y[ind.kA],      
    tind = tind
  )
  w <- cv_classo(
    data = data.kA,
    p = p,
    lam0_seq = lam0_seq,
    nfold = nfold,
    maxiter = maxiter,
    tol = tol,
    mu = mu,
    nu = nu,
    seed = seed,
    constraint_type = constraint_type,
    type = "1se"
  )
  a.udb <- as.numeric(w$a)     
  w.kA <- as.numeric(w$beta)    
  se_w_kA <- w$se_beta        
  se_w_a <- w$se_a            
  
  if (p_n > 0) {
    y_pred_w <- as.vector(
      N[ind.1, , drop = FALSE] %*% a.udb +
        X[ind.1, , drop = FALSE] %*% w.kA
    )
  } else {
    y_pred_w <- as.vector(
      X[ind.1, , drop = FALSE] %*% w.kA
    )
  }
  res <- as.numeric(y[ind.1] - y_pred_w)
  data.delta <- list(
    X = X[ind.1, , drop = FALSE],    
    N = N[ind.1, , drop = FALSE],    
    y = res,                         
    tind = tind
  )
  delta <- cv_classo(
    data = data.delta,
    p = p,
    lam0_seq = lam0_seq,
    nfold = nfold,
    maxiter = maxiter,
    tol = tol,
    mu = mu,
    nu = nu,
    seed = seed + 100, 
    constraint_type = constraint_type
  )
  a.delta <- as.numeric(delta$a)      
  delta.kA <- as.numeric(delta$beta) 
  se_delta_kA <- delta$se_beta      
  se_delta_a <- delta$se_a          
  
  beta.kA <- w.kA + delta.kA    
  a.KA <- a.udb + a.delta       
  
  se_beta_kA <- sqrt(se_w_kA^2 + se_delta_kA^2)
  se_a_KA <- sqrt(se_w_a^2 + se_delta_a^2)
  names(se_beta_kA) <- colnames(X)
  if (p_n > 0 && !is.null(colnames(N))) {
    names(se_a_KA) <- colnames(N)
  }
  
  return(list(
    beta = as.numeric(beta.kA),     
    a = a.KA,                       
    beta.udb = w.kA,                
    a.udb = a.udb,                  
    se_beta = se_beta_kA,          
    se_a = se_a_KA,                
    se_beta_udb = se_w_kA,         
    se_a_udb = se_w_a              
  ))            
}






