# Real data relative PE 

library(ggplot2)
library(cowplot)
library(patchwork)
library(dplyr)
library(readxl)
library(grid)

result_dir <- "E:/..."

out_dir <- file.path(result_dir, "realdata_PE_4panel")

if (!dir.exists(out_dir)) {
  dir.create(out_dir, recursive = TRUE)
}

file_info <- data.frame(
  Target = rep(
    c("UC(female)", "Normal(female)", "Normal(male)", "UC(male)"),
    2
  ),
  AgeType = c(
    rep("+ age", 4),
    rep("without age", 4)
  ),
  File = c(
    file.path(result_dir, "81set1-100-singlesub-ncn0105.xlsx"),
    file.path(result_dir, "81set2-100-singlesub-ncn0105.xlsx"),
    file.path(result_dir, "81set3-100-singlesub-ncn0105.xlsx"),
    file.path(result_dir, "81set4-100-singlesub-ncn0105.xlsx"),
    
    file.path(result_dir, "81set1-100-singlesub.xlsx"),
    file.path(result_dir, "81set2-100-singlesub.xlsx"),
    file.path(result_dir, "81set3-100-singlesub.xlsx"),
    file.path(result_dir, "81set4-100-singlesub.xlsx")
  ),
  stringsAsFactors = FALSE
)


method_order <- c(
  "Naive Trans-subCodalasso",
  "Pooled-subCodalasso",
  "Trans-subCodalasso",
  "Trans-Lasso-alr",
  "Trans-GLM-alr"
)

disease_order <- c(
  "UC(female)",
  "Normal(female)",
  "Normal(male)",
  "UC(male)"
)

target_methods_3 <- c(
  "Naive Trans-subCodalasso",
  "Pooled-subCodalasso",
  "Trans-subCodalasso"
)

target_methods_2 <- c(
  "Naive Trans-subCodalasso",
  "Trans-subCodalasso"
)

method_colors <- c(
  "Naive Trans-subCodalasso" = "#FFBC79",
  "Pooled-subCodalasso"      = "#F17A3E",
  "Trans-subCodalasso"       = "#B87333",
  "Trans-Lasso-alr"          = "#B7E4B3",
  "Trans-GLM-alr"            = "#7CCB7C"
)


read_pe_mean <- function(file) {
  
  if (!file.exists(file)) {
    stop("File does not exist: ", file)
  }
  
  pe_df <- readxl::read_excel(file, sheet = "PE_mean")
  
  colnames(pe_df)[1:2] <- c("Method_raw", "PE")
  
  pe_df <- pe_df %>%
    mutate(
      Method_raw = as.character(Method_raw),
      PE = as.numeric(PE)
    )
  
  return(pe_df)
}

extract_one_file <- function(file, target, age_type) {
  
  pe_df <- read_pe_mean(file)
  
  get_pe <- function(method_name) {
    val <- pe_df$PE[pe_df$Method_raw == method_name]
    if (length(val) == 0) {
      stop("Method not found in the file: ", method_name, "\nFile: ", file)
    }
    return(val[1])
  }
  
  coda_pe    <- get_pe("coda")
  subcoda_pe <- get_pe("subcoda")
  
  comp_df <- data.frame(
    Disease = target,
    AgeType = age_type,
    Constraint = "Composition",
    Method = method_order,
    Value = c(
      get_pe("naive_single") / coda_pe,
      get_pe("pool_single") / coda_pe,
      get_pe("trans_single") / coda_pe,
      get_pe("translasso_alr_single") / coda_pe,
      get_pe("transglm_alr_single") / coda_pe
    ),
    stringsAsFactors = FALSE
  )
  
  sub_df <- data.frame(
    Disease = target,
    AgeType = age_type,
    Constraint = "Subcomposition",
    Method = method_order,
    Value = c(
      get_pe("naive_sub") / subcoda_pe,
      get_pe("pool_sub") / subcoda_pe,
      get_pe("trans_sub") / subcoda_pe,
      get_pe("translasso_alr_sub") / subcoda_pe,
      get_pe("transglm_alr_sub") / subcoda_pe
    ),
    stringsAsFactors = FALSE
  )
  
  return(rbind(comp_df, sub_df))
}

df_all <- bind_rows(
  lapply(seq_len(nrow(file_info)), function(i) {
    extract_one_file(
      file = file_info$File[i],
      target = file_info$Target[i],
      age_type = file_info$AgeType[i]
    )
  })
)

df_all <- df_all %>%
  mutate(
    Disease = factor(Disease, levels = disease_order),
    Method = factor(Method, levels = method_order),
    Constraint = factor(
      Constraint,
      levels = c("Subcomposition", "Composition")
    ),
    AgeType = factor(
      AgeType,
      levels = c("+ age", "without age")
    )
  )

print(df_all)

make_inset <- function(dat, title_text = NULL) {
  
  y_min <- min(dat$Value, na.rm = TRUE)
  y_max <- max(dat$Value, na.rm = TRUE)
  pad <- max((y_max - y_min) * 0.25, 0.03)
  
  ggplot(dat, aes(x = Method, y = Value, fill = Method)) +
    geom_col(width = 0.7, show.legend = FALSE) +
    scale_fill_manual(values = method_colors) +
    coord_cartesian(ylim = c(y_min - pad, y_max + pad)) +
    theme_minimal(base_size = 8) +
    labs(title = title_text, x = NULL, y = NULL) +
    theme(
      plot.title = element_text(size = 6.2, hjust = 0.42, lineheight = 0.8),
      axis.text.x = element_blank(),
      axis.ticks.x = element_blank(),
      axis.text.y = element_text(size = 5.2),
      panel.grid.minor = element_blank(),
      panel.grid.major.x = element_blank(),
      plot.background = element_rect(
        color = "grey50",
        fill = "white",
        linewidth = 0.4
      ),
      plot.margin = margin(1, 1, 1, 1)
    )
}

make_legend_plot <- function(dat) {
  
  dat <- dat %>%
    mutate(
      Disease = factor(Disease, levels = disease_order),
      Method = factor(Method, levels = method_order)
    )
  
  ggplot(dat, aes(x = Disease, y = Value, fill = Method)) +
    geom_col(
      position = position_dodge(width = 0.8),
      width = 0.75
    ) +
    scale_fill_manual(
      values = method_colors,
      name = "Method"
    ) +
    theme_minimal(base_size = 10) +
    theme(
      legend.position = "bottom",
      legend.title = element_text(size = 8, face = "bold"),
      legend.text = element_text(size = 7),
      legend.key.width = unit(0.45, "cm"),
      legend.key.height = unit(0.28, "cm"),
      legend.spacing.x = unit(0.15, "cm"),
      legend.box = "horizontal",
      legend.justification = "center"
    )
}

make_one_panel <- function(dat,
                           panel_title,
                           show_x = TRUE,
                           show_y = TRUE,
                           show_legend = FALSE) {
  
  dat <- dat %>%
    mutate(
      Disease = factor(Disease, levels = disease_order),
      Method = factor(Method, levels = method_order)
    )
  
  p_main <- ggplot(dat, aes(x = Disease, y = Value, fill = Method)) +
    geom_col(
      position = position_dodge(width = 0.8),
      width = 0.75
    ) +
    geom_hline(
      yintercept = 1,
      color = "black",
      linewidth = 0.4
    ) +
    scale_fill_manual(
      values = method_colors,
      name = "Method"
    ) +
    theme_minimal(base_size = 10) +
    labs(
      y = if (show_y) "Relative Prediction Error" else NULL,
      x = NULL
    ) +
    theme(
      axis.text.x = if (show_x) {
        element_text(angle = 30, hjust = 1, size = 7.5)
      } else {
        element_blank()
      },
      axis.ticks.x = if (show_x) {
        element_line()
      } else {
        element_blank()
      },
      
      axis.text.y = if (show_y) {
        element_text(size = 7.5)
      } else {
        element_blank()
      },
      axis.ticks.y = if (show_y) {
        element_line()
      } else {
        element_blank()
      },
      axis.title.y = if (show_y) {
        element_text(size = 8.5)
      } else {
        element_blank()
      },
      
      legend.position = if (show_legend) "bottom" else "none",
      legend.title = element_text(size = 7.5, face = "bold"),
      legend.text = element_text(size = 5.8),
      legend.key.width = unit(0.35, "cm"),
      legend.key.height = unit(0.25, "cm"),
      legend.spacing.x = unit(0.1, "cm"),
      legend.box.spacing = unit(0.1, "cm"),
      legend.box = "horizontal",
      legend.justification = "center",
      
      plot.margin = margin(t = 52, r = 8, b = 5, l = 5)
    )
  
  df_small3 <- dat %>% filter(Method %in% target_methods_3)
  
  inset_list_3 <- lapply(disease_order, function(d) {
    tmp <- df_small3 %>% filter(Disease == d)
    make_inset(tmp, d)
  })
  names(inset_list_3) <- disease_order
  
  df_small2 <- dat %>% filter(Method %in% target_methods_2)
  
  inset_list_2 <- lapply(disease_order, function(d) {
    tmp <- df_small2 %>% filter(Disease == d)
    make_inset(tmp, d)
  })
  names(inset_list_2) <- disease_order
  
  p_body <- ggdraw(p_main) +
    draw_plot(inset_list_3[[1]], x = 0.045, y = 0.765, width = 0.105, height = 0.20) +
    draw_plot(inset_list_3[[2]], x = 0.275, y = 0.765, width = 0.105, height = 0.20) +
    draw_plot(inset_list_3[[3]], x = 0.505, y = 0.765, width = 0.105, height = 0.20) +
    draw_plot(inset_list_3[[4]], x = 0.725, y = 0.765, width = 0.105, height = 0.20) +
    
    draw_plot(inset_list_2[[1]], x = 0.155, y = 0.765, width = 0.075, height = 0.20) +
    draw_plot(inset_list_2[[2]], x = 0.385, y = 0.765, width = 0.075, height = 0.20) +
    draw_plot(inset_list_2[[3]], x = 0.615, y = 0.765, width = 0.075, height = 0.20) +
    draw_plot(inset_list_2[[4]], x = 0.835, y = 0.765, width = 0.075, height = 0.20)
  
  p_strip <- ggdraw() +
    draw_label(
      panel_title,
      x = 0.5,
      y = 0.5,
      fontface = "bold",
      size = 11
    ) +
    theme_void() +
    theme(
      plot.background = element_rect(
        fill = "grey90",
        color = "grey40",
        linewidth = 0.8
      ),
      plot.margin = margin(0, 0, 0, 0)
    )
  
  p_panel <- plot_grid(
    p_strip,
    p_body,
    ncol = 1,
    rel_heights = c(0.08, 1)
  )
  
  return(p_panel)
}

df_sub_age <- df_all %>%
  filter(Constraint == "Subcomposition", AgeType == "+ age")

df_sub <- df_all %>%
  filter(Constraint == "Subcomposition", AgeType == "without age")

df_comp_age <- df_all %>%
  filter(Constraint == "Composition", AgeType == "+ age")

df_comp <- df_all %>%
  filter(Constraint == "Composition", AgeType == "without age")

p_sub_age <- make_one_panel(
  df_sub_age,
  "Subcomposition + age",
  show_x = FALSE,
  show_y = TRUE,
  show_legend = FALSE
)

p_sub <- make_one_panel(
  df_sub,
  "Subcomposition",
  show_x = FALSE,
  show_y = FALSE,
  show_legend = FALSE
)

p_comp_age <- make_one_panel(
  df_comp_age,
  "Composition + age",
  show_x = TRUE,
  show_y = TRUE,
  show_legend = FALSE
)

p_comp <- make_one_panel(
  df_comp,
  "Composition",
  show_x = TRUE,
  show_y = FALSE,
  show_legend = FALSE
)

legend_plot <- make_legend_plot(df_comp_age)
shared_legend <- cowplot::get_legend(legend_plot)

p_body_4panel <- plot_grid(
  p_sub_age,
  p_sub,
  p_comp_age,
  p_comp,
  ncol = 2,
  align = "hv",
  labels = NULL
)

p_final_4panel <- plot_grid(
  p_body_4panel,
  shared_legend,
  ncol = 1,
  rel_heights = c(1, 0.055)
)

print(p_final_4panel)

ggsave(
  filename = file.path(out_dir, "Fig_realdata_relative_PE_4panel_with_insets_shared_axis_legend.png"),
  plot = p_final_4panel,
  width = 14,
  height = 9,
  dpi = 400
)

ggsave(
  filename = file.path(out_dir, "Fig_realdata_relative_PE_4panel_with_insets_shared_axis_legend.pdf"),
  plot = p_final_4panel,
  width = 14,
  height = 9
)

write.csv(
  df_all,
  file = file.path(out_dir, "Fig_realdata_relative_PE_4panel_data.csv"),
  row.names = FALSE
)

cat("\nFinished.\n")
cat("Figure and data saved to:", out_dir, "\n")