# Source-selection

library(ggplot2)
library(readxl)
library(dplyr)
library(tidyr)

result_dir <- "E:/..."

files_comp <- list(
  "set1" = file.path(result_dir, "81set1-100-singlesub.xlsx"),
  "set2" = file.path(result_dir, "81set2-100-singlesub.xlsx"),
  "set3" = file.path(result_dir, "81set3-100-singlesub.xlsx"),
  "set4" = file.path(result_dir, "81set4-100-singlesub.xlsx")
)

files_age <- list(
  "set1" = file.path(result_dir, "81set1-100-singlesub-ncn0105.xlsx"),
  "set2" = file.path(result_dir, "81set2-100-singlesub-ncn0105.xlsx"),
  "set3" = file.path(result_dir, "81set3-100-singlesub-ncn0105.xlsx"),
  "set4" = file.path(result_dir, "81set4-100-singlesub-ncn0105.xlsx")
)

# single
selection_sheet <- "selection_trans_single"
# sub
#selection_sheet <- "selection_trans_sub"

single_cols <- c("S1", "S2", "S3", "S4")

combo_cols <- c(
  "S1", "S2", "S3", "S4",
  "S12", "S13", "S14", "S23", "S24", "S34",
  "S123", "S124", "S134", "S234"
)

source_names <- c(
  "S1" = "UCf",
  "S2" = "Nf",
  "S3" = "Nm",
  "S4" = "UCm",
  
  "S12" = "UCf+Nf",
  "S13" = "UCf+Nm",
  "S14" = "UCf+UCm",
  "S23" = "Nf+Nm",
  "S24" = "Nf+UCm",
  "S34" = "Nm+UCm",
  
  "S123" = "UCf+Nf+Nm",
  "S124" = "UCf+Nf+UCm",
  "S134" = "UCf+Nm+UCm",
  "S234" = "Nf+Nm+UCm"
)

target_names <- c(
  "set1" = "Target: UC female",
  "set2" = "Target: Normal female",
  "set3" = "Target: Normal male",
  "set4" = "Target: UC male"
)

get_source_selection_plot_data <- function(files, data_type) {
  
  out_list <- lapply(names(files), function(set_name) {
    
    df <- read_excel(files[[set_name]], sheet = selection_sheet)
    
    df_single <- df
    
    for (i in seq_len(nrow(df_single))) {
      
      target_col <- as.character(df_single$Target[i])
      
      if (target_col %in% single_cols) {
        
        selected_aux <- single_cols[
          as.numeric(df_single[i, single_cols]) == 1
        ]
        
        selected_aux <- setdiff(selected_aux, target_col)
        
        df_single[i, target_col] <- 0
        
        if (length(selected_aux) == 0) {
          df_single[i, target_col] <- 1
        }
      }
    }
    
    marginal_df <- df_single %>%
      summarise(across(all_of(single_cols), ~ mean(.x == 1, na.rm = TRUE))) %>%
      pivot_longer(
        cols = everything(),
        names_to = "Source",
        values_to = "Selection_Probability"
      ) %>%
      mutate(
        Data_Type = data_type,
        Plot_Type = "Single-source probability",
        Target_Label = target_names[set_name],
        Source_Label = source_names[Source]
      )
    
    exact_set <- apply(df, 1, function(row_i) {
      
      target_i <- as.character(row_i["Target"])
      
      selected_single <- single_cols[
        as.numeric(row_i[single_cols]) == 1
      ]
      
      selected_single <- setdiff(selected_single, target_i)
      
      if (length(selected_single) == 0) {
        return(target_i)
      }
      
      selected_digits <- gsub("S", "", selected_single)
      selected_digits <- sort(selected_digits)
      paste0("S", paste(selected_digits, collapse = ""))
    })
    
    exact_df <- data.frame(
      Exact_Source_Set = exact_set,
      stringsAsFactors = FALSE
    ) %>%
      count(Exact_Source_Set, name = "n") %>%
      mutate(
        Selection_Probability = n / nrow(df),
        Source = Exact_Source_Set
      ) %>%
      select(Source, Selection_Probability)
    
    exact_df <- data.frame(Source = combo_cols) %>%
      left_join(exact_df, by = "Source") %>%
      mutate(
        Selection_Probability = ifelse(is.na(Selection_Probability), 0, Selection_Probability),
        Data_Type = data_type,
        Plot_Type = "Exact selected source set",
        Target_Label = target_names[set_name],
        Source_Label = source_names[Source]
      )
    
    bind_rows(marginal_df, exact_df)
  })
  
  bind_rows(out_list)
}

plot_df <- bind_rows(
  get_source_selection_plot_data(files_comp, "Composition only"),
  get_source_selection_plot_data(files_age,  "Composition + age")
)

plot_df <- plot_df %>%
  mutate(
    Col_Label = case_when(
      Data_Type == "Composition only" & Plot_Type == "Single-source probability" ~
        "Marginal single-source selection frequency\n(Compositional)",
      Data_Type == "Composition only" & Plot_Type == "Exact selected source set" ~
        "Exact source-set selection frequency\n(Compositional)",
      Data_Type == "Composition + age" & Plot_Type == "Single-source probability" ~
        "Marginal single-source selection frequency\n(Compositional + Non-compositional)",
      Data_Type == "Composition + age" & Plot_Type == "Exact selected source set" ~
        "Exact source-set selection frequency\n(Compositional + Non-compositional)"
    ),
    Row_Label = Target_Label
  )

plot_df$Row_Label <- factor(
  plot_df$Row_Label,
  levels = c(
    "Target: UC female",
    "Target: Normal female",
    "Target: Normal male",
    "Target: UC male"
  )
)

plot_df$Col_Label <- factor(
  plot_df$Col_Label,
  levels = c(
    "Marginal single-source selection frequency\n(Compositional)",
    "Exact source-set selection frequency\n(Compositional)",
    "Marginal single-source selection frequency\n(Compositional + Non-compositional)",
    "Exact source-set selection frequency\n(Compositional + Non-compositional)"
  )
)

plot_df <- plot_df %>%
  filter(
    Plot_Type == "Exact selected source set" |
      (Plot_Type == "Single-source probability" & Source %in% single_cols)
  )

# Nf, Nm, UCf, UCm
single_order <- c("S2", "S3", "S1", "S4")

exact_order <- c(
  "S2", "S3", "S1", "S4",
  "S23", "S12", "S24",
  "S13", "S34", "S14",
  "S123", "S234",
  "S124", "S134"
)

plot_df <- plot_df %>%
  mutate(
    X_Key = case_when(
      Plot_Type == "Single-source probability" ~ paste0("single_", Source),
      Plot_Type == "Exact selected source set" ~ paste0("exact_", Source)
    ),
    X_Label = Source_Label
  )

x_levels <- c(
  paste0("single_", single_order),
  paste0("exact_", exact_order)
)

x_labels <- c(
  setNames(source_names[single_order], paste0("single_", single_order)),
  setNames(source_names[exact_order], paste0("exact_", exact_order))
)

plot_df$X_Key <- factor(plot_df$X_Key, levels = x_levels)

source_colors <- c(
  "single_S2" = "#91BFDB",  # Nf
  "single_S3" = "#5AAE61",  # Nm
  "single_S1" = "#FDB863",  # UCf
  "single_S4" = "#D95F02",  # UCm
  
  "exact_S2" = "#91BFDB",   # Nf
  "exact_S3" = "#5AAE61",   # Nm
  "exact_S1" = "#FDB863",   # UCf
  "exact_S4" = "#D95F02",   # UCm
  
  "exact_S23" = "grey75",   # Nf+Nm
  "exact_S12" = "grey70",   # Nf+UCf
  "exact_S24" = "grey65",   # Nf+UCm
  "exact_S13" = "grey60",   # Nm+UCf
  "exact_S34" = "grey55",   # Nm+UCm
  "exact_S14" = "grey50",   # UCf+UCm
  "exact_S123" = "grey45",  # Nf+Nm+UCf
  "exact_S234" = "grey40",  # Nf+Nm+UCm
  "exact_S124" = "grey35",  # Nf+UCf+UCm
  "exact_S134" = "grey30"   # Nm+UCf+UCm
)

p <- ggplot(
  plot_df,
  aes(x = X_Key, y = Selection_Probability, fill = X_Key)
) +
  geom_col(
    data = plot_df %>% filter(Plot_Type == "Single-source probability"),
    width = 0.28,
    color = "black",
    linewidth = 0.2
  ) +
  geom_col(
    data = plot_df %>% filter(Plot_Type == "Exact selected source set"),
    width = 0.72,
    color = "black",
    linewidth = 0.2
  ) +
  facet_grid(
    Row_Label ~ Col_Label,
    scales = "free_x"
  ) +
  scale_fill_manual(values = source_colors, guide = "none") +
  scale_x_discrete(labels = x_labels) +
  scale_y_continuous(
    limits = c(0, 1),
    breaks = seq(0, 1, 0.2)
  ) +
  labs(
    x = "Selected source set",
    y = "Selection probability"
  ) +
  theme_bw(base_size = 13) +
  theme(
    strip.background = element_rect(fill = "grey85", color = "black", linewidth = 0.5),
    strip.text.x = element_text(size = 11, face = "bold"),
    strip.text.y = element_text(size = 10, face = "bold", angle = 90),
    
    axis.text.x = element_text(angle = 45, hjust = 1, size = 7),
    axis.text.y = element_text(size = 9),
    axis.title = element_text(size = 13),
    
    panel.grid.minor = element_blank(),
    panel.grid.major.x = element_blank(),
    panel.border = element_rect(color = "grey40", fill = NA, linewidth = 0.4),
    
    panel.spacing.x = unit(0.8, "lines"),
    panel.spacing.y = unit(0.5, "lines"),
    plot.margin = margin(8, 8, 8, 8)
  )

print(p)


# ggsave(
#   filename = file.path(result_dir, paste0(selection_sheet, "_source_selection_plot_targetonly.png")),
#   plot = p,
#   width = 15,
#   height = 8,
#   dpi = 300
# )