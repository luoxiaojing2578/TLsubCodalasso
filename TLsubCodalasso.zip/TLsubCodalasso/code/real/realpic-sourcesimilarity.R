# Source similarity heatmaps

library(dplyr)
library(ggplot2)
library(ggnewscale)

data_file <- "abundance_stoolsubset.csv"

result_dir <- "E:/..."

out_dir <- file.path(result_dir, "source_similarity_combined")

if (!dir.exists(out_dir)) {
  dir.create(out_dir, recursive = TRUE)
}

data <- read.csv(data_file)

data <- data[
  !is.na(data$bmi) &
    data$bmi != "na" &
    data$bmi != "nd",
]

data$bmi <- as.numeric(data$bmi)

if (!("age" %in% names(data))) {
  stop("No age column was found in the data. Please check whether the column name is 'age'.")
}

data$age <- as.numeric(data$age)

data <- data[
  !is.na(data$age),
]

genus_columns <- names(data)[
  grepl("\\.g__", names(data)) &
    !grepl("\\.s__", names(data)) &
    !grepl("\\.t__", names(data))
]

genus_mat <- data[, genus_columns, drop = FALSE]

zero_ratio <- colMeans(genus_mat == 0)

genus_columns <- genus_columns[zero_ratio <= 0.9]

extract_phylum <- function(x) {
  if (grepl("p__", x)) {
    sub(".*p__([^\\.\\|;]+).*", "\\1", x)
  } else {
    NA_character_
  }
}

genus_phylum <- sapply(genus_columns, extract_phylum)

phylum_count <- table(genus_phylum)

valid_phylum <- names(phylum_count[phylum_count >= 2])

genus_columns <- genus_columns[genus_phylum %in% valid_phylum]
genus_phylum  <- genus_phylum[genus_phylum %in% valid_phylum]

ord <- order(genus_phylum, genus_columns, na.last = TRUE)

genus_columns_ordered <- genus_columns[ord]
genus_phylum_ordered  <- genus_phylum[ord]

group_sizes <- as.numeric(table(genus_phylum_ordered))
tind <- c(0, cumsum(group_sizes))

cat("genus :", length(genus_columns_ordered), "\n")
cat("tind =", paste(tind, collapse = ", "), "\n")

data_use <- data[, c("gender", "disease", "bmi", "age", genus_columns_ordered)]
data_use <- na.omit(data_use)

X <- data_use[, genus_columns_ordered, drop = FALSE]

meta <- data.frame(
  gender = data_use$gender,
  disease = data_use$disease,
  BMI = data_use$bmi,
  age = data_use$age,
  stringsAsFactors = FALSE
)

meta$dataset <- dplyr::case_when(
  meta$gender == "female" & meta$disease == "ibd_ulcerative_colitis" ~ "S1: UC female",
  meta$gender == "female" & meta$disease == "n" ~ "S2: Normal female",
  meta$gender == "male"   & meta$disease == "n" ~ "S3: Normal male",
  meta$gender == "male"   & meta$disease == "ibd_ulcerative_colitis" ~ "S4: UC male",
  TRUE ~ NA_character_
)

keep_sample <- !is.na(meta$dataset)

X <- X[keep_sample, , drop = FALSE]
meta <- meta[keep_sample, , drop = FALSE]

meta$dataset <- factor(
  meta$dataset,
  levels = c(
    "S1: UC female",
    "S2: Normal female",
    "S3: Normal male",
    "S4: UC male"
  )
)

dataset_levels <- levels(meta$dataset)

short_names <- c(
  "S1: UC female"     = "UC female",
  "S2: Normal female" = "Normal female",
  "S3: Normal male"   = "Normal male",
  "S4: UC male"       = "UC male"
)

print(table(meta$dataset))

global_clr_transform <- function(C_total) {
  gm <- exp(rowMeans(log(C_total)))
  Z_clr <- log(sweep(C_total, 1, gm, "/"))
  return(Z_clr)
}

X_mat <- as.matrix(X)
storage.mode(X_mat) <- "numeric"

X_mat[is.na(X_mat)] <- 0
X_mat[X_mat == 0] <- 0.5

X_rel <- X_mat / rowSums(X_mat)

X_clr <- global_clr_transform(X_rel)
X_clr <- as.data.frame(X_clr)

calc_center_distance <- function(X_similarity, meta) {
  group_centers <- X_similarity %>%
    mutate(dataset = meta$dataset) %>%
    group_by(dataset) %>%
    summarise(
      across(where(is.numeric), mean),
      .groups = "drop"
    )
  
  group_centers_mat <- as.matrix(group_centers[, -1])
  rownames(group_centers_mat) <- group_centers$dataset
  
  center_dist_mat <- as.matrix(dist(group_centers_mat, method = "euclidean"))
  return(center_dist_mat)
}

center_dist_comp <- calc_center_distance(X_clr, meta)
center_dist_comp <- center_dist_comp[dataset_levels, dataset_levels]

cat("CLR-center distance, composition only:\n")
print(round(center_dist_comp, 3))

prev_list <- lapply(
  split(seq_len(nrow(X)), meta$dataset),
  function(idx) {
    colMeans(X[idx, , drop = FALSE] > 0)
  }
)

prev_mat <- do.call(cbind, prev_list)
colnames(prev_mat) <- names(prev_list)

prev_cor <- cor(prev_mat, method = "spearman")
prev_cor <- prev_cor[dataset_levels, dataset_levels]

cat("Spearman correlations of genus prevalence:\n")
print(round(prev_cor, 3))

calc_genus_bmi_cor_vector <- function(X_clr, meta, dataset_name) {
  
  idx <- which(meta$dataset == dataset_name)
  
  X_k <- X_clr[idx, , drop = FALSE]
  y_k <- meta$BMI[idx]
  
  cor_vec <- apply(
    X_k,
    2,
    function(x) {
      suppressWarnings(
        cor(
          x,
          y_k,
          method = "spearman",
          use = "pairwise.complete.obs"
        )
      )
    }
  )
  
  return(cor_vec)
}

bmi_assoc_list <- lapply(
  dataset_levels,
  function(ds) {
    calc_genus_bmi_cor_vector(X_clr, meta, ds)
  }
)

names(bmi_assoc_list) <- dataset_levels

bmi_assoc_mat <- do.call(cbind, bmi_assoc_list)
colnames(bmi_assoc_mat) <- dataset_levels
rownames(bmi_assoc_mat) <- genus_columns_ordered

bmi_assoc_pairwise_cor <- cor(
  bmi_assoc_mat,
  method = "spearman",
  use = "pairwise.complete.obs"
)

bmi_assoc_pairwise_cor <- bmi_assoc_pairwise_cor[dataset_levels, dataset_levels]

cat("\nPairwise Spearman correlation of genus-BMI association patterns:\n")
print(round(bmi_assoc_pairwise_cor, 3))

calc_age_adjusted_genus_bmi_cor_vector <- function(X_clr, meta, dataset_name) {
  
  idx <- which(meta$dataset == dataset_name)
  
  X_k <- X_clr[idx, , drop = FALSE]
  y_k <- meta$BMI[idx]
  age_k <- meta$age[idx]
  
  bmi_resid <- resid(lm(y_k ~ age_k))
  
  cor_vec <- apply(
    X_k,
    2,
    function(x) {
      genus_resid <- resid(lm(x ~ age_k))
      
      suppressWarnings(
        cor(
          genus_resid,
          bmi_resid,
          method = "spearman",
          use = "pairwise.complete.obs"
        )
      )
    }
  )
  
  return(cor_vec)
}

bmi_assoc_ageadj_list <- lapply(
  dataset_levels,
  function(ds) {
    calc_age_adjusted_genus_bmi_cor_vector(X_clr, meta, ds)
  }
)

names(bmi_assoc_ageadj_list) <- dataset_levels

bmi_assoc_ageadj_mat <- do.call(cbind, bmi_assoc_ageadj_list)
colnames(bmi_assoc_ageadj_mat) <- dataset_levels
rownames(bmi_assoc_ageadj_mat) <- genus_columns_ordered

bmi_assoc_ageadj_pairwise_cor <- cor(
  bmi_assoc_ageadj_mat,
  method = "spearman",
  use = "pairwise.complete.obs"
)

bmi_assoc_ageadj_pairwise_cor <- bmi_assoc_ageadj_pairwise_cor[dataset_levels, dataset_levels]

cat("\nAge-adjusted pairwise Spearman correlation of genus-BMI association patterns:\n")
print(round(bmi_assoc_ageadj_pairwise_cor, 3))

make_long_df <- function(mat, type, panel) {
  
  df <- as.data.frame(as.table(mat))
  colnames(df) <- c("Row", "Col", "Value")
  
  df$type <- type
  df$panel <- panel
  df$Label <- sprintf("%.2f", df$Value)
  
  df$Row <- factor(df$Row, levels = rev(dataset_levels))
  df$Col <- factor(df$Col, levels = dataset_levels)
  
  levels(df$Row) <- short_names[levels(df$Row)]
  levels(df$Col) <- short_names[levels(df$Col)]
  
  return(df)
}

dist_comp_df <- make_long_df(
  center_dist_comp,
  type = "dist",
  panel = "CLR-center distance"
)

corr_prev_df <- make_long_df(
  prev_cor,
  type = "corr_prev",
  panel = "Genus prevalence correlation"
)

bmi_assoc_df <- make_long_df(
  bmi_assoc_pairwise_cor,
  type = "corr_bmi",
  panel = "Pairwise Spearman correlation\n(BMI--genus)"
)

bmi_assoc_ageadj_df <- make_long_df(
  bmi_assoc_ageadj_pairwise_cor,
  type = "corr_bmi",
  panel = "Pairwise Spearman correlation\n(age-adjusted BMI--genus)"
)

heat_df <- rbind(
  dist_comp_df,
  corr_prev_df,
  bmi_assoc_df,
  bmi_assoc_ageadj_df
)

heat_df$panel <- factor(
  heat_df$panel,
  levels = c(
    "CLR-center distance",
    "Genus prevalence correlation",
    "Pairwise Spearman correlation\n(BMI--genus)",
    "Pairwise Spearman correlation\n(age-adjusted BMI--genus)"
  )
)

p_heat_2x2 <- ggplot() +
  
geom_tile(
  data = subset(heat_df, type == "dist"),
  aes(x = Col, y = Row, fill = Value),
  color = "white",
  linewidth = 0.8
) +
  geom_text(
    data = subset(heat_df, type == "dist"),
    aes(x = Col, y = Row, label = Label),
    size = 4.1
  ) +
  scale_fill_gradient(
    low = "white",
    high = "#D73027",
    name = "Distance"
  ) +
  
  ggnewscale::new_scale_fill() +
  
geom_tile(
  data = subset(heat_df, type == "corr_bmi"),
  aes(x = Col, y = Row, fill = Value),
  color = "white",
  linewidth = 0.8
) +
  geom_text(
    data = subset(heat_df, type == "corr_bmi"),
    aes(x = Col, y = Row, label = Label),
    size = 4.1
  ) +
  scale_fill_gradient2(
    low = "#4575B4",
    mid = "white",
    high = "#D73027",
    midpoint = 0,
    limits = c(-1, 1),
    name = "BMI--genus\ncorrelation"
  ) +
  
  facet_wrap(
    ~ panel,
    nrow = 2
  ) +
  
  coord_fixed() +
  labs(x = NULL, y = NULL) +
  
  theme_bw(base_size = 13) +
  theme(
    strip.background = element_rect(
      fill = "grey90",
      color = "grey40",
      linewidth = 0.8
    ),
    
    strip.text = element_text(
      face = "bold",
      size = 10.5,
      lineheight = 0.9
    ),
    
    axis.text.x = element_text(
      angle = 45,
      hjust = 1,
      vjust = 1,
      size = 10.5
    ),
    
    axis.text.y = element_text(size = 10.5),
    
    panel.grid = element_blank(),
    
    panel.border = element_rect(
      color = "grey40",
      linewidth = 0.8
    ),
    
    legend.position = "right",
    legend.title = element_text(size = 11),
    legend.text = element_text(size = 9.5),
    
    legend.spacing.y = unit(0.25, "cm"),
    
    panel.spacing.x = unit(0.9, "lines"),
    panel.spacing.y = unit(1.0, "lines"),
    
    plot.margin = margin(5, 8, 5, 5)
  )

print(p_heat_2x2)

ggsave(
  filename = file.path(out_dir, "Fig_similarity_heatmaps_2x2_combined.png"),
  plot = p_heat_2x2,
  width = 15,
  height = 10.5,
  dpi = 400
)

ggsave(
  filename = file.path(out_dir, "Fig_similarity_heatmaps_2x2_combined.pdf"),
  plot = p_heat_2x2,
  width = 15,
  height = 10.5
)

cat("\nCombined 2 x 2 heatmap finished.\n")
cat("Figure saved to:", out_dir, "\n")
