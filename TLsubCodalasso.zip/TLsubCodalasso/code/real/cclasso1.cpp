#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]
#include <cmath>
#include <Rcpp.h>

using namespace arma;
using namespace Rcpp;

// [[Rcpp::export]]
int nzcount(arma::vec x) {
  vec y = nonzeros(x) ;
  return y.n_elem;
}


// [[Rcpp::export]]
double softThres(const double x, const double lambda) {
  return((x > lambda) ? x - lambda :
           (x < -lambda) ? x + lambda : 0.);
}


//double hardThres(const double x, const double lambda) {
  //return((x > lambda) ? x  :
           //(x < -lambda) ? x : 0.);
//}


// //' Engine function
// //'
////' @export
// [[Rcpp::export]]
Rcpp::List classoshe(arma::mat Xt, arma::vec y, arma::mat C, arma::vec we, double lam0,
                     int maxiter, double tol, double mu, double nu){
  
  int i,n = Xt.n_rows, p = Xt.n_cols, kk = C.n_rows;
  Rcpp::List out;
  //mat sfac = stddev(Xt);
  //for(i=0; i < p; i++){
    //if(sfac(0,i)!=0) sfac(0,i) = 1/sfac(0,i); else sfac(0,i) = 1;
  //}
  //Xt  = Xt.each_row()%sfac;
  //C  = C.each_row()%sfac;
  mat xx = Xt.t()*Xt/n , cc = C.t()*C;
  vec xy = Xt.t()*y/n;  
  vec lam, betap = zeros<vec>(p) , betau = zeros<vec>(p), psi;
  vec xxdiag = xx.diag(), ccdiag = cc.diag();
  double ssq2, ssq = sqrt(accu(square(y-Xt*betap))/n),err,du;
  we = we*lam0;
  int k,j;
  xx.diag().zeros();  cc.diag().zeros();
  for(i=0; i < maxiter; i++){
    ssq2=ssq;
    lam = we*ssq2;
    psi = zeros<vec>(kk);
    for(k=0; k < maxiter; k++){
      for(j=0; j < p; j++){
        du = (xy(j) - sum(xx.row(j)*betau)); //// check 
        du = du-mu*(sum(cc.row(j)*betau) + sum(C.col(j)%psi));
        betau(j) = softThres(du,lam(j))/(xxdiag(j) + mu*ccdiag(j));
      }
      mu = mu*nu;
      psi = psi+ C*betau;
      err = sqrt(sum(square(betap-betau))); 
      betap = betau;
      if(err < tol && k >0) break;
    }
    ssq = sqrt(accu(square(y-Xt*betap))/n);
    if(abs(ssq-ssq2) < tol && i >0) break;
  }
  //out["beta"] = betap%vectorise(sfac);
  out["beta"] = betap;
  return(out);
}


// [[Rcpp::export]]
Rcpp::List classoshe1(arma::mat Xt, arma::vec y,
                     arma::mat C, arma::vec we,
                     double lam0,
                     int maxiter, double tol,
                     double mu, double nu,
                     arma::vec cw   
                     ){
  
  int i, n = Xt.n_rows, p = Xt.n_cols, kk = C.n_rows;
  Rcpp::List out;
  
  mat sfac = stddev(Xt);
  for(i=0; i < p; i++){
    if(sfac(0,i)!=0) sfac(0,i) = 1/sfac(0,i); else sfac(0,i) = 1;
  }
  Xt  = Xt.each_row()%sfac;
  C  = C.each_row()%sfac;

  mat xx = Xt.t()*Xt/n , cc = C.t()*C;
  vec xy = Xt.t()*y/n;  
  
  vec lam, betap = zeros<vec>(p), betau = zeros<vec>(p), psi;
  vec xxdiag = xx.diag(), ccdiag = cc.diag();
  
  double ssq2, ssq = sqrt(accu(square(y - Xt*betap))/n), err, du;
  we = we * lam0;
  
  int k, j;
  xx.diag().zeros();
  cc.diag().zeros();
  
  for(i = 0; i < maxiter; i++){
    
    ssq2 = ssq;
    lam = we * ssq2;
    psi = zeros<vec>(kk);
    
    for(k = 0; k < maxiter; k++){
      
      for(j = 0; j < p; j++){
        
        du = xy(j) - sum(xx.row(j) * betau);
        
        
        du = du - mu * (
          sum(cc.row(j) * betau) +
          sum(C.col(j) % (psi + cw))
        );
        
        betau(j) = softThres(du, lam(j)) /
          (xxdiag(j) + mu * ccdiag(j));
      }
      
      mu = mu * nu;
      
      
      psi = psi + (C * betau + cw);
      
      err = sqrt(sum(square(betap - betau)));
      betap = betau;
      
      if(err < tol && k > 0) break;
    }
    
    ssq = sqrt(accu(square(y - Xt * betap)) / n);
    if(abs(ssq - ssq2) < tol && i > 0) break;
  }
  
  out["beta"] = betap%vectorise(sfac);
  //out["beta"] = betap;
  return(out);
}


// [[Rcpp::export]]
double hardThres(const double x, const double lambda) {
  return (fabs(x) >= lambda) ? x : 0.;
}


// [[Rcpp::export]]
Rcpp::List classo_l0(arma::mat Xt, arma::vec y, arma::mat C, arma::vec we, double lam0,
                     int maxiter, double tol, double mu, double nu, int sparse_level = 10){
  int n = Xt.n_rows, p = Xt.n_cols, kk = C.n_rows;
  Rcpp::List out;
  
  
  mat xx = Xt.t()*Xt/n;      
  vec xy = Xt.t()*y/n;      
  mat cc = C.t()*C;          
  
  vec xxdiag = xx.diag(), ccdiag = cc.diag();
  xx.diag().zeros();  
  cc.diag().zeros();
  
  
  vec beta = zeros<vec>(p);   
  vec beta_prev = beta;       
  double ssq = sqrt(accu(square(y - Xt*beta))/n);
  double ssq_prev = ssq;
  
  
  // vec lambda = we * lam0;
  vec lambda = we * sqrt(2 * lam0);  
  
  
  for(int iter = 0; iter < maxiter; iter++){
    beta_prev = beta;
    ssq_prev = ssq;
    
    
    vec psi = zeros<vec>(kk);  
    for(int k = 0; k < maxiter; k++){
      vec beta_new = beta;
      for(int j = 0; j < p; j++){
       
        double du = xy(j) - sum(xx.row(j)*beta_new) - mu*(sum(cc.row(j)*beta_new) + sum(C.col(j)%psi));
       
        beta_new(j) = hardThres(du, lambda(j)) / (xxdiag(j) + mu*ccdiag(j) + 1e-8);
      }
      
     
      mu *= nu;
      psi += C*beta_new;
      
     
      double err = sqrt(sum(square(beta - beta_new)));
      beta = beta_new;
      if(err < tol) break;
    }
    
    
    ssq = sqrt(accu(square(y - Xt*beta))/n);
    
   
    double beta_err = sqrt(sum(square(beta - beta_prev)));
    if(beta_err < tol && fabs(ssq - ssq_prev) < tol) break;
  }
  
  out["beta"] = beta;
  out["sparse_level"] = nzcount(beta); 
  return(out);
}


// [[Rcpp::export]]
Rcpp::List classo_l0_nonhom(arma::mat Zt, arma::vec y, arma::mat C, arma::vec we,
                           double lam0, int maxiter, double tol, double mu, double nu,
                           arma::vec cw, int sparse_level) {
  
  int n = Zt.n_rows, p = Zt.n_cols, kk = C.n_rows;
  Rcpp::List out;
  
 
  mat sfac = stddev(Zt);
  for (int i = 0; i < p; i++) {
    if (sfac(0, i) != 0) sfac(0, i) = 1 / sfac(0, i);
    else sfac(0, i) = 1;
  }
  Zt.each_row() %= sfac;
  C.each_row() %= sfac;
  
 
  mat xx = Zt.t() * Zt / n;
  vec xy = Zt.t() * y / n;
  mat cc = C.t() * C;
  vec xxdiag = xx.diag(), ccdiag = cc.diag();
  xx.diag().zeros(); 
  cc.diag().zeros();
  
  
  vec beta = zeros<vec>(p);
  vec beta_prev = beta;
  double ssq = sqrt(accu(square(y - Zt * beta)) / n);
  double ssq_prev = ssq;
  // vec lam = we * lam0 * ssq;
  vec lam = we * sqrt(2 * lam0) * ssq;  

  
  
  for (int iter = 0; iter < maxiter; iter++) {
    beta_prev = beta;
    ssq_prev = ssq;
    vec psi = zeros<vec>(kk); 
    
    
    for (int k = 0; k < maxiter; k++) {
      vec beta_new = beta;
      for (int j = 0; j < p; j++) {
        
        double du = xy(j) - sum(xx.row(j) * beta_new) - mu * (sum(cc.row(j) * beta_new) + sum(C.col(j) % (psi + cw)));
        
        beta_new(j) = hardThres(du, lam(j)) / (xxdiag(j) + mu * ccdiag(j) + 1e-8);
      }
      
      
      mu *= nu;
      psi += (C * beta_new + cw);
      
     
      double err = sqrt(sum(square(beta - beta_new)));
      beta = beta_new;
      if (err < tol) break;
    }
    
    
    if (nzcount(beta) > sparse_level) {
      vec abs_beta = abs(beta);
      uvec idx = sort_index(abs_beta, "descend");
      //beta(idx.rows(sparse_level, p - 1)) = 0;
      
      beta.elem( idx.rows(sparse_level, p-1) ).fill(0.0);
    }
    
   
    ssq = sqrt(accu(square(y - Zt * beta)) / n);
    
    
    double beta_err = sqrt(sum(square(beta - beta_prev)));
    if (beta_err < tol && fabs(ssq - ssq_prev) < tol) break;
  }
  
  
  out["beta"] = beta % vectorise(sfac);
  out["sparse_level"] = nzcount(beta); 
  return out;
}

