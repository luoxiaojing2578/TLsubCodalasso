﻿# Trans-subCodaLasso Real Data Analysis

R code for the real data analysis in the paper:

**Transfer Learning for High-Dimensional Regression with Compositional Covariates: Application to Microbiome Studies**

The scripts reproduce the real microbiome data analysis for BMI prediction. The real data experiments include two settings: compositional covariates only, and compositional covariates with additional non-compositional covariates. For each setting, both the single composition constraint and the subcomposition constraints are considered.

The code corresponds to the real data analysis in the main paper, and to the additional real data results in **Supplementary Material Sections S5.1 and S5.3**.

## Main functions

The main functions for the proposed method are in:

- `Func-TransCodaLasso.R`

The C++ code used for constrained Lasso computation is in:

- `cclasso1.cpp`

## How to run

The real data experiments are implemented in two main R scripts:

- `real-c.R`: real data analysis with compositional covariates only.
- `real-cnc.R`: real data analysis with compositional covariates and additional non-compositional covariates.

Both scripts include the single composition constraint and the subcomposition constraints.

Run the compositional-covariates-only experiment by:

```r
source("real-c.R")
```

Run the experiment with additional non-compositional covariates by:

```r
source("real-cnc.R")
```

The input data file is:

```text
abundance_stoolsubset.csv
```

## Figures and tables

After obtaining the Excel result files, run the following scripts to reproduce the figures and tables:

```r
source("realpic-PE.R")
source("realpic-sourceselection.R")
source("realpic-sourcesimilarity.R")
source("realpic-jaccardsimilarity.R")
source("realtab-beta-single.R")
source("realtab-beta-sub.R")
```

